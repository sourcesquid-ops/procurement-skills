---
name: tariff-hs-lookup
description: Use this skill when the user needs to find an HS code (Harmonized System code), check import duty rates, understand customs classification, find FTA preferential rates, or assess tariff impact on sourcing decisions. Also trigger when the user mentions "HS code", "customs code", "tariff code", "HTS code", "duty rate", "import tax", "customs duty", "what is the duty on", "FTA benefit", "RCEP", "India-ASEAN FTA", "CPTPP", "GSP", "anti-dumping duty", "countervailing duty", "Section 301", "safeguard duty", or any question about how much tax they'll pay importing goods. Works for any product, any country pair.
---

# Tariff & HS Lookup

Classifies products under the Harmonized System, identifies applicable duty rates, checks FTA eligibility, and assesses total tariff burden for any import scenario. Flags anti-dumping, countervailing, and safeguard duties.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Note destination country (import market), origin country (determines FTA eligibility), and product category.

## Workflow

### Step 1: HS Code Classification

The Harmonized System is a 6-digit international classification. Countries add digits to create national tariff lines (8–10 digits).

**To classify a product:**
1. Identify the product's primary function and material composition
2. Work through the HS classification hierarchy (Sections → Chapters → Headings → Subheadings)
3. Apply GIR (General Interpretive Rules) when classification is ambiguous

**HS Structure:**
```
Chapter XX (2 digits) — broad category
  Heading XXXX (4 digits) — product type
    Subheading XXXXXX (6 digits) — international standard
      National line XXXXXXXX–XXXXXXXXXX (8–10 digits) — country-specific
```

**Key chapter reference (common sourcing categories):**

| Product category | HS Chapter range |
|-----------------|-----------------|
| Plastics and articles | 39 |
| Rubber and articles | 40 |
| Wood and articles | 44 |
| Paper and paperboard | 48 |
| Textiles (yarn, fabric) | 50–60 |
| Apparel (knit) | 61 |
| Apparel (woven) | 62 |
| Footwear | 64 |
| Ceramics | 69 |
| Glassware | 70 |
| Iron and steel | 72–73 |
| Copper | 74 |
| Aluminium | 76 |
| Machinery | 84 |
| Electronics/electrical | 85 |
| Vehicles/auto parts | 87 |
| Furniture | 94 |
| Toys and games | 95 |
| Miscellaneous manufactured | 96 |
| Bio-based / natural fibre products | 46 / 39 / 44 (depends) |
| Food / agricultural | 01–24 |
| Chemicals | 28–38 |
| Pharma | 30 |

**Use web search to verify:** Search for "[product name] HS code [destination country]" to confirm current classification. HS codes are updated every 5 years (next: HS 2027).

### Step 2: Duty Rate Lookup

Search for duty rates using:
- India: [ICEGATE customs tariff](https://www.icegate.gov.in/Webappl/CtPrintServlet) or search "India customs duty [HS code]"
- USA: USITC Tariff Schedule — search "HTS [code] USA duty rate"
- EU: TARIC database — search "TARIC [HS code] EU duty"
- UK: Global Trade Tariff — search "UK tariff [commodity code]"
- Australia: Australian Customs Tariff
- China: China Customs Tariff — search "[HS code] China import duty"

**Common duty rate ranges (indicative — always verify):**

| Product category | India MFN | USA MFN | EU MFN |
|-----------------|-----------|---------|--------|
| Raw plastics (Ch. 39) | 7.5–10% | 3–5% | 3–6.5% |
| Textiles (Ch. 50–60) | 10–25% | 7–14% | 8–12% |
| Apparel (Ch. 61–62) | 20% | 12–32% | 12% |
| Footwear (Ch. 64) | 20–25% | 8–48% | 3.7–17% |
| Machinery (Ch. 84) | 7.5% | 0–4.4% | 0–3.7% |
| Electronics (Ch. 85) | 0–20% | 0% (ITA) | 0% (ITA) |
| Furniture (Ch. 94) | 20% | 0% | 0–5.6% |
| Auto parts (Ch. 87) | 7.5–15% | 2.5–25% | 3.5–6.5% |
| Bio-based products | Varies | Varies | Varies |

**Additional duties to check:**
- Anti-dumping duty (ADD): Check if origin country faces ADD for this product category
- Countervailing duty (CVD): Subsidised goods from certain origins
- Safeguard duty: Temporary protection measures
- Social welfare surcharge (India): 10% of customs duty
- GST/VAT on import: Separate from customs duty (India: 5–28%; EU: 20–25%; USA: none federal)

### Step 3: FTA Eligibility Check

**Major FTAs by importing country:**

**India FTAs (as of 2025):**
| FTA | Partner countries | Benefit |
|-----|------------------|---------|
| ASEAN-India FTA (AIFTA) | 10 ASEAN nations (incl. Vietnam, Thailand, Malaysia, Indonesia) | 0–5% for most goods |
| India-UAE CEPA | UAE | Significant duty reductions |
| India-Japan CEPA | Japan | 0% for most manufactured goods |
| India-South Korea CEPA | South Korea | Duty reductions |
| India-Sri Lanka FTA | Sri Lanka | Duty-free on many items |
| SAFTA | South Asia | Limited benefits |
| India-Australia ECTA | Australia | Phasing to 0% |
| India-UK FTA | UK | Under negotiation / watch |

**USA FTAs:**
- USMCA (Canada, Mexico) — significant
- CPTPP (not in force for USA) — USA withdrew
- Section 301 additional tariffs on Chinese goods (25–100% on thousands of products)
- GSP (suspended as of 2020, partially reinstated — check current status)

**EU FTAs:**
- GSP (many developing countries) — 0–6% for eligible products
- GSP+ (enhanced preferences)
- CETA (Canada)
- EPA with Japan, South Korea, Vietnam (EVFTA)
- EU-India FTA: Under negotiation

**RCEP (Regional Comprehensive Economic Partnership):**
- Members: China, Japan, South Korea, Australia, New Zealand + 10 ASEAN nations (incl. Vietnam, Malaysia, Indonesia, Thailand, Philippines)
- India did not join RCEP
- Benefit: Staged tariff reduction to 0% on most goods over 10–20 years
- Rules of origin: Generally 40% value addition in RCEP region

**CPTPP:**
- Members: Canada, Mexico, Japan, Australia, New Zealand, Vietnam, Malaysia, Singapore, Chile, Peru, Brunei
- UK joined 2024
- Significant benefits for Vietnam exports to Japan, Australia, Canada

**FTA eligibility requirements — always check:**
1. **Rules of Origin (RoO):** Product must meet a threshold of local content or undergo substantial transformation in the FTA country
2. **Certificate of Origin:** Must be issued by relevant authority (e.g., ECGC in India, Chamber of Commerce)
3. **Tariff Shift rule:** Common alternative to value-addition rule — HS classification must change at a certain level through processing
4. **Direct transport rule:** Most FTAs require goods to be transported directly without transshipment through non-member countries (some allow with documentation)

### Step 4: Anti-Dumping and Special Duty Alert

**High-risk country/product combinations to always check:**

| Exporting country | Product categories at risk of ADD |
|------------------|----------------------------------|
| China | Steel, aluminium, textiles, solar panels, ceramics, paper, chemicals, tyres, furniture, many manufactured goods |
| India | Chemicals, certain textiles |
| Vietnam | Steel, textiles, footwear (in some markets) |

**How to check:**
- India ADD: [DGTR (Directorate General of Trade Remedies)](https://www.dgtr.gov.in)
- USA ADD/CVD: USITC and Commerce Department — search "ADD order [product] [country]"
- EU ADD: EU Official Journal — search "EU anti-dumping [product] [country]"
- Australia: Anti-Dumping Commission
- UK: Trade Remedies Authority

### Step 5: Total Duty Cost Calculation

```
TARIFF IMPACT CALCULATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Product: [Name]
HS Code: [XXXXXXXXXX]
Origin country: [Country]
Destination: [Country]
CIF value of shipment: $[X,XXX]

DUTIES APPLICABLE
MFN Customs duty: [X]% = $[XXX]
Anti-dumping duty: [X]% = $[XXX] (if applicable)
Social welfare surcharge: [X]% of customs duty = $[XXX] (India)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOTAL DUTY (before GST/VAT): $[XXX]
Effective duty rate: [X]% of CIF

WITH FTA (if eligible):
FTA rate: [X]%
FTA duty saving: $[XXX] vs. MFN
Certificate of origin required: [Yes/No]

TOTAL IMPORT COST (duty + GST/VAT): $[XXX]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RECOMMENDATION: [Use FTA / MFN / Seek alternative origin]
```

### Step 6: Strategic Sourcing Implications

If duty burden is high, advise on:

1. **Alternative origin countries** that have FTA preference with destination
2. **Tariff engineering** — legitimate product modification or HS re-classification that results in a lower duty rate (requires trade lawyer review)
3. **FTZ / bonded warehouse** strategies for duty deferral
4. **Drawback** — duty refund when goods are re-exported
5. **Inward Processing Relief (EU) / Manufacturing under bond (India)** — import duty-free for goods that will be processed and re-exported

## Related Skills
- `freight-cost-calculator` — add duty to freight for full landed cost
- `should-cost-modelling` — incorporate duty into total landed cost model
- `incoterms-advisor` — Incoterms determine CIF value basis for duty calculation
- `resilience-geopolitical-radar` — for new tariff and trade policy changes
- `rfq-drafting` — inform suppliers of required certificates of origin
