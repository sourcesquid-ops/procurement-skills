---
name: customs-documentation-checklist
description: Use this skill when the user needs to know what documents are required for a shipment, wants to check if their paperwork is complete before a shipment leaves, needs to understand a specific trade document, or is dealing with a customs hold or delay. Trigger when the user says "what documents do I need", "customs checklist", "shipping documents", "commercial invoice", "certificate of origin", "bill of lading", "packing list", "MSDS", "phytosanitary certificate", "import licence", "export licence", "FDA prior notice", "ISF filing", "customs clearance", "LC document requirements", "documents for importing from China", "what does customs need", "my shipment is held", "document discrepancy", or any question about paperwork needed to move goods across borders legally. Covers any product, any country pair, any transport mode (sea, air, road, courier), any payment method (TT, LC, DP, DA).
---

# Customs Documentation Checklist

Every international shipment requires a specific set of documents. Missing one stops the goods. A discrepancy between documents costs money, causes delays, and can trigger seizure. This skill produces the exact document checklist for any shipment — any product, any country pair, any transport mode — and explains how to prepare each document correctly.

**Core philosophy:** Customs documentation is not bureaucracy. It is the legal evidence that your goods are what you say they are, worth what you say they're worth, made where you say they were made, and compliant with every law that applies to them. Every document gap is a customs officer's justification to hold your shipment.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Extract: supplier country, destination country, product category, Incoterms, payment terms, any special certifications required.

---

## Step 1: Shipment Profile

Collect the following before generating the checklist. Check context file first.

```
SHIPMENT PROFILE
─────────────────────────────────────────────────────────
Origin country:          [e.g., China / India / Vietnam]
Origin city / port:      [e.g., Ningbo / Nhava Sheva / HCMC]
Destination country:     [e.g., USA / UK / Germany / India]
Destination port:        [e.g., Los Angeles / Felixstowe / Hamburg]
Product:                 [Description + HS code if known]
Product category:        [General goods / Food / Pharma / Chemicals /
                          Textiles / Timber / Live plants / Hazmat /
                          Electronics / Medical devices / etc.]
Transport mode:          [FCL Sea / LCL Sea / Air / Road / Courier]
Payment terms:           [TT / LC / DP / DA / Open account]
Incoterms:               [EXW / FOB / CIF / DAP / DDP / etc.]
Shipment value:          [USD / EUR / INR amount]
Special conditions:      [Temperature-controlled / Hazmat /
                          CITES species / Dual-use goods / etc.]
Is an FTA being used:    [RCEP / AIFTA / CPTPP / GSP / USMCA / etc.]
```

---

## Step 2: Universal Documents — Required for Every International Shipment

These five documents are mandatory for virtually every cross-border commercial shipment regardless of country pair or product.

---

### 1. Commercial Invoice (CI)

**What it is:** The primary transactional document. It is simultaneously the seller's bill to the buyer, the customs declaration of value, and the import duty assessment basis.

**Who prepares it:** Exporter / seller.

**How many originals:** 3 originals standard (some countries require more — see country notes below).

**What it must contain — mandatory fields:**

```
COMMERCIAL INVOICE — REQUIRED FIELDS
─────────────────────────────────────────────────────────
☐ Invoice number and date
☐ Seller's full legal name, registered address, and Tax/GST ID
☐ Buyer's full legal name, registered address, and Tax/GST ID
☐ Consignee's name and address (if different from buyer)
☐ Purchase Order number (buyer's reference)
☐ Country of origin for each line item
☐ HS code (6-digit minimum; 8–10 digit for importing country)
☐ Full description of goods — must match PO, packing list, and BL exactly:
    - Product name (no abbreviations or codes only)
    - Material/composition
    - End use (for dual-use/restricted goods)
    - Quantity with unit of measure
☐ Unit price (in agreed currency)
☐ Line total and invoice total
☐ Currency clearly stated
☐ Incoterms (with named place and "Incoterms® 2020")
☐ Freight amount (if CIF/CFR — must be stated separately)
☐ Insurance amount (if CIF — must be stated separately)
☐ Payment terms
☐ Port of loading
☐ Port of discharge
☐ Vessel name and voyage number OR flight number
☐ Bill of lading / AWB number (once issued)
☐ Signature and stamp of exporter
```

**Critical rules — invoice red flags that cause customs problems:**

- ❌ "As per sample" or "As agreed" — customs requires actual description
- ❌ Description differs from BL (e.g., "plastic parts" on invoice vs. "auto components" on BL)
- ❌ Value understatement — customs databases benchmark against market prices; low values trigger examination
- ❌ Missing country of origin — this is mandatory on invoice in almost every jurisdiction
- ❌ Invoice value in one currency, payment terms in another — creates ambiguity
- ❌ HS code on invoice doesn't match importer's classification — triggers query
- ❌ Buyer name on invoice doesn't match consignee on BL — creates LC discrepancy risk

**Country-specific invoice requirements:**
- **USA:** No official format required but FDA, FWS, or USDA may require additional fields for regulated goods.
- **EU:** Must include EORI number for both exporter and importer if above de minimis thresholds.
- **India (import):** Must include Indian importer's IEC (Import Export Code) number.
- **India (export):** Must include Indian exporter's IEC, GSTIN; state GST rate; place of supply; mention "For Export" prominently; if LUT (Letter of Undertaking): state LUT number and "Supply meant for export on payment of IGST" or "under LUT without payment of IGST."
- **GCC (Saudi, UAE, etc.):** Invoice must be notarised/legalised by Chamber of Commerce and sometimes by destination country embassy.
- **China (import):** Chinese customs uses a standardised import declaration; invoice must match exactly.
- **Russia:** Requires invoice in Russian or with Russian translation for customs clearance.

---

### 2. Packing List (PL)

**What it is:** A detailed breakdown of exactly how goods are packed — what is in each carton, how many cartons, dimensions and weights. Customs uses this to verify that what they may physically examine matches what the invoice describes.

**Who prepares it:** Exporter / supplier.

**Critical rule:** Packing list, commercial invoice, and bill of lading MUST all use identical descriptions, quantities, and references. One word difference can cause a discrepancy under a Letter of Credit.

**What it must contain:**

```
PACKING LIST — REQUIRED FIELDS
─────────────────────────────────────────────────────────
☐ Packing list number and date
☐ Invoice number (cross-reference)
☐ Seller and buyer details
☐ PO number
☐ Mark and numbers (carton markings matching physical cartons)
☐ For each carton (or carton grouping):
    - Carton number / carton range
    - Item / part number
    - Full description (must match invoice exactly)
    - Quantity per carton (in pcs, kg, m, etc.)
    - Number of cartons
    - Dimensions per carton (L × W × H in cm)
    - Net weight per carton (kg)
    - Gross weight per carton (kg)
☐ Totals:
    - Total number of packages / cartons
    - Total net weight (kg)
    - Total gross weight (kg)
    - Total volume (CBM)
☐ Vessel / flight details
☐ Port of loading and discharge
☐ Signature and stamp
```

---

### 3. Bill of Lading (BL) / Airway Bill (AWB) / Road Waybill

**What it is:** The transport document issued by the carrier. For sea freight, the original Bill of Lading is a **document of title** — whoever holds the original BL controls the goods. This makes it the most legally powerful document in international trade.

**Types:**

| Type | Mode | Negotiable? | When used |
|------|------|------------|-----------|
| Original Bill of Lading (OBL) | Sea | Yes — document of title | LC payments; where bank controls release |
| Seaway Bill / Express Release | Sea | No | TT payment; trusted relationship; faster release |
| Airway Bill (AWB) | Air | No | Air freight always |
| Road Consignment Note (CMR) | Road | No | European road freight |
| Multimodal BL | Multi | Usually yes | Combined transport |
| House BL (HBL) | Sea (through forwarder) | Depends | LCL; forwarder-issued |
| Master BL (MBL) | Sea (carrier) | Yes | Issued by shipping line |

**Critical BL fields to verify:**

```
BILL OF LADING — CHECK THESE BEFORE ACCEPTING
─────────────────────────────────────────────────────────
☐ Shipper name matches invoice seller exactly (character for character)
☐ Consignee name matches invoice buyer / LC terms exactly
☐ Notify party matches LC or buyer instructions
☐ Port of loading matches LC / invoice
☐ Port of discharge matches LC / invoice
☐ Description of goods matches invoice (same words — not similar)
☐ Container number(s) and seal number(s) stated
☐ Number of packages matches packing list total exactly
☐ Gross weight matches packing list (±5% acceptable by most customs)
☐ On-board notation present if required by LC
    (Must say "Shipped on Board" with vessel name, port, and date)
☐ "Clean" BL — no clause noting damaged or deficient cargo
    ("Said to contain" clauses are standard; any damage notation = dirty BL)
☐ Freight notation: "Freight Prepaid" (if seller pays) or
    "Freight Collect" (if buyer pays) — must match Incoterms
☐ Date of issue within validity window (LC, L/C if applicable)
☐ Number of originals issued stated (usually 3/3)
```

**Common BL errors that cause LC rejection:**
- "Freight prepaid" on a FOB BL (buyer should pay freight on FOB)
- Description says "cartons" on invoice but "packages" on BL
- On-board date after LC expiry date
- Consignee name abbreviated differently from LC
- Missing "clean on board" notation when LC requires it

---

### 4. Certificate of Origin (COO)

**What it is:** An official document certifying the country of manufacture of the goods. Required by customs in virtually every country to determine:
1. Which duty rate applies (MFN vs. preferential/FTA rate)
2. Whether import restrictions or anti-dumping duties apply
3. Compliance with rules of origin for trade agreement claims

**Types of Certificate of Origin:**

| Type | Used for | Issued by | Key features |
|------|---------|-----------|--------------|
| **Non-preferential / General COO** | Proving origin without claiming duty preference | Chamber of Commerce | Standard requirement |
| **GSP Form A** | Claiming GSP preference (developing country → developed) | Government / Customs authority | Specific format |
| **EUR.1 Movement Certificate** | EU trade agreements (EU ↔ partner countries) | Customs authority | Preference certificate |
| **REX Declaration** | EU GSP self-certification by registered exporter | Exporter (registered) | For exports to EU |
| **Form AIFTA** | India-ASEAN FTA | Government / DGFT | India ↔ ASEAN |
| **Form AI** | ASEAN Trade in Goods Agreement | Government authority | Intra-ASEAN |
| **Form E** | ASEAN-China FTA (ACFTA) | Government | China ↔ ASEAN |
| **Form D** | ASEAN FTA (ATIGA) | Government | Intra-ASEAN |
| **RCEP COO** | RCEP (15-country Asia-Pacific FTA) | Government / self-certification | RCEP members |
| **USMCA Certification** | USMCA (USA, Canada, Mexico) | Exporter self-certification | North America |
| **CPTPP COO** | CPTPP members | Government / self-certification | CPTPP countries |

**Rules of Origin — critical concept:**

For a COO to be valid for FTA preference, the goods must meet the "rules of origin" for that FTA. Common tests:
- **Wholly obtained:** Product entirely produced in the country (agricultural goods, natural resources)
- **Substantial transformation:** The product has been sufficiently transformed — tested by:
  - *Tariff Shift Rule:* HS classification changes at chapter (2-digit), heading (4-digit), or subheading (6-digit) level through processing
  - *Value Added Rule:* Regional/local value content exceeds a threshold (commonly 35–40%)
  - *Specific Process Rule:* A defined manufacturing process must be performed in the origin country

**COO preparation checklist:**

```
CERTIFICATE OF ORIGIN — PREPARATION CHECK
─────────────────────────────────────────────────────────
☐ Correct COO type selected for the FTA/preference being claimed
☐ Exporter details match invoice (legal name, address)
☐ Consignee / importer details match invoice
☐ Description matches invoice and BL exactly
☐ HS code matches invoice (at correct digit level for the FTA)
☐ Country of origin stated: [Country]
☐ Origin criterion stated (e.g., "WO" — wholly obtained; "P" — sufficiently worked)
☐ Gross weight, quantity match packing list
☐ Invoice number and date referenced
☐ BL number referenced (if issued before COO)
☐ Third country declaration (if applicable — some FTAs require this)
☐ Signature and date by authorised exporter official
☐ Authentication by issuing authority (Chamber / Customs / Government body)
☐ If original is required by LC: originals (not copies) presented
☐ COO date: must not pre-date shipment date
☐ Validity: most FTAs require COO to be presented within 12 months of issue
```

---

### 5. Insurance Certificate / Policy

**What it is:** Evidence that cargo insurance has been arranged. Required when seller is responsible for insurance (CIF, CIP Incoterms) or when LC requires it.

**When required:**
- Incoterms CIF or CIP: seller must arrange and provide
- LC transactions: almost always required as a standalone document
- When buyer's country regulations require it

**What it must contain:**

```
INSURANCE CERTIFICATE — REQUIRED FIELDS
─────────────────────────────────────────────────────────
☐ Insured party name (usually the party at risk — buyer under CIF)
☐ Description of goods (matching invoice)
☐ Conveyance (vessel name / flight number)
☐ Port/place of loading to port/place of discharge
☐ Sum insured (must be ≥110% of CIF value per standard trade practice)
☐ Cover type:
    - Institute Cargo Clause A (All Risks — broadest; required for CIP)
    - Institute Cargo Clause B (named perils — intermediate)
    - Institute Cargo Clause C (minimum; standard for CIF)
☐ Policy / certificate number
☐ Date of issue (must not be after date of shipment)
☐ Claims payable at: [Destination — with local settling agent named]
☐ Blank endorsed (if negotiable — for LC)
☐ Insurer name and signature
```

---

## Step 3: Country-Pair Specific Document Requirements

### CHINA → USA 🇨🇳→🇺🇸

**Standard documents:** CI (3 copies) + PL + OBL/seaway bill + COO (non-preferential) + insurance (if CIF)

**Mandatory additional:**

```
☐ ISF 10+2 (Importer Security Filing)
    - Filed by US importer / customs broker
    - Due: 24 hours before vessel loading in China
    - Contents: 10 data elements from importer + 2 from carrier
    - Failure: $5,000 penalty per violation
    - Platform: ACE (Automated Commercial Environment)

☐ ACE Entry (Customs Entry)
    - Filed by licensed US customs broker
    - Type: Formal entry (>$2,500) or informal entry (<$2,500)
    - Duty: Based on HTS code + any Section 301 / AD/CVD duties
    - Bond: Required for formal entries

☐ Section 301 Tariff Assessment
    - Check if product HS code is on List 1, 2, 3, or 4B
    - Current rates: 7.5% – 100% additional duty on affected products
    - Source: USTR Section 301 lists (ustr.gov)

☐ AD/CVD Assessment
    - Check ITC / Commerce Department orders for anti-dumping
    - Common categories: steel, aluminium, solar, chemicals, furniture
    - Source: usitc.gov and commerce.gov

☐ UFLPA Compliance Documentation (if product at risk)
    - Written supply chain disclosure to Tier 2–3
    - Affidavit: no Xinjiang inputs or UFLPA Entity List suppliers
    - Third-party audit / supply chain mapping
    - DNA/isotope testing for cotton products

☐ FDA Prior Notice (for food, beverages, dietary supplements, cosmetics)
    - Filed in FDA Prior Notice System Interface (PNSI)
    - Due: 2–8 hours before arrival (mode-dependent)
    - Penalty: shipment refused or detained if not filed

☐ FDA Registration (for food facilities, drug manufacturers)
    - Exporter must be registered with FDA
    - Registration renewal: every 2 years (even-numbered years)

☐ CPSC Compliance / General Conformity Certificate (GCC)
    - For children's products and other regulated consumer goods
    - Third-party testing required for children's products
    - Must accompany shipment

☐ Lacey Act Declaration (for wood products, plants)
    - Importers of plant/wood products must file PPQ Form 505
    - Declares scientific name, country of harvest, quantity, value

☐ CITES Permit (for wildlife / plant species)
    - If product contains CITES-listed species (ivory, certain woods,
      specific animal products)
    - Import and export permits from both countries' CITES authority
```

---

### CHINA → EU (Germany / Netherlands / Belgium) 🇨🇳→🇪🇺

**Standard documents:** CI + PL + OBL/seaway bill + COO (non-preferential) + insurance (if CIF)

**Mandatory additional:**

```
☐ Single Administrative Document (SAD / Form C88)
    - EU customs declaration; filed by customs broker
    - Required for all commercial imports above €150

☐ EORI Number
    - Both exporter (Chinese side may have EU EORI if DDP)
    - EU importer must have EORI (Economic Operators Registration
      and Identification number)
    - Register at: customs authority of EU member state

☐ CE Declaration of Conformity (for regulated products)
    - Products covered: electronics, machinery, medical devices,
      toys, PPE, construction products, pressure equipment, etc.
    - Must be in language of destination country
    - Technical file must be retained by EU importer for 10 years

☐ CE Marking Physical on Product (where applicable)
    - Must appear on product and packaging before sale in EU
    - Minimum height: 5mm

☐ EU Customs Tariff Classification (TARIC code — 10 digits)
    - 6-digit HS + 4-digit EU addition
    - Check anti-dumping duties: many Chinese product categories
      subject to EU AD duties (steel, ceramics, solar, bicycle parts,
      certain chemicals, textiles)

☐ REX / EUR.1 / Form A (if claiming GSP preference)
    - China is not currently eligible for EU GSP (graduated out 2023)
    - For goods transshipped via GSP-eligible countries: rules of
      origin sufficiency test applies

☐ REACH Declaration (for chemicals, textiles, electronics)
    - Confirmation that substances of very high concern (SVHC)
      are below 0.1% w/w threshold
    - EU importer is responsible; supplier must provide data

☐ RoHS Declaration (for electronics and electrical equipment)
    - Restriction of Hazardous Substances
    - Maximum concentrations: Pb, Hg, Cd, Cr6+, PBBs, PBDEs

☐ EUDR Due Diligence Statement (for relevant commodities)
    - For cattle/leather, cocoa, coffee, palm, soy, wood, rubber
    - Geolocation data + deforestation-free evidence
    - Filed before placing on EU market

☐ CBAM Reporting (for steel, aluminium, cement, fertiliser, electricity)
    - Quarterly reporting during transitional phase (to Dec 2025)
    - CBAM certificate purchase from January 2026
    - Filed by EU importer / CBAM declarant

☐ Food Safety Documents (for food products)
    - Health certificate from Chinese authority (GACC-registered facility)
    - Veterinary certificate (for animal products)
    - RASFF-compliant labelling in destination language
    - EU importer responsible for notification to TRACES (for animal products)
```

---

### INDIA → USA 🇮🇳→🇺🇸

```
Standard + ISF 10+2 + ACE Entry + FDA documents (if applicable) +
CPSC (if applicable)

SPECIFIC INDIA-USA ADDITIONS:
☐ IEC (Import Export Code) on all export documents
    - 10-digit code issued by DGFT (Directorate General of Foreign Trade)
    - Must appear on invoice, shipping bill, and BL

☐ Shipping Bill (Indian Customs Export Declaration)
    - Filed electronically via ICEGATE
    - Mandatory for all exports from India
    - Generates LEO (Let Export Order) — goods cannot load without it

☐ SB (Shipping Bill) number
    - Must be referenced on export documents for RoDTEP/drawback claims

☐ GST Export Documentation
    - If exporting under LUT (Letter of Undertaking): state LUT number
    - If paying IGST on export: obtain IGST refund later via GSTR-1/3B
    - Export invoice must state: "Supply meant for export on payment
      of IGST" OR "Supply meant for export under LUT/bond without
      payment of IGST"

☐ FSSAI Health Certificate (for food products)
    - Issued by Export Inspection Agency (EIA) or accredited lab
    - Required for all food exports

☐ APEDA Registration (for agricultural/food exports)
    - Mandatory for: fresh fruits and vegetables, processed foods,
      animal products, basmati rice, floriculture
    - RCMC (Registration-cum-Membership Certificate) required

☐ Drawback / RoDTEP / EPCG Claim Documentation
    - If claiming any duty drawback or export incentive
    - Shipping Bill must be filed accordingly
    - Bank Realisation Certificate (FIRC) from bank after receipt
```

---

### INDIA → EU 🇮🇳→🇪🇺

```
Standard + EU SAD + EORI + CE (if applicable) + REACH/RoHS (if applicable)

INDIA-EU SPECIFIC:
☐ Form A / GSP Certificate of Origin
    - India remains eligible for EU GSP (check current status — India
      graduated from some categories; verify per product)
    - Issued by Export Inspection Agency (EIA) or authorised agency
    - Alternatively: REX self-certification if India is REX-registered

☐ BIS Certificate (if exporting regulated goods to India is reversed
    — for imports INTO India this is required)

☐ Textile and Garment Documentation (for apparel)
    - OEKO-TEX / GOTS if required by EU buyer
    - Composition label in destination country language

☐ EUDR Documentation (for coffee, spices containing relevant commodities)
    - India is a major exporter of coffee, rubber, and wood products
    - GPS plot coordinates and deforestation-free evidence required
```

---

### CHINA / INDIA / VIETNAM → UK 🇨🇳🇮🇳🇻🇳→🇬🇧

```
POST-BREXIT UK requires separate documentation from EU:

☐ UK Customs Declaration (CHIEF / CDS)
    - Post-Brexit: UK has own customs system
    - Filed by UK customs broker via Customs Declaration Service (CDS)

☐ UK EORI Number (separate from EU EORI)
    - Required for all commercial imports into UK

☐ UK Global Tariff / UK Trade Tariff Commodity Code (10 digits)
    - UK has own tariff schedule post-Brexit (similar to EU but diverging)
    - Check: trade-tariff.service.gov.uk

☐ UK Certificate of Origin (non-preferential)
    - Required for duty assessment and anti-dumping checks

☐ UK Conformity Assessment (UKCA marking) — for regulated products
    - UK equivalent of CE marking
    - Phased introduction: CE marking still accepted in Great Britain
      until end of 2024 (check current status — dates have shifted)
    - UKCA required for goods first placed on GB market after transition

☐ UK Rules of Origin for UK FTAs
    - UK-India FTA (if concluded — check current status)
    - UK-Vietnam FTA (UKVFTA — in force January 2021)
    - UK-ASEAN: bilateral agreements being negotiated
    - UK-Australia / New Zealand FTAs: in force

☐ Northern Ireland Note:
    - Northern Ireland remains under EU customs rules (Windsor Framework)
    - Goods moving GB → NI may face UK internal trade requirements
    - Separate documentation requirements apply
```

---

### VIETNAM / BANGLADESH / INDONESIA → EU 🇻🇳🇧🇩🇮🇩→🇪🇺

```
Standard EU documents +

☐ EVFTA Certificate of Origin (Vietnam → EU) — EUR.1 or REX declaration
    - Vietnam is CPTPP and EVFTA member
    - Significant tariff preference for garments, footwear, electronics

☐ Bangladesh GSP+ / EBA Certificate
    - Bangladesh eligible for Everything But Arms (EBA) — 0% duty
    - Form A required (or REX when Bangladesh transitions)
    - Rules of origin: double transformation for garments
      (yarn → fabric → garment all in Bangladesh)

☐ SMETA / BSCI Audit (for many EU buyers)
    - Not legally required but commercially mandatory for most
      EU fashion, retail, and FMCG buyers

☐ OEKO-TEX / GOTS (for textiles and apparel)
    - Commercially required by many EU buyers
    - Must accompany shipment documentation as attachment to invoice
```

---

### ANY COUNTRY → INDIA (Imports) 🌍→🇮🇳

```
STANDARD IMPORT INTO INDIA:
☐ Bill of Entry (BE)
    - Filed by CHA (Customs House Agent) via ICEGATE
    - Types: Bill of Entry for Home Consumption (white); 
      Bond (yellow); Ex-Bond (green)
    - Must be filed before or at time of arrival

☐ Commercial Invoice (with IEC of Indian importer)

☐ Packing List

☐ Bill of Lading / AWB

☐ Certificate of Origin (with country of origin clearly stated)

☐ Insurance Certificate

☐ Import Licence (for restricted/licensed goods)
    - Mandatory for: certain chemicals, weapons, electronics
      (specific categories), pharmaceuticals, hazmat
    - Check DGFT's ITC(HS) for your HS code

☐ BIS Registration Certificate (for BIS-mandatory products)
    - Mandatory certification for 400+ product categories
    - Categories: electronics, electrical goods, toys, steel,
      cement, automotive parts, medical devices, food contact materials
    - Foreign manufacturer must have BIS licence; Indian importer
      must hold Authorised Indian Representative (AIR) certificate
    - Products without BIS cannot be cleared through Indian customs

☐ FSSAI Licence / NOC (for food products)
    - All food imports require FSSAI clearance
    - Importer must have FSSAI central licence
    - Product labels must comply with FSSAI labelling regulations
    - Some categories require FSSAI port testing before clearance

☐ Plant Quarantine Clearance (for plant material, seeds, wood)
    - PQ Order No. 3, 2003 applies
    - Phytosanitary certificate from origin country required
    - NPPO inspection at Indian port of entry

☐ Wildlife Clearance (CITES) if applicable

☐ Drug Import Licence (for pharmaceuticals)
    - CDSCO (Central Drugs Standard Control Organisation) licence

☐ Radioactive material licence (if applicable — AERB)

☐ E-way Bill (for interstate movement within India after customs clearance)
    - Generated by importer if goods value >INR 50,000

INDIA-SPECIFIC DUTY STRUCTURE:
Basic Customs Duty (BCD): [X]%
Social Welfare Surcharge: 10% of BCD
IGST on import: [5/12/18/28]% on (CIF + BCD + SWS)
Total duty = BCD + SWS + IGST
Note: IGST paid on import is creditable as ITC if importer is GST-registered
```

---

### CHINA / INDIA → AUSTRALIA 🇨🇳🇮🇳→🇦🇺

```
☐ Import Declaration (formal for >AUD 1,000; self-assessed for <AUD 1,000)
    - Filed via Department of Home Affairs / ABF (Australian Border Force)
    - Electronic filing via ICS (Integrated Cargo System)

☐ ABN (Australian Business Number) of importer

☐ Certificate of Origin (for FTA preference)
    - ChAFTA (China-Australia FTA): Certificate of Origin from
      China Council for Promotion of International Trade (CCPIT) or
      China Chamber of Commerce
    - ECTA (Australia-India FTA): Certificate of Origin from
      relevant Indian authority
    - CPTPP: relevant form if exporting from CPTPP member

☐ Biosecurity Import Conditions (BICON)
    - Australia has one of the world's strictest biosecurity regimes
    - Check BICON database (agriculture.gov.au/bicon) for your product
    - Conditions vary: treatment required, permit required, prohibited
    - Categories requiring special attention:
      - All plant material (phytosanitary certificate mandatory)
      - All animal products (veterinary health certificate)
      - Soil or growing media (usually prohibited or heavily restricted)
      - Wood packaging (ISPM 15 heat treatment + marking mandatory)
      - Used machinery / equipment (must be clean, free of soil/organic matter)

☐ AQIS / DAFF Health Certificate (for food products)
    - Imported food must comply with Australia New Zealand Food
      Standards Code
    - Risk-based inspection at port

☐ Australian Consumer Law Compliance
    - Mandatory safety standards for regulated consumer goods
    - Supplier registration for recalls (if applicable)

☐ ACMA Compliance (for electronic / radio equipment)
    - Australian Communications and Media Authority
    - RCM (Regulatory Compliance Mark) required for electrical goods
```

---

### CHINA / INDIA / VIETNAM → MIDDLE EAST (UAE / SAUDI) 🌏→🇦🇪🇸🇦

```
UAE:
☐ Commercial Invoice — certified by Chamber of Commerce + UAE Embassy in origin country
    (Many UAE banks and customs require embassy attestation)

☐ Certificate of Origin — certified by Chamber of Commerce
    (Required for all commercial imports; legalisation often needed)

☐ Packing List

☐ Bill of Lading / AWB

☐ ESMA Conformity Certificate (for regulated products)
    - Emirates Authority for Standardisation and Metrology
    - Mandatory for specific product categories (electronics, food, chemicals, toys)

☐ Halal Certificate (for food, beverages, cosmetics, pharmaceuticals)
    - Required for Muslim-market products
    - Must be issued by UAE-approved Halal certification body
    - Country-specific: different bodies approved for different origin countries

☐ Food Import Permit (for certain food categories)
    - MOCCAE (Ministry of Climate Change and Environment) permit

SAUDI ARABIA (additional to UAE requirements):
☐ SABER Certificate (Saudi Product Safety Programme)
    - Replaces SASO type approval
    - Two components: Product Certificate + Shipment Certificate
    - Product Certificate: based on third-party conformity assessment
    - Shipment Certificate: generated per shipment on SABER portal
    - Mandatory for 600+ product categories (electronics, appliances,
      construction materials, toys, textiles, food contact, cosmetics)
    - Without SABER: goods held at Saudi port indefinitely

☐ Saudi Halal Accreditation Authority (HAC) approval (for food)

☐ SFDA Registration (for food, pharmaceuticals, medical devices)

☐ Arab-specific Certificate of Origin (separate from standard COO)
    - Required for claiming Arab trade agreement preferences
    - Issued by Arab Chamber of Commerce

☐ Iqama / Agent details (for commercial imports — Saudi importer
    must be Saudi entity or have Saudi commercial agent)
```

---

## Step 4: Transport Mode Specific Documents

### Air Freight Specific

```
AIR FREIGHT DOCUMENT SET
─────────────────────────────────────────────────────────
☐ Master Airway Bill (MAWB) — issued by airline
☐ House Airway Bill (HAWB) — issued by freight forwarder (if applicable)
☐ Air Cargo Manifest — airline's consolidated cargo list
☐ Shipper's Declaration for Dangerous Goods
    - Required for any hazardous material per IATA DGR (Dangerous Goods Regulations)
    - Must be completed by trained and certified staff
    - Only approved DG can fly; many categories prohibited on passenger aircraft
☐ Customs Air Cargo Advance Screening (ACAS) — for US-bound air cargo:
    - Air cargo data must be pre-screened by CBP before loading
    - Filed by airlines and freight forwarders
☐ IATA e-Air Waybill (e-AWB) — now industry standard for most lanes
```

### Courier / Express (DHL, FedEx, UPS)

```
COURIER SHIPMENT DOCUMENTS
─────────────────────────────────────────────────────────
☐ Commercial Invoice (electronic, 3 copies)
    - Value must be accurate — courier companies face fines for undervaluation
    - "Gift" and "no commercial value" declarations on commercial shipments
      are customs fraud — do not do this
☐ Packing List
☐ Courier Airway Bill (generated by courier company)
☐ Customs declaration (CN22 / CN23 for postal; carrier's declaration for express)
☐ All special permits, certificates as required for product/destination
☐ De minimis thresholds:
    - USA: $800 (duty-free informal entry)
    - EU: €150 (above = VAT + duty)
    - UK: £135 (customs duty threshold)
    - India: INR 5,000 (de minimis)
    - Australia: AUD 1,000
    - Note: Some countries have eliminated de minimis for e-commerce
```

### Road Freight (Europe)

```
ROAD FREIGHT — EUROPE
─────────────────────────────────────────────────────────
☐ CMR (Convention on the Contract for the Carriage of Goods by Road)
    - International road consignment note
    - 4 originals: 1 sender / 1 consignee / 1 carrier / 1 travels with goods
☐ TIR Carnet (Transit International Routier)
    - For sealed road transit through multiple countries without intermediate
      customs examination
    - Issued by IRU-affiliated national associations
☐ ATA Carnet (for temporary imports — trade fairs, samples, equipment)
☐ T1 / T2 Transit Document (intra-EU or EU-UK transit)
☐ EUR.1 (for FTA preference claims on road movements)
☐ Phytosanitary / Veterinary certificates (for relevant goods)
☐ ADR (transport of dangerous goods by road — European Agreement)
    - Driver must have ADR training certificate
    - Vehicle must be ADR-compliant
    - Multimodal Dangerous Goods Form required
```

---

## Step 5: Product-Specific Additional Documents

### Food and Agricultural Products

```
FOOD / AGRI — ADDITIONAL DOCUMENTS
─────────────────────────────────────────────────────────
☐ Phytosanitary Certificate
    - For all plant and plant products (fruits, vegetables, seeds,
      plants, wood, cut flowers, grains)
    - Issued by: National Plant Protection Organisation (NPPO) of
      exporting country
    - India: Plant Protection Adviser (PPA), NPPO India
    - China: GACC / AQSIQ
    - Contains: list of pests/diseases absent; treatment if applicable
    - Valid for: varies by country (typically 14–30 days)
    - Original only; faxed/scanned copies not accepted at many ports

☐ Veterinary Health Certificate / Sanitary Certificate
    - For all animal products (meat, dairy, eggs, fish, honey,
      animal feed, skins, wool)
    - Issued by: official veterinarian of exporting country's government
    - Must match exactly with destination country's import requirements
    - USA: FSIS (Food Safety and Inspection Service) for meat
    - EU: TRACES platform; harmonised veterinary certificates

☐ Certificate of Analysis (CoA)
    - Laboratory test results confirming composition, purity, safety
    - Required for: food, feed, chemicals, pharma, nutraceuticals
    - Test parameters must match importing country's standards

☐ Health Certificate
    - Combined with CoA or standalone; confirms product is fit for
      human/animal consumption

☐ CITES Permit (for endangered species of plants or animals)
    - Appendix I: commercial trade prohibited
    - Appendix II: trade permitted with permits
    - Appendix III: limited protection with COO

☐ Fumigation Certificate (for wood packaging and certain goods)
    - ISPM 15: International Standards for Phytosanitary Measures No. 15
    - All wooden packaging (pallets, crates, dunnage) must be:
      - Heat treated to 56°C for 30 minutes core temperature, OR
      - Methyl bromide fumigated (being phased out)
    - Must bear official ISPM 15 mark: wheat sheaf symbol + country code +
      producer code + treatment code
    - Note: solid wood packing materials without ISPM 15 mark = automatic
      refusal at many ports; fumigation and re-inspection at importer's cost

☐ Organic Certificate (for organic-certified products)
    - Must be from an accredited body recognised by importing country
    - USA: NOP (National Organic Program) — USDA
    - EU: must be from EU-approved certification body
    - India: NPOP / PGS-India
```

### Chemicals and Hazardous Materials

```
CHEMICALS / HAZMAT — ADDITIONAL DOCUMENTS
─────────────────────────────────────────────────────────
☐ Material Safety Data Sheet (MSDS) / Safety Data Sheet (SDS)
    - Required for all chemicals, hazardous goods, and many
      industrial materials
    - Must be in language of destination country
    - GHS (Globally Harmonised System) format required in most countries
    - 16-section format per GHS/SDS standards
    - Labelling must match SDS

☐ Dangerous Goods Declaration
    - For hazardous goods classified under IMDG (sea), IATA DGR (air),
      or ADR (road)
    - Must include: UN number, proper shipping name, hazard class,
      packing group, quantity, packaging type
    - Shipper must be DG-trained and declaration must be signed

☐ Chemical Import Licence / Permit
    - Many countries require specific licences for chemicals:
    - India: CIB&RC registration for pesticides; PCB NOC for hazmat
    - USA: TSCA (Toxic Substances Control Act) certification
    - EU: ECHA registration / notification under REACH

☐ Controlled Substance / Narcotic Permit
    - For precursor chemicals or scheduled substances
    - International Narcotics Control Board (INCB) permits

☐ Radioactive Material Licence
    - IAEA documentation; national nuclear authority permits

☐ Basel Convention Documentation
    - For transboundary movement of hazardous waste
    - Prior informed consent from receiving country required
```

### Textiles and Apparel

```
TEXTILES / APPAREL — ADDITIONAL DOCUMENTS
─────────────────────────────────────────────────────────
☐ Textile Visa (for USA imports under MFA/WTO safeguard categories)
    - Some categories still require export visas from some origins

☐ Fibre Content Certificate / Composition Declaration
    - Mandatory for USA (FTC Textile Fiber Products Identification Act)
    - Mandatory for EU (Textile labelling Regulation 1007/2011)
    - Must state exact fibre composition (% by weight for each fibre)

☐ Country of Origin for Textiles (USA)
    - Must be labelled "Made in [Country]" per FTC rules
    - Country of origin = where fabric was cut and sewn (substantial transformation)

☐ Flammability Test Report
    - USA: CPSC requirements for children's sleepwear
    - EU: EN 13501 for furnishing fabrics
    - Specific categories: mattresses, bedding, upholstered furniture

☐ GOTS / OEKO-TEX / BCI Certificate (if organic/sustainable claim)
    - Must be valid and from accredited body
    - Cannot claim without documentation

☐ RMG/RSC Declaration (Bangladesh: Ready-Made Garment)
    - BGMEA / BKMEA membership certificate
    - Utilisation Declaration for bonded warehouse goods
```

### Pharmaceutical and Medical Devices

```
PHARMA / MEDICAL — ADDITIONAL DOCUMENTS
─────────────────────────────────────────────────────────
☐ Drug Registration Certificate / Marketing Authorisation
    - Must be registered in destination country
    - USA: FDA NDA/ANDA/510(k) as applicable
    - EU: EMA/national competent authority
    - India: CDSCO approval

☐ GMP Certificate (Good Manufacturing Practice)
    - Issued by exporting country's drug regulatory authority
    - Some countries accept WHO-GMP; others require bilateral recognition

☐ Certificate of Pharmaceutical Product (CPP)
    - WHO model certificate confirming product is authorised for sale
      in exporting country
    - Required by many importing countries' drug authorities

☐ Import Drug Licence (destination country)
    - USA: FDA import alert check; no banned manufacturers
    - India: CDSCO import licence for Schedule X drugs and biologics
    - EU: Qualified Person (QP) release for imported medicines

☐ Medical Device Registration (destination country)
    - USA: FDA 510(k) clearance or PMA
    - EU: CE marking + Notified Body certificate
    - India: CDSCO licence (Form MD-15 for import)

☐ Free Sale Certificate (FSC) / Certificate of Free Sale
    - Confirms product is legally sold in exporting country without restriction
    - Required by many importing countries for food supplements, cosmetics,
      medical devices

☐ Cold Chain Documentation (temperature-sensitive)
    - Temperature monitoring records (data logger printout)
    - Temperature excursion report if applicable
    - Validated cold chain specification
```

### Timber and Wood Products

```
TIMBER / WOOD — ADDITIONAL DOCUMENTS
─────────────────────────────────────────────────────────
☐ FSC Certificate / PEFC Certificate (if certified wood)
    - Chain of Custody certificate for all parties in supply chain
    - Required by many buyers and increasingly by regulation

☐ EUDR Due Diligence Statement (for EU market)
    - GPS coordinates of forest plots
    - Deforestation-free evidence
    - Filed via EU information system before placing on EU market

☐ Lacey Act Declaration (USA) — PPQ Form 505
    - Scientific name of tree species
    - Country of harvest
    - Name of forest management unit / harvest region
    - Quantity and value
    - Responsibility on US importer

☐ CITES Permit (for protected timber species)
    - Appendix II species: Brazilian rosewood, bigleaf mahogany,
      ebony (some species), ramin, etc.
    - Appendix I: commercial trade prohibited

☐ Phytosanitary Certificate (for sawn timber, logs, bark)
    - ISPM 15 for wood packaging (see above)
    - Additional treatment certificates for some importing countries

☐ Indian State Government Permits (for Indian timber exports)
    - Many Indian timber species require state/central government permits
    - Teak: strictly regulated; export requires Forest Department NOC
```

---

## Step 6: Letter of Credit Document Compliance

When payment is by LC, document compliance is absolute — banks pay on documents, not on goods. A single discrepancy = non-payment until corrected.

### LC Document Checklist

```
LC DOCUMENT COMPLIANCE CHECKLIST
─────────────────────────────────────────────────────────
LC Number: _____________  Expiry Date: _______________
Last date for shipment: _____________
Presentation period: ___ days after BL date

BEFORE PREPARING DOCUMENTS — READ LC CAREFULLY FOR:
☐ Exact name of beneficiary (must match invoice exactly — no abbreviation)
☐ Exact name of applicant/buyer (must match invoice exactly)
☐ Goods description (LC may specify exact wording — use it verbatim)
☐ Port of loading (may restrict to specific port)
☐ Port of discharge (may restrict)
☐ Partial shipments: allowed or prohibited?
☐ Transhipment: allowed or prohibited?
☐ Latest shipment date
☐ Document presentation period
☐ Number of originals required for each document
☐ Specific clauses (e.g., "third-party documents acceptable" or not)
☐ Inspection certificate required — by whom?

DOCUMENT MATCHING RULES (UCP 600):
☐ All documents must show same merchandise description
    (Invoice description can be detailed; other docs must not contradict)
☐ Beneficiary name identical across all documents
☐ Applicant name identical across all documents where required
☐ LC number shown on each document (check if LC requires this)
☐ Dates consistent: BL date ≤ latest shipment date; 
    documents presented within LC presentation period

COMMON LC DISCREPANCIES TO AVOID:
1. Late presentation (beyond presentation period after BL date)
2. Late shipment (BL date after LC's latest shipment date)
3. Short shipment (quantity less than LC stipulates)
4. Over-shipment (quantity more than LC permits — check if allowed)
5. Inconsistent goods description across documents
6. Missing documents (especially COO or inspection certificate)
7. Unsigned or incorrectly signed documents
8. "Freight collect" on BL when LC requires "freight prepaid"
9. BL marked "on deck" when LC requires "under deck"
10. Insurance certificate for wrong amount (must be min. 110% CIF)
11. Dirty BL (any notation about damaged or missing cargo)
12. Third-party BL when LC requires beneficiary as shipper
```

---

## Step 7: Customs Hold Resolution Guide

When a shipment is detained, held, or queried by customs:

```
CUSTOMS HOLD RESPONSE PROTOCOL
─────────────────────────────────────────────────────────
Step 1: Get the hold reason in writing
    - Request written notice of detention reason
    - Common reasons: document deficiency / value query /
      classification dispute / restricted goods / inspection /
      UFLPA / regulatory non-compliance

Step 2: Match reason to resolution path

DOCUMENT DEFICIENCY HOLD:
    - Identify missing or incorrect document
    - Obtain corrected document from supplier / forwarder / authority
    - Note: some documents (phytosanitary, fumigation) cannot be
      retroactively issued — goods may need re-inspection or treatment
      at port of entry at importer's cost

VALUE QUERY:
    - Provide proof of purchase: bank transfer records, LC, invoice history
    - Provide market comparables showing declared value is correct
    - Prepare: purchase order, prior shipment invoices at same price,
      market price research
    - Warning: customs has right to re-assess value upward; you pay duty
      on customs' assessed value, not your declared value

CLASSIFICATION DISPUTE:
    - Obtain binding tariff ruling if possible (advance ruling)
    - Prepare technical documents: product composition, manufacturing process,
      function, end use
    - Cite WCO HS classification opinions or prior rulings if helpful
    - Consider engaging customs lawyer if duty difference is material

RESTRICTED / PROHIBITED GOODS:
    - Consult customs lawyer immediately
    - Options: re-export, destruction, abandonment
    - Voluntary abandonment may avoid penalties in some jurisdictions

INSPECTION / EXAMINATION SELECTED:
    - Request examination appointment
    - Ensure you or customs broker is present or represented
    - Containers may be opened and repacked at importer's expense
    - Request examination report in writing

UFLPA HOLD (US imports):
    - Request CBP Field Operations contact information
    - Engage customs lawyer with UFLPA experience immediately
    - Prepare: complete supply chain mapping to raw material;
      supplier certifications; affidavits; test results
    - Timeline: 30 days to respond; goods may be seized if not responded
    - Rebuttal standard is "clear and convincing evidence"

Step 3: Track costs
    - Demurrage (container storage) accrues daily — resolve quickly
    - Document all detention costs for potential supplier recovery
    - Check contract: is supplier liable for costs of documentation failure?
```

---

## Step 8: Pre-Shipment Document Checklist — Final Gate

Issue this to the supplier or freight forwarder before cargo loads:

```
PRE-SHIPMENT DOCUMENT VERIFICATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PO Number: ____________  Shipment Date: _______________
Supplier: _____________  Forwarder: __________________
Origin: _______________  Destination: ________________
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

UNIVERSAL (every shipment)
☐ Commercial Invoice — correct, signed, stamped
☐ Packing List — matches invoice quantities and weights
☐ Bill of Lading / AWB draft — reviewed and approved by buyer
☐ Certificate of Origin — correct type, authenticated
☐ Insurance Certificate — if CIF/CIP; value ≥110% CIF

DESTINATION-SPECIFIC (check against country requirements above)
☐ [Country-specific document 1]
☐ [Country-specific document 2]
☐ [Country-specific document 3]

PRODUCT-SPECIFIC
☐ [Product certification / permit 1]
☐ [Product certification / permit 2]
☐ [Test report / CoA]

PAYMENT METHOD
☐ LC: all documents match LC terms exactly (use LC compliance checklist)
☐ DP/DA: documents sent via bank per collection instructions
☐ TT: documents sent directly to buyer after shipment

TRANSPORT
☐ ISPM 15 wood packaging (if any wood packing used)
☐ Dangerous goods declaration (if hazmat)
☐ ISF filed (US-bound only, 24hr before loading)

CROSS-CHECKS — ALL DOCUMENTS
☐ Same goods description across all documents
☐ Same quantity (pcs/kg) across invoice, packing list, BL
☐ Same weight (gross) across packing list and BL
☐ Same port of loading across all documents
☐ Same consignee name across all documents
☐ PO number referenced on all documents
☐ No unsigned documents
☐ No expired certificates
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Verified by: _____________ Date: _______________
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Related Skills
- `tariff-hs-lookup` — HS code classification determines which documents are needed and what duty applies
- `incoterms-advisor` — Incoterms determine who prepares which documents and who pays freight/insurance
- `esg-compliance-audit` — UFLPA, EUDR, CBAM documents are ESG compliance documents
- `rfq-drafting` — document requirements should be specified in the RFQ and PO before supplier quotes
- `purchase-order-generator` — required documents should be listed in every PO
- `freight-cost-calculator` — transport mode determines which transport documents apply
- `resilience-geopolitical-radar` — new regulations and enforcement actions change document requirements
- `sourcing-project-context` — destination markets, certifications, and special requirements stored here
