---
name: supplier-performance-scorecard
description: Use this skill when the user wants to track, measure, score, or review supplier performance over time. Also trigger when the user says "how is my supplier performing", "create a supplier scorecard", "rate my suppliers", "supplier KPIs", "supplier report card", "OTIF tracking", "on-time delivery", "quality rejection rate", "supplier ranking", "annual supplier review", "supplier tiering", "preferred supplier status", "put supplier on watch", "issue a corrective action", "CAPA to supplier", "supplier is underperforming", "which suppliers should I keep", "supplier development plan", "supplier awards", or "consolidate my supplier base". Works for any product category, any country, any supplier relationship stage. Produces monthly scorecards, quarterly review packs, annual supplier ratings, CAPA letters, development plans, and supplier tiering decisions.
---

# Supplier Performance Scorecard

Tracks, measures, and manages supplier performance using structured KPIs — from individual monthly scorecards to annual strategic reviews and supplier tiering. Turns raw delivery, quality, and commercial data into decisions: develop, maintain, escalate, or exit.

**Core philosophy:** You cannot manage what you do not measure. A supplier who knows they are being scored performs better than one who isn't. A buyer who can show data wins every negotiation, escalation, and boardroom discussion.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Extract: active supplier list, product categories, quality standards, approved supplier list (ASL), and any known performance issues.

---

## Step 1: Mode Selection

Ask the user which output they need:

| Mode | When to use | Output |
|------|-------------|--------|
| **Single supplier scorecard** | Monthly or quarterly review of one supplier | Full scorecard with scores and actions |
| **Multi-supplier comparison** | Ranking all suppliers in a category | Comparative table + tiering decision |
| **Annual strategic review** | Full-year performance + forward plan | Review pack with development roadmap |
| **CAPA issuance** | Supplier has failed on a KPI | Corrective action letter + tracking plan |
| **Supplier tiering** | Reclassifying supplier status | Tier recommendation with rationale |
| **Development plan** | Improving a key supplier | 90-day improvement roadmap |
| **Exit assessment** | Evaluating whether to discontinue | Risk-weighted exit recommendation |

---

## Step 2: KPI Framework

### The Five Performance Dimensions

Every supplier is measured across five dimensions. Weights can be adjusted by category (see Step 3).

---

### Dimension 1: Delivery Performance (25% default weight)

**OTIF — On Time In Full**

The master delivery KPI. Measures whether the supplier delivered the right quantity at the right time.

```
OTIF % = (Orders delivered on time AND in full) ÷ (Total orders) × 100
```

| OTIF Score | Rating | Points |
|------------|--------|--------|
| 98–100% | Excellent | 10 |
| 95–97% | Good | 8 |
| 90–94% | Acceptable | 6 |
| 85–89% | Below standard | 4 |
| 80–84% | Poor | 2 |
| <80% | Critical failure | 0 |

**Supporting delivery KPIs:**

| KPI | Formula | Target |
|-----|---------|--------|
| On-Time Rate (OTR) | Orders on time ÷ Total orders | ≥97% |
| In-Full Rate (IFR) | Orders in full quantity ÷ Total orders | ≥99% |
| Average days late | Sum of late days ÷ Late orders | ≤2 days |
| Lead time adherence | Actual lead time ÷ Quoted lead time | ≤105% |
| Order acknowledgement time | Days from PO to supplier confirmation | ≤2 business days |
| Advance ship notice (ASN) | % orders with ASN issued before shipment | ≥95% |

**Late delivery classification:**
- 1–3 days late: Minor delay — no scorecard penalty if communicated in advance
- 4–7 days late: Moderate delay — partial penalty
- 8–14 days late: Significant delay — full penalty + corrective action required
- 15+ days late: Critical — CAPA + performance review meeting required

---

### Dimension 2: Quality Performance (25% default weight)

**Incoming Quality Rate (IQR) / Acceptance Rate**

```
IQR % = (Lots accepted on first inspection) ÷ (Total lots inspected) × 100
```

| IQR Score | Rating | Points |
|-----------|--------|--------|
| 99–100% | Excellent | 10 |
| 97–98% | Good | 8 |
| 95–96% | Acceptable | 6 |
| 92–94% | Below standard | 4 |
| 88–91% | Poor | 2 |
| <88% | Critical failure | 0 |

**Supporting quality KPIs:**

| KPI | Formula | Target |
|-----|---------|--------|
| Defect Rate (PPM) | (Defective units ÷ Total units) × 1,000,000 | ≤500 PPM |
| Lot Acceptance Rate | Lots accepted ÷ Lots inspected | ≥97% |
| First Article Acceptance | First articles passed ÷ Submitted | 100% |
| Field failure / warranty claims | Claims attributable to supplier ÷ Units shipped | ≤0.1% |
| Corrective action close rate | CAPAs closed on time ÷ CAPAs issued | ≥90% |
| Repeat defect rate | Same defect recurrence within 90 days | 0% target |
| Documentation accuracy | Correct COAs/test reports on first submission | ≥99% |

**Quality event classification:**
- Minor: Cosmetic defect, AQL 4.0 level, contained, no customer impact
- Major: Functional defect, AQL 2.5 breach, potential customer impact
- Critical: Safety defect, regulatory non-conformance, customer field failure
- Systemic: Same defect appearing in 3+ consecutive lots

---

### Dimension 3: Commercial Performance (20% default weight)

**Price Competitiveness**

```
Price Index = Supplier's price ÷ Market benchmark price × 100
(Below 100 = competitive; above 100 = above market)
```

| Price Index | Rating | Points |
|-------------|--------|--------|
| ≤95 (5%+ below market) | Excellent | 10 |
| 96–100 (at or below market) | Good | 8 |
| 101–105 (1–5% above market) | Acceptable | 6 |
| 106–110 (5–10% above market) | Below standard | 4 |
| 111–115 (10–15% above market) | Poor | 2 |
| >115 (15%+ above market) | Not competitive | 0 |

**Supporting commercial KPIs:**

| KPI | Definition | Target |
|-----|-----------|--------|
| Invoice accuracy | Invoices matching PO without dispute ÷ Total invoices | ≥99% |
| Price change requests | Unplanned price increase requests in period | 0 preferred |
| Payment terms compliance | Invoices within agreed payment terms | 100% |
| Quote response time | Days to return RFQ response | ≤5 business days |
| Quote accuracy | Quotes that convert to order without re-negotiation | ≥80% |
| Year-on-year cost movement | Price change vs. prior year (negative = reduction) | ≤CPI |
| Cost savings initiatives | Supplier-initiated cost reduction ideas implemented | Track annually |

---

### Dimension 4: Responsiveness & Communication (15% default weight)

The softest KPI dimension but often the most predictive of future problems. Unresponsive suppliers create hidden operational costs — time spent chasing, expediting, and managing uncertainty.

**Responsiveness scoring:**

| KPI | Excellent (10) | Good (8) | Acceptable (6) | Poor (2) |
|-----|---------------|----------|----------------|---------|
| Email/message response time | <4 hours | <24 hours | <48 hours | >48 hours |
| Issue escalation speed | <2 hours | <8 hours | <24 hours | >24 hours |
| Proactive communication (delays, shortages) | Always | Usually | Sometimes | Rarely |
| Sample/prototype turnaround | Ahead of schedule | On schedule | ≤5 days late | >5 days late |
| Reporting compliance | All reports on time | 1–2 late | 3–5 late | Frequent misses |
| Meeting attendance | Always present, prepared | Usually prepared | Sometimes unprepared | Frequently absent |

**Composite responsiveness score:**
Average across all applicable KPIs × 10 = Responsiveness score (0–100).

---

### Dimension 5: Compliance & Sustainability (15% default weight)

**Certifications and regulatory compliance**

| KPI | Scoring |
|-----|---------|
| Required certifications valid and current | 10 pts if all valid; -2 per expired/missing cert |
| Social compliance audit (SMETA/SA8000/WRAP) | 10 = passed; 6 = passed with minor; 2 = corrective actions outstanding; 0 = failed |
| Environmental compliance (ISO 14001/equivalent) | 10 = certified; 6 = in progress; 2 = not started; 0 = non-compliant |
| Forced labour/child labour policy | 10 = clean; 0 = any finding = automatic scorecard failure |
| Country of origin documentation | 10 = always accurate; deduct 2 per discrepancy found |
| Chemical compliance (REACH/RoHS/Prop 65) | 10 = all tested and documented; deduct per missing certificate |
| ESG reporting | 10 = annual ESG report submitted; 6 = partial data; 2 = requested but not provided |
| Business continuity plan | 10 = documented and tested; 6 = documented; 2 = none |

**Automatic disqualification triggers (regardless of total score):**
- Any confirmed instance of child labour or forced labour
- Knowingly falsified test reports or certificates
- Unresolved critical regulatory non-conformance >90 days
- Criminal investigation or sanctions against the entity

---

## Step 3: Category Weight Adjustments

Different product categories and supply relationships warrant different weightings. Adjust from defaults:

| Category profile | Delivery | Quality | Commercial | Responsiveness | Compliance |
|-----------------|----------|---------|------------|---------------|------------|
| **Default** | 25% | 25% | 20% | 15% | 15% |
| **Critical / sole-sourced** | 30% | 30% | 10% | 20% | 10% |
| **Food / pharma / medical** | 20% | 35% | 10% | 10% | 25% |
| **Commodity / raw material** | 25% | 20% | 30% | 15% | 10% |
| **Fashion / seasonal** | 35% | 20% | 20% | 20% | 5% |
| **Compliance-sensitive (ESG markets)** | 20% | 20% | 15% | 10% | 35% |
| **Capital equipment / tooling** | 15% | 30% | 20% | 20% | 15% |
| **Bio-materials / sustainable goods** | 20% | 20% | 15% | 10% | 35% |

Ask the user to confirm or adjust weights before scoring.

---

## Step 4: Score Calculation

### Composite Score Formula

```
Composite Score = 
  (Delivery score × Delivery weight) +
  (Quality score × Quality weight) +
  (Commercial score × Commercial weight) +
  (Responsiveness score × Responsiveness weight) +
  (Compliance score × Compliance weight)

Maximum = 100 points
```

### Performance Bands

| Band | Score | Status | Management action |
|------|-------|--------|-------------------|
| 🏆 Platinum | 90–100 | Strategic Partner | Preferred status, longer contracts, early access to innovation |
| 🥇 Gold | 80–89 | Preferred Supplier | Increased volume, annual recognition |
| 🥈 Silver | 70–79 | Approved Supplier | Maintain; quarterly review |
| 🟡 Bronze | 60–69 | On Watch | Improvement plan required; 90-day review |
| 🔴 Red | 50–59 | Probationary | Formal CAPA; sourcing alternatives |
| ⛔ Critical | <50 | Exit candidate | Immediate escalation; dual-source or exit |

---

## Step 5: Scorecard Output

### Monthly / Quarterly Scorecard Template

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SUPPLIER PERFORMANCE SCORECARD
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Supplier:          [Name]                Country: [Country]
Category:          [Product category]
Review period:     [Month/Quarter Year]
Buyer:             [Name]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PERFORMANCE SUMMARY
───────────────────────────────────────────────────
Dimension           Weight   Score   Weighted   Trend
─────────────────── ──────── ─────── ────────── ──────
Delivery            25%      XX/100  XX.X       ↑/↓/→
Quality             25%      XX/100  XX.X       ↑/↓/→
Commercial          20%      XX/100  XX.X       ↑/↓/→
Responsiveness      15%      XX/100  XX.X       ↑/↓/→
Compliance          15%      XX/100  XX.X       ↑/↓/→
─────────────────── ──────── ─────── ────────── ──────
COMPOSITE SCORE              XX/100             ↑/↓/→
STATUS:             [🏆 Platinum / 🥇 Gold / 🥈 Silver / 🟡 Bronze / 🔴 Probationary / ⛔ Critical]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DELIVERY DETAIL
───────────────────────────────────────────────────
Total orders in period:       [N]
On Time In Full (OTIF):       [X]%     Target: ≥97%
On-Time Rate:                 [X]%
In-Full Rate:                 [X]%
Average days late:            [X] days
Late orders (details):
  - PO [number]: [X] days late — reason: [reason]
  - PO [number]: [X] days late — reason: [reason]
───────────────────────────────────────────────────

QUALITY DETAIL
───────────────────────────────────────────────────
Lots inspected:               [N]
Lots accepted first pass:     [N] ([X]%)
Defect rate:                  [X] PPM
Quality events this period:
  Minor:    [N]  Major:  [N]  Critical:  [N]
Open CAPAs:                   [N] (oldest: [X] days open)
Warranty claims:              [N] ([X]% of shipments)
───────────────────────────────────────────────────

COMMERCIAL DETAIL
───────────────────────────────────────────────────
Current contracted price:     $[X.XX] [Incoterms]
Market benchmark:             $[X.XX]
Price index:                  [X]% [above/below] market
Invoicing accuracy:           [X]%
Price changes requested:      [N] ([accepted/rejected])
Cost savings initiatives:     [Description or "None this period"]
───────────────────────────────────────────────────

RESPONSIVENESS DETAIL
───────────────────────────────────────────────────
Avg. email response time:     [X] hours
Issues escalated proactively: [Y/N — examples]
Reports submitted on time:    [X]%
Meeting attendance:           [X]%
───────────────────────────────────────────────────

COMPLIANCE DETAIL
───────────────────────────────────────────────────
Certifications status:        [All valid / [X] expiring / [X] expired]
Last social audit:            [Date] — Result: [Pass/Conditional/Fail]
Environmental certification:  [ISO 14001 / Equivalent / None]
Open compliance findings:     [N] ([X] days oldest)
───────────────────────────────────────────────────

PERIOD HIGHLIGHTS
✅ Strengths:
  1. [Specific achievement this period]
  2. [Specific achievement]

⚠️ Concerns:
  1. [Specific concern with data]
  2. [Specific concern]

🚨 Critical issues:
  1. [If any — specific event, date, impact]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ACTION PLAN
───────────────────────────────────────────────────
# | Action                    | Owner    | Due Date  | Priority
──┼───────────────────────────┼──────────┼───────────┼─────────
1 | [Action]                  | Supplier | [Date]    | [H/M/L]
2 | [Action]                  | Buyer    | [Date]    | [H/M/L]
3 | [Action]                  | Both     | [Date]    | [H/M/L]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Next review:    [Date]
Scorecard issued by:  [Name]     Date: [Date]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 6: Multi-Supplier Comparison & Tiering

When reviewing all suppliers in a category simultaneously:

### Comparative Table

```
SUPPLIER PERFORMANCE COMPARISON — [Category] — [Period]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Supplier         Country  Delivery Quality Comm.  Resp.  Compl.  TOTAL   Tier     Trend
──────────────── ──────── ──────── ─────── ─────── ────── ─────── ─────── ──────── ──────
[Supplier A]     China    24.0     22.5    17.0    13.0   13.5    90.0    Platinum  ↑
[Supplier B]     India    21.0     20.0    18.0    12.0   12.0    83.0    Gold      →
[Supplier C]     Vietnam  18.0     18.0    15.0    10.0   10.0    71.0    Silver    ↓
[Supplier D]     Turkey   15.0     15.0    14.0    9.0    8.0     61.0    Bronze    ↓
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TIERING DECISIONS
─────────────────────────────────────────────────────────────────
Supplier A → PLATINUM: Preferred — increase volume allocation, offer extended contract
Supplier B → GOLD: Maintain — annual review, commercial negotiation opportunity
Supplier C → SILVER: Monitor — deteriorating trend; schedule performance review call
Supplier D → BRONZE: On Watch — 90-day improvement plan; begin dual-source evaluation
─────────────────────────────────────────────────────────────────
```

### Volume Allocation Recommendation

Based on performance scores, recommend volume distribution:

```
RECOMMENDED VOLUME ALLOCATION — [Category]
─────────────────────────────────────────────────────
Supplier    Score    Current %   Recommended %   Change
─────────── ──────── ─────────── ─────────────── ──────
Supplier A  90       30%         45%             +15%  ← reward performance
Supplier B  83       35%         35%             0%    ← maintain
Supplier C  71       25%         15%             -10%  ← reduce exposure
Supplier D  61       10%         5%              -5%   ← minimum while on watch
─────────────────────────────────────────────────────
Rationale: Volume allocated proportionally to performance score, 
with Platinum suppliers receiving disproportionate uplift as reward signal.
```

---

## Step 7: CAPA Issuance

When a supplier scores below threshold on any dimension or has a critical quality/delivery event, issue a formal Corrective Action and Preventive Action (CAPA) letter.

### CAPA Trigger Thresholds

| Trigger | Automatic action |
|---------|-----------------|
| OTIF <90% for 2 consecutive periods | CAPA — delivery |
| Defect rate >1,000 PPM in any period | CAPA — quality |
| Critical quality event (safety defect, field failure) | Immediate CAPA + hold |
| Compliance finding (expired cert, audit failure) | CAPA — compliance |
| Invoice dispute rate >3% | CAPA — commercial |
| Composite score <60 for 2 consecutive periods | Full performance CAPA |
| Composite score <50 in any single period | Escalation + CAPA |

### CAPA Letter Template

```
CORRECTIVE ACTION AND PREVENTIVE ACTION REQUEST
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CAPA Reference:    CAPA-[YYYYMMDD]-[Supplier Code]-[Sequence]
Date issued:       [Date]
Supplier:          [Name], [Address], [Country]
Contact:           [Name, Title, Email]
Category:          [Quality / Delivery / Commercial / Compliance]
Severity:          [Minor / Major / Critical]
Response required by: [Date — 5 business days for Critical, 10 for Major, 15 for Minor]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. DESCRIPTION OF NON-CONFORMANCE
───────────────────────────────────────────────────
Event date(s):     [Date(s)]
PO/Lot reference:  [Reference]
Description:       [Factual description of what happened]

Evidence:
  - [Test report / Inspection report / Delivery record — reference number]
  - [Photo / Document reference]

Impact:
  - Internal: [Rework cost, production stoppage, planning disruption]
  - Customer: [Customer complaint, line stop, recall risk]
  - Financial: [Estimated cost of non-conformance: $X,XXX]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

2. IMMEDIATE CONTAINMENT REQUIRED
───────────────────────────────────────────────────
By [Date] (within [X] business days of this CAPA):

☐ Quarantine and inspect all inventory of [Part/Product] currently at buyer's facility
☐ Place hold on any in-transit shipments pending inspection
☐ Stop shipment of further product until root cause confirmed
☐ Provide replacement [units/lot] by [date]
☐ Other: [Specific containment action]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

3. ROOT CAUSE ANALYSIS REQUIRED
───────────────────────────────────────────────────
Required methodology: [5-Why / Fishbone / FMEA — select based on severity]
Supplier must identify:
  a) What happened (the defect/failure)
  b) Why it happened (root cause — not symptoms)
  c) Why it was not detected before shipment (escape cause)
  d) What systemic condition allowed this to occur

Submit root cause analysis by: [Date]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

4. CORRECTIVE AND PREVENTIVE ACTIONS REQUIRED
───────────────────────────────────────────────────
Supplier to propose specific corrective actions addressing:
  a) Immediate correction of the specific non-conformance
  b) Process change to prevent recurrence
  c) Detection improvement to catch similar issues before shipment
  d) Verification method and timeline to confirm effectiveness

Include for each action:
  - Specific action description
  - Responsible person and title
  - Target completion date
  - Evidence of completion (what will be provided to buyer)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

5. CAPA RESPONSE SUBMISSION
───────────────────────────────────────────────────
Submit your completed CAPA response to: [Email]
Format: Our CAPA Response Form (attached) or equivalent structure
Deadline: [Date]

Failure to respond by the deadline will result in:
  - Automatic escalation to [senior buyer / VP Procurement]
  - Suspension of new PO issuance
  - Formal performance review meeting

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

6. FINANCIAL IMPLICATIONS
───────────────────────────────────────────────────
Cost of non-conformance to be charged to supplier:
  Inspection / sorting cost:   $[XXX]
  Rework cost:                 $[XXX]
  Freight for return/replace:  $[XXX]
  Customer penalty (if any):   $[XXX]
  ─────────────────────────────────────────────────
  Total charge:                $[XXX]

Charges will be deducted from next invoice unless disputed in writing 
within [5] business days of this notice.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This CAPA will remain open until all actions are verified as complete.
Recurrence within 12 months will result in probationary status review.

Issued by: [Name], [Title]
[Company Name]
[Email] | [Phone]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 8: Annual Strategic Review

Conducted once per year with key suppliers. Goes beyond monthly scorecard — assesses the relationship strategically.

### Annual Review Structure

**Section 1: Full-Year Performance Summary**
- 12-month composite score trend (monthly chart)
- Year-on-year comparison (this year vs. last year per dimension)
- Number of CAPAs issued, closed, recurred
- Cost of poor quality (COPQ) — total cost of defects, delays, and rework attributable to supplier

**Section 2: Commercial Performance**
- Price movement vs. market index
- Cost savings achieved (supplier-initiated vs. buyer-initiated)
- Payment compliance record
- Total cost of ownership vs. next-best alternative

**Section 3: Capacity and Capability Assessment**
- Capacity utilisation and headroom for growth
- Investments made in equipment, people, systems this year
- New product introduction capability demonstrated
- Digital integration status (EDI, portal, automated reporting)

**Section 4: Strategic Alignment**
- How well does this supplier align with our 3-year sourcing strategy?
- Are they investing in the categories/technologies we will need?
- ESG trajectory — improving, static, or regressing?
- Geopolitical and supply chain risk profile — has it changed?

**Section 5: Forward Plan**
- Projected volume for next year
- Development priorities agreed
- Target scorecard score for next annual review
- Contract renewal or renegotiation trigger points

### Annual Scorecard Summary Output

```
ANNUAL SUPPLIER REVIEW SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Supplier: [Name]          Review Year: [Year]
Category: [Category]      Buyer: [Name]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FULL-YEAR SCORECARD
─────────────────────────────────────────────────
         Q1      Q2      Q3      Q4      FY Avg
────── ─────── ─────── ─────── ─────── ──────────
Score   [X]     [X]     [X]     [X]     [X]/100
Trend   →       ↑       ↑       ↓       ↑ vs PY

FY Status: [Platinum / Gold / Silver / Bronze / Probationary]
Prior Year: [X]/100 → Change: [+/-X pts]

COST OF POOR QUALITY (COPQ)
─────────────────────────────────────────────────
Defect-related rework:    $[X,XXX]
Return logistics:         $[X,XXX]
Customer penalties:       $[X,XXX]
Expediting costs:         $[X,XXX]
─────────────────────────────────────────────────
TOTAL COPQ:               $[X,XXX]

COST SAVINGS ACHIEVED
─────────────────────────────────────────────────
Price reduction vs. prior year:   $[X,XXX]
Supplier-initiated savings:       $[X,XXX]
Process improvements:             $[X,XXX]
─────────────────────────────────────────────────
TOTAL SAVINGS:                    $[X,XXX]

NET VALUE CONTRIBUTION: $[savings minus COPQ]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

STRATEGIC DECISION
─────────────────────────────────────────────────
☐ Grow — increase volume allocation, extended contract
☐ Maintain — renew on current terms, standard review cadence
☐ Develop — improvement plan, increased buyer support
☐ Reduce — reduce exposure, begin dual-sourcing
☐ Exit — phase out with [X]-month transition plan

Rationale: [1–3 sentence rationale for the decision]

AGREED TARGETS FOR NEXT YEAR
─────────────────────────────────────────────────
Composite score target:  [X]/100
OTIF target:             [X]%
Defect rate target:      [X] PPM
Price movement target:   [X]% [reduction / flat]
Key development focus:   [Specific capability to develop]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Signed: Buyer [Name]          Supplier [Name]
Date:   [Date]                Date: [Date]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 9: 90-Day Supplier Development Plan

For suppliers in Bronze or Probationary band — a structured improvement roadmap with fortnightly checkpoints.

```
90-DAY SUPPLIER DEVELOPMENT PLAN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Supplier:       [Name]
Current status: [Bronze / Probationary]
Current score:  [X]/100
Target score:   [X]/100 by Day 90
Plan start:     [Date]
Review cadence: Fortnightly call + monthly scorecard
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ROOT CAUSE OF UNDERPERFORMANCE
[Brief factual assessment: where is the supplier failing and why]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DAYS 1–30: STABILISE
─────────────────────────────────────────────────
Focus: Contain the bleeding. Fix what is causing the most damage now.

Action 1: [Specific action]
  Owner: [Supplier contact name + title]
  Evidence required: [What buyer will check to verify]
  Due: Day [X]

Action 2: [Specific action]
  Owner: [Name]
  Evidence: [Description]
  Due: Day [X]

Action 3: [Specific action]
  Owner: [Name]
  Evidence: [Description]
  Due: Day [X]

30-Day checkpoint: Buyer reviews evidence. Score must reach [X] or 
plan escalates to [VP Procurement / alternative sourcing decision].

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DAYS 31–60: IMPROVE
─────────────────────────────────────────────────
Focus: Address root causes. Build systemic improvements.

Action 4: [Specific action]
  Owner: [Name]
  Evidence: [Description]
  Due: Day [X]

Action 5: [Specific action]
  Owner: [Name]
  Evidence: [Description]
  Due: Day [X]

60-Day checkpoint: Score must reach [X]. Buyer decides: continue plan 
or escalate to exit process.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DAYS 61–90: SUSTAIN
─────────────────────────────────────────────────
Focus: Prove the improvements are systemic, not temporary.

Action 6: [Specific action]
  Owner: [Name]
  Evidence: [Description]
  Due: Day [X]

Action 7: [Specific action]
  Owner: [Name]
  Evidence: [Description]
  Due: Day [X]

90-Day OUTCOME DECISION
─────────────────────────────────────────────────
If score ≥ [target]: Reclassify to Silver. Resume standard cadence.
If score [X]–[Y]:    Extend plan 30 days. Final chance.
If score < [X]:      Initiate exit/alternative sourcing process.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 10: Exit Assessment

When a supplier scores below 50 for two consecutive periods, or has a critical failure event, assess whether to exit.

### Exit Decision Matrix

| Factor | Weight | Score supplier |
|--------|--------|---------------|
| Performance score trend | 25% | Improving (10) / Flat (5) / Declining (0) |
| Replaceability | 25% | Easy to replace (10) / Moderate (5) / Hard (0) |
| Strategic importance | 20% | Low (10) / Medium (5) / Critical (0) |
| Outstanding PO/tooling exposure | 15% | Low (10) / Medium (5) / High (0) |
| Relationship/goodwill salvageable | 15% | Yes (10) / Maybe (5) / No (0) |

**Exit decision:**
- Matrix score ≥70: Exit — proceed with transition plan
- Matrix score 50–69: Final development attempt — 60-day plan with clear exit trigger
- Matrix score <50: Do not exit yet — too difficult/costly; focus on dual-sourcing instead

### Exit Transition Plan Output

```
SUPPLIER EXIT TRANSITION PLAN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Supplier to exit:     [Name]
Target exit date:     [Date — typically 3–6 months]
Replacement supplier: [Name or "TBD — RFQ in progress"]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TRANSITION STEPS
─────────────────────────────────────────────────
Week 1–2:   Issue RFQ to alternative suppliers (use rfq-drafting skill)
Week 3–6:   Qualify replacement supplier (use vendor-qualification skill)
Week 7–10:  Sample and first article from replacement
Week 11–14: Parallel production run — both suppliers active
Week 15–16: Last order placed with exiting supplier
Week 17+:   Full volume transferred to replacement

RISK MITIGATION
─────────────────────────────────────────────────
Buffer stock target during transition: [X] weeks
Exiting supplier obligations before exit:
  ☐ Return all buyer-owned tooling by [date]
  ☐ Provide last shipment to confirmed spec
  ☐ Cooperate with replacement supplier qualification
  ☐ Transfer all documentation (drawings, specs, test data)
  ☐ Settle all invoices and CAPA charges

Exit communication:
  [Script for communicating exit decision to supplier — factual, 
   professional, non-blaming. Preserve option for future re-engagement 
   if performance recovers.]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 11: Supplier Recognition

High-performing suppliers deserve formal recognition. It costs nothing and dramatically strengthens loyalty and motivation.

**Platinum supplier benefits to offer:**
- First access to new product development programs
- Longer contract terms (2–3 years vs. annual)
- Reduced inspection frequency (skip-lot or audit-free status)
- Joint press release or case study (brand exposure)
- Annual supplier award (plaque, certificate, public acknowledgement)
- Executive relationship access (VP/Director to Director meetings)

**Recognition letter template:**

```
Subject: [Company] Platinum Supplier Status — [Year] — [Supplier Name]

Dear [Name],

It is my pleasure to inform you that [Supplier Name] has achieved 
Platinum Supplier status in our [Year] annual review, with a composite 
performance score of [X]/100.

This recognition reflects your team's consistent excellence across 
delivery, quality, and commercial partnership. Your performance 
represents the standard we aspire to across our entire supply base.

As a Platinum supplier, you are now eligible for:
- Priority allocation in our [Year+1] production program
- [X]-year preferred supplier agreement
- Reduced inspection frequency under our trusted supplier program
- Invitation to our annual supplier summit

Thank you for your partnership. We look forward to continued growth 
together.

[Name], [Title]
[Company]
```

---

## Related Skills
- `sourcing-project-context` — for approved supplier list and category context
- `vendor-qualification` — the onboarding assessment; scorecard is the ongoing version
- `negotiation-playbook` — low scorecard scores = leverage in price renegotiation
- `contract-redlining` — scorecard KPIs should be written into supplier contracts
- `resilience-geopolitical-radar` — country/route risk affects delivery score interpretation
- `rfq-drafting` — when scorecard triggers exit, immediately RFQ alternatives
- `spend-analysis` — combine scorecard with spend data for total supplier value assessment
