---
name: sourcing-project-context
description: Use this skill when the user wants to set up, update, or reference their sourcing project context. Also use when starting any procurement, sourcing, RFQ, vendor qualification, or logistics task — this is the foundation file that all other procurement skills read first. Trigger whenever the user mentions a new product to source, a new supplier program, a new market or country they're sourcing from, or asks you to remember key details about their company, products, or supply chain. If you're about to run any procurement skill and this context doesn't exist yet, create it first.
---

# Sourcing Project Context

This is the foundation skill. Every other procurement skill in this library reads this file first to understand the user's product, supply chain, company, and requirements before doing anything.

## What This Skill Does

Creates and maintains a persistent context document (`.sourcesquid/context.md`) that captures:
- Company and stakeholder profile
- Active sourcing projects
- Supplier base and preferences
- Quality and compliance requirements
- Trade and logistics parameters
- Commercial terms and approval thresholds

## Workflow

### Step 1: Check for Existing Context

```bash
cat .sourcesquid/context.md 2>/dev/null || echo "NO_CONTEXT"
```

If context exists, read it and confirm with the user whether to update or use as-is.

If no context exists, run the intake interview below.

### Step 2: Intake Interview

Ask the user for the following. Batch questions intelligently — don't ask one at a time if the conversation already contains answers.

**Company profile:**
- Company name, country of incorporation, GST/tax ID if relevant
- Industry and primary products manufactured or sold
- Annual procurement spend (approximate)
- Team size and sourcing structure (solo, small team, large org)

**Current sourcing program:**
- What product(s) are being sourced right now?
- Target countries or regions (or open to suggestions?)
- Key quality standards required (ISO, CE, FDA, BIS, RoHS, FSC, GOTS, etc.)
- Certifications needed from suppliers (SMETA, SA8000, ISO 9001, FSSC, etc.)
- Any existing approved supplier list (ASL)?

**Commercial parameters:**
- Target unit price range or budget
- Annual volume or order frequency
- Payment terms preference (LC, TT, DP, DA, open account)
- Lead time requirements
- MOQ tolerance

**Logistics:**
- Incoterms preference or flexibility
- Preferred ports of loading (origin) and destination
- Freight mode preference (sea, air, courier, multimodal)
- Customs broker or forwarder already engaged?
- Any restricted countries or sanctioned entities to avoid?

**Compliance and risk:**
- ESG / sustainability requirements
- Conflict minerals or forced labour policy?
- Geopolitical sensitivities (e.g., avoid certain countries)
- Insurance requirements

### Step 3: Write the Context File

```bash
mkdir -p .sourcesquid
```

Write `.sourcesquid/context.md` in this format:

```markdown
# Sourcing Project Context
_Last updated: [DATE]_

## Company
- **Name**: [Company name]
- **Country**: [Country]
- **Industry**: [Industry]
- **Annual spend**: [Approximate]
- **Team**: [Solo / team size]

## Active Projects
| Project | Product | Category | Target Country | Stage | Priority |
|---------|---------|----------|----------------|-------|----------|
| [ID]    | [Product] | [Category] | [Country] | [RFQ/Sampling/Production] | [H/M/L] |

## Quality & Compliance
- **Standards required**: [ISO 9001, CE, FDA, BIS, RoHS, FSC, GOTS, etc.]
- **Supplier certifications**: [SMETA, SA8000, ISO 14001, etc.]
- **Restricted substances**: [REACH, RoHS, Prop 65, etc.]
- **ESG policy**: [Summary]

## Commercial Parameters
- **Payment terms**: [Preferred and acceptable alternatives]
- **Lead time**: [Standard / maximum]
- **MOQ**: [Tolerance range]
- **Target price**: [If known per project]
- **Currency**: [USD / EUR / INR / etc.]
- **Approval threshold**: [PO value requiring sign-off]

## Logistics
- **Incoterms preference**: [e.g., FOB for sea, DAP for air]
- **Origin ports**: [e.g., Ningbo, Shanghai, Chennai, Ho Chi Minh City]
- **Destination ports**: [e.g., Nhava Sheva, Rotterdam, Los Angeles]
- **Freight mode**: [Sea FCL / LCL / Air / Courier / Multimodal]
- **Forwarder / broker**: [Name if engaged]

## Supplier Base
| Supplier | Country | Category | Status | Risk Level |
|----------|---------|----------|--------|------------|
| [Name]   | [Country] | [Category] | [Approved/Probationary/Blacklisted] | [H/M/L] |

## Blacklist / Restrictions
- [Any countries, entities, or practices to avoid]

## Notes
- [Any other context the user has provided]
```

### Step 4: Confirm and Save

Show the user the completed context file. Ask for corrections. Save to `.sourcesquid/context.md`.

Tell the user: "All other procurement skills will now read this context automatically. You can update it at any time by saying 'update my sourcing context'."

## How Other Skills Use This Context

When any other procurement skill triggers, it should begin with:

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Then use the context to:
- Pre-fill company details into RFQs and outreach emails
- Apply the correct quality standards automatically
- Use the right Incoterms, payment terms, and ports
- Flag any compliance conflicts with supplier country or product
- Skip questions the user has already answered

## Related Skills
- All other skills in this library read this context first
- `rfq-drafting` — uses product category, quality standards, commercial parameters
- `vendor-qualification` — uses approved supplier list, compliance requirements
- `supplier-outreach` — uses company profile and commercial parameters
- `incoterms-advisor` — uses logistics parameters and destination
- `freight-cost-calculator` — uses port preferences and freight mode
