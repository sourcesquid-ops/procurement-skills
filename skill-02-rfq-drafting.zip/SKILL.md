---
name: rfq-drafting
description: Use this skill when the user wants to write, generate, or improve an RFQ (Request for Quotation), RFI (Request for Information), or RFP (Request for Proposal) to send to suppliers or manufacturers. Also trigger when the user says "draft an RFQ", "write to suppliers", "prepare a quotation request", "send out quotes", "get prices from factories", or describes a product they want to source and needs a structured document to send. Works for any product category — electronics, textiles, food, chemicals, timber, plastics, machinery, bio-materials, packaging, medical devices, automotive parts, and more. Works for any sourcing country (China, India, Vietnam, Bangladesh, Turkey, Mexico, Eastern Europe, etc.) and can output in multiple languages.
---

# RFQ Drafting

Converts product specifications into professional, complete RFQ documents ready to send to manufacturers or suppliers. Handles any product category, any country of supply, and outputs in English plus any required supplier language.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Use company name, quality standards, payment terms, Incoterms, and port preferences from context. Ask only for what's missing.

## Workflow

### Step 1: Product Intelligence Gathering

Ask the user for product details if not already provided. Tailor questions to the category.

**All categories (always ask):**
- Product name and common trade name
- Primary function / end use
- Target market and end consumer (affects compliance)
- Annual volume required and frequency (annual, seasonal, spot)
- Target unit price or budget (optional but useful)
- Sample required before bulk? Timeline?
- Tooling — who owns it? New tool or existing?

**Category-specific questions** — see `references/category-questions.md`

Load the relevant section based on product category detected from the user's description.

### Step 2: Select RFQ Template

Based on the product category, select the appropriate template from `references/rfq-templates.md`:

| Category | Template |
|----------|----------|
| Mechanical / Metal parts | Fabrication RFQ |
| Injection moulded / plastic | Tooling + Production RFQ |
| Textiles / Apparel / Soft goods | CMT / FOB Apparel RFQ |
| Electronics / PCBs / Assemblies | Electronics RFQ |
| Food / Nutraceuticals / Beverages | Food-grade RFQ |
| Chemicals / Raw materials | Bulk Commodity RFQ |
| Packaging (rigid / flexible) | Packaging RFQ |
| Timber / Wood products | FSC/Timber RFQ |
| Furniture / Home goods | Furniture RFQ |
| Industrial machinery / Equipment | Capital Equipment RFQ |
| Bio-materials / Sustainable goods | Eco-materials RFQ |
| Generic / Multi-category | Standard RFQ |

### Step 3: Draft the RFQ

Structure every RFQ in this order:

---

**[COMPANY NAME]**
Request for Quotation — [RFQ-YYYYMMDD-001]
Date: [Date]
Valid for supplier response until: [Date + 14 days]
Confidentiality: This RFQ and all responses are confidential.

---

**1. Introduction**
Brief 2–3 sentence introduction: who the buyer is, what they're sourcing, and the purpose of this RFQ.

**2. Product Specifications**

| Parameter | Requirement |
|-----------|-------------|
| Product name | |
| Description | |
| Material / Composition | |
| Dimensions (L × W × H) | |
| Weight | |
| Colour / Finish | |
| Tolerances | |
| Key performance requirements | |
| Applicable standards | |

Attach: technical drawing (DWG/PDF), 3D model (STEP/STP), samples (if any), reference images.

**3. Quantity and Delivery**

| Item | Quantity | Delivery Date | Destination |
|------|----------|---------------|-------------|
| [Item] | [Qty] | [Date] | [Port/Address] |

- MOQ: [State or ask supplier to propose]
- Annual forecast: [Units/year]
- Order frequency: [Monthly / Quarterly / Spot]

**4. Quotation Format Required**

Please quote the following (one line per item):

| Item | Unit Price ([Incoterms, Port]) | MOQ | Lead Time | Tooling Cost | Validity |
|------|-------------------------------|-----|-----------|--------------|---------|
| | | | | | |

Also provide:
- Price break schedule (if applicable): [e.g., 500 / 1,000 / 5,000 / 10,000 units]
- Tooling cost (if new tooling required): [USD, one-off]
- Sample cost and lead time
- Payment terms proposed

**5. Quality and Compliance Requirements**

- Quality standard: [ISO 9001 / BIS / CE / FDA / RoHS / FSC / GOTS / REACH / etc.]
- Inspection: [AQL 2.5 / Third-party inspection / Factory inspection allowed]
- Documentation required: [COA / Test reports / MSDS / Certificates]
- Supplier certifications required: [SMETA / SA8000 / ISO 14001 / FSSC 22000 / etc.]
- Samples: [Pre-production / Golden samples / First article inspection]

**6. Packaging Requirements**

- Inner packaging: [Specification]
- Master carton: [Dimensions, max weight]
- Marking: [Carton markings, labels, barcodes required]
- Special handling: [Fragile / Hazmat / Temperature-controlled]

**7. Commercial Terms**

- Incoterms: [e.g., FOB Ningbo / CIF Nhava Sheva / EXW Factory]
- Currency: [USD / EUR / CNY]
- Payment terms: [e.g., 30% TT advance, 70% against BL copy / LC at sight]
- Warranty: [e.g., 12 months from date of delivery]
- Penalty for late delivery: [If applicable]

**8. Information Requested from Supplier**

Please also provide:
- [ ] Company profile and factory certifications
- [ ] Production capacity (units/month)
- [ ] Current key customers (references)
- [ ] Lead time for first production run
- [ ] Whether you have existing tooling for this product
- [ ] Sub-contractor policy (do you outsource any production?)
- [ ] Export markets you currently supply to

**9. Submission Instructions**

- Send quote to: [Email]
- Subject line: RFQ-[Number] | [Product Name] | [Supplier Name]
- Deadline: [Date]
- Language: [English / or specify]
- Format: Excel or PDF preferred

Questions: Contact [Name] at [Email / WhatsApp]

---

### Step 4: Language Output

If the user requests translation or the target country warrants it:

**Chinese (Simplified)** — for mainland China suppliers
**Vietnamese** — for Vietnam suppliers
**Hindi** — for Indian suppliers (or keep English)
**Turkish** — for Turkey suppliers
**Spanish** — for Mexico / LATAM suppliers
**Arabic** — for Middle East suppliers
**German / Polish / Romanian** — for Eastern Europe suppliers
**Bengali** — for Bangladesh suppliers

Generate a translated version maintaining all tables and structure. Note: Technical specifications should remain in English alongside the translation to avoid misinterpretation.

### Step 5: Delivery Format

Ask the user how they want the output:
- Plain text to paste into email
- Word document (.docx)
- Excel quotation sheet (use xlsx skill)
- PDF (use pdf skill)

Default: offer Word document using the `docx` skill.

### Step 6: Distribution List Advice

After drafting, advise the user:
- Send to minimum 3 suppliers for competitive tension
- Include at least 1 known/incumbent and 2 new candidates
- Stagger sends if you don't want suppliers knowing they're competing
- Set a firm deadline (14 days typical; 7 days for urgent; 21 days for capital equipment)
- Follow up at Day 7 if no acknowledgement

## Quality Gates — Before Sending

Run through this checklist:

- [ ] All units specified (mm not cm, kg not lbs, unless regional standard)
- [ ] Incoterms and port of origin clearly stated
- [ ] Currency specified
- [ ] All compliance standards explicitly listed (no "standard quality")
- [ ] Payment terms specified
- [ ] Sample / tooling cost asked separately
- [ ] Submission deadline set
- [ ] Contact person named
- [ ] File attachments listed (even if not yet attached)

## Common Mistakes to Flag

- Vague specs ("as per sample") — always add written specs alongside samples
- Missing Incoterms — never let a supplier assume delivery terms
- No validity period — supplier prices can change; lock in with a quote validity date
- Not asking for capacity — a supplier who can't meet volume is a risk
- Not asking about sub-contracting — know if your factory uses sub-tiers

## Related Skills
- `sourcing-project-context` — read first for company profile
- `vendor-qualification` — run in parallel to assess suppliers receiving this RFQ
- `should-cost-modelling` — build a should-cost before sending to avoid anchoring
- `supplier-outreach` — draft the covering email to send with this RFQ
- `incoterms-advisor` — if Incoterms are unclear, resolve before sending

## Reference Files
- `references/category-questions.md` — category-specific spec questions
- `references/rfq-templates.md` — full templates by category
- `references/technical-clauses.md` — quality, IP, and commercial clause library
