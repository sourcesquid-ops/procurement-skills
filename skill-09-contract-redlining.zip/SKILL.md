---
name: contract-redlining
description: Use this skill when the user wants to review, redline, analyse, or negotiate a purchase order, supplier contract, supply agreement, NDA, or commercial terms document. Also trigger when the user says "review this contract", "redline this PO", "what's wrong with these terms", "are these supplier T&Cs acceptable", "check this NDA", "analyse this supply agreement", "what clauses am I missing", "is this standard", "review my payment terms", "flag any risks in this contract", or uploads or pastes a contract for review. Covers purchase orders (POs), master supply agreements (MSAs), manufacturing agreements, NDAs, quality agreements, tooling agreements, and logistics contracts.
---

# Contract Redlining

Reviews and redlines supplier contracts, purchase orders, NDAs, and supply agreements. Identifies missing clauses, unfavourable terms, ambiguities, and commercial risks. Recommends improved language.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Note company jurisdiction, payment terms preferences, quality standards, and any prior flagged issues.

## Workflow

### Step 1: Document Classification

Identify the document type and apply the relevant review checklist:

| Document type | Primary risk areas | Review depth |
|--------------|-------------------|--------------|
| Purchase Order (PO) | Delivery terms, quality, liability | Standard |
| Master Supply Agreement (MSA) | All areas | Deep |
| Non-Disclosure Agreement (NDA) | Scope, duration, remedies | Standard |
| Quality Agreement | AQL, inspection rights, CAPA | Technical |
| Tooling Agreement | Ownership, liability, return | Standard |
| Logistics / 3PL Agreement | SLAs, liability caps, insurance | Standard |
| Manufacturing Agreement | IP, exclusivity, capacity, ramp | Deep |

### Step 2: Run the Review

**A. COMMERCIAL TERMS**

Review and flag:

- **Price and currency**: Fixed or floating? Price review mechanism? FX clause?
- **Payment terms**: Net 30 / 60 / 90 days? Advance payment? LC? TT?
  - 🔴 Flag: >Net 60 without security; >50% advance to unknown supplier
  - ✅ Preferred: Net 30–45 after delivery / document receipt
- **Price adjustment**: Is there a clause allowing price changes? Under what conditions?
  - 🔴 Flag: Open-ended price adjustment without notice period
  - ✅ Add: "Prices are fixed for [12 months]. Any price change requires [60 days] written notice."
- **Volume commitment**: Is the buyer obligated to minimum volumes?
  - 🔴 Flag: Annual minimum purchase obligation without exit clause
- **Exclusivity**: Is either party locked in exclusively?
  - 🔴 Flag: Buyer exclusivity without supplier performance guarantees

**B. DELIVERY AND LOGISTICS**

- **Incoterms**: Stated correctly? Named place specific?
  - 🔴 Flag: Incoterms version not stated (must say "Incoterms® 2020")
  - 🔴 Flag: Sea Incoterm (FOB/CIF) applied to air freight
- **Delivery date**: Fixed or estimated? Consequences of late delivery?
  - ✅ Add: "Delivery [X] days late triggers a penalty of [0.5%] of order value per day, up to [5%] of order value."
- **Lead time**: Stated clearly? What triggers the clock (PO receipt, advance payment, material release)?
- **Force majeure**: What events excuse delay? Is COVID-type event covered?
  - ✅ Standard force majeure: war, natural disaster, government action — should NOT include supplier's own manufacturing failures
- **Packaging**: Sufficiently specified? Who bears damage from inadequate packaging?

**C. QUALITY AND INSPECTION**

- **Quality standard**: Referenced explicitly? (ISO 9001, AQL level, test method)
  - 🔴 Flag: "Industry standard quality" — meaningless, always reject
  - ✅ Replace with: "AQL 2.5 major / 4.0 minor per ISO 2859-1, unless otherwise specified in PO"
- **Inspection rights**: Does buyer have the right to inspect at factory? Before shipment? Third-party?
  - ✅ Must-have: "Buyer reserves the right to conduct or commission pre-shipment inspection at seller's facility."
- **Rejection procedure**: What happens if goods fail inspection?
  - ✅ Must-have: Clear process for rejection, re-inspection, return at seller's cost, replacement timeline
- **CAPA**: Corrective and preventive action process for quality escapes?
- **Warranty**: Duration and scope?
  - 🔴 Flag: No warranty clause, or warranty period <12 months from delivery
  - ✅ Standard: "12 months from date of delivery, or 18 months from date of manufacture, whichever is earlier."
- **Latent defects**: What about defects discovered after the warranty period?
- **Product liability**: Who bears liability for injury or damage caused by defective product?
  - ✅ Must-have: Supplier indemnifies buyer for product liability arising from manufacturing defects

**D. INTELLECTUAL PROPERTY**

- **IP ownership**: Who owns the product design? Tooling? Any developments made during the contract?
  - 🔴 Flag: No IP clause — default may vary by jurisdiction
  - ✅ Must-have: "All IP, designs, and tooling paid for by [Buyer] shall remain the exclusive property of [Buyer]."
- **Confidentiality**: Is there an NDA or confidentiality clause? Scope clear?
- **Brand use**: Can supplier use buyer's brand name in their marketing?
  - 🔴 Flag: No restriction on supplier advertising the relationship
- **Sub-contracting**: Can supplier sub-contract? Does buyer need to approve?
  - ✅ Add: "Supplier shall not sub-contract any part of this order without prior written consent of Buyer."
- **Tooling ownership**: Who owns dies, moulds, jigs?
  - ✅ If buyer paid: "All tooling funded by Buyer is the exclusive property of Buyer and must be returned on demand."

**E. LIABILITY AND INDEMNITY**

- **Liability cap**: Is supplier's liability capped? At what level?
  - 🔴 Flag: Supplier liability capped below value of PO
  - ✅ Minimum: Liability should cover full PO value + consequential losses for quality failures
- **Consequential losses**: Are they excluded or included?
- **Insurance**: Is supplier required to carry product liability insurance? What limits?
  - ✅ Typical requirement: $1M–$5M product liability cover per occurrence

**F. TERM, TERMINATION, AND EXIT**

- **Contract term**: Fixed or rolling? Auto-renewal clause?
  - 🔴 Flag: Auto-renewal without buyer consent
- **Termination for convenience**: Can buyer exit without cause?
  - ✅ Must-have for MSA: Termination on [90 days] written notice without cause
- **Termination for cause**: Clear triggers (insolvency, repeated quality failures, force majeure > X days)?
- **Transition assistance**: If contract ends, does supplier cooperate with handover to new supplier?
- **Tooling return**: On termination, process for returning buyer-owned tooling?
- **Stock return**: On termination, process for returning unused materials / finished goods?

**G. GOVERNING LAW AND DISPUTE RESOLUTION**

- **Governing law**: Which country's law applies?
  - 🟡 Note: If supplier is in China, Chinese law is common but arbitration in Hong Kong or Singapore is preferred
  - 🟡 Note: Indian contracts often governed by Indian law with Mumbai or Delhi jurisdiction
- **Dispute resolution**: Negotiation → Mediation → Arbitration → Litigation?
  - ✅ Preferred: ICC or SIAC arbitration for international contracts (enforceable across jurisdictions)
  - 🔴 Flag: Disputes submitted exclusively to courts in supplier's jurisdiction only
- **Language**: Which language is authoritative if bilingual contract?

### Step 3: Output Format

**Redline Report:**

```
CONTRACT REVIEW REPORT
Document: [Title / Reference]
Supplier: [Name]
Reviewed by: [User]
Date: [Date]

━━━ 🔴 CRITICAL ISSUES (must fix before signing) ━━━
Clause [X.X] — [Issue description]
  Current text: "[Quote]"
  Risk: [Explanation]
  Recommended change: "[Improved wording]"

━━━ 🟡 SIGNIFICANT CONCERNS ━━━
[Same format]

━━━ 🟢 RECOMMENDED ADDITIONS (clauses currently missing) ━━━
Add: [Clause name]
  Recommended text: "[Full clause text]"
  Why: [Rationale]

━━━ ℹ️ NOTES / OBSERVATIONS ━━━
[Minor items, market practice context]

SUMMARY: [X] critical issues, [X] significant concerns, [X] additions recommended
RECOMMENDATION: Do not sign as-is / Sign with amendments / Sign (minor issues)
```

### Step 4: Standard Clause Library

If the user needs specific clause language, provide from this library:

**Force majeure (balanced):**
"Neither party shall be liable for any failure or delay in performance due to causes beyond its reasonable control, including but not limited to acts of God, war, civil unrest, government actions, or natural disasters, provided that the affected party: (a) gives written notice within [5] business days of the event; and (b) uses commercially reasonable efforts to mitigate the effect. If the force majeure event continues for more than [60] days, the other party may terminate the agreement on [30] days' written notice."

**IP ownership:**
"All intellectual property rights in any designs, drawings, specifications, tooling, and moulds provided by or paid for by Buyer shall remain the exclusive property of Buyer. Supplier grants Buyer a royalty-free, perpetual licence to any background IP incorporated into the goods."

**Quality (basic):**
"All goods shall conform to the specifications set out in the Purchase Order and any applicable drawings or samples approved by Buyer. Goods shall meet AQL Level II, 2.5 major / 4.0 minor per ISO 2859-1 unless otherwise stated. Buyer reserves the right to inspect goods at Supplier's premises prior to shipment."

**Governing law (international best practice):**
"This Agreement shall be governed by the laws of [Singapore / England & Wales]. Any dispute arising shall be finally resolved by arbitration under the [SIAC / ICC] Rules in [Singapore / London], in the English language, before [1/3] arbitrator(s)."

## Related Skills
- `rfq-drafting` — ensure RFQ terms pre-align with contract expectations
- `vendor-qualification` — assess supplier credibility before contracting
- `incoterms-advisor` — verify Incoterms stated in contract
- `resilience-geopolitical-radar` — assess force majeure risk by supplier country
