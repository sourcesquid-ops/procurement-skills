---
name: esg-compliance-audit
description: Use this skill when the user wants to assess, audit, score, or improve supplier ESG compliance, or understand regulatory requirements affecting their supply chain. Trigger when the user mentions "ESG audit", "supplier sustainability", "forced labour", "UFLPA", "Uyghur", "modern slavery", "child labour", "EUDR", "deforestation regulation", "CBAM", "carbon border", "Scope 3", "conflict minerals", "supply chain due diligence", "LkSG", "German supply chain act", "social compliance", "SMETA", "SA8000", "WRAP", "BSCI", "ethical sourcing", "ESG questionnaire", "ESG scorecard", "supplier carbon footprint", "environmental audit", "human rights due diligence", "supply chain transparency", or any question about whether a supplier meets ethical, environmental, or governance standards. Covers UFLPA, EUDR, CBAM, CSDDD, LkSG, UK Modern Slavery Act, AU Modern Slavery Act, conflict minerals. Any product, any country, any market.
---

# ESG Compliance Audit

The most rapidly evolving area of procurement risk. ESG compliance has shifted from voluntary best practice to legal obligation in the EU, UK, US, Germany, France, and Australia — with more jurisdictions following. A supplier that fails ESG due diligence can result in shipment seizure, market access denial, reputational catastrophe, and personal liability for directors.

**Core philosophy:** ESG compliance is not a box to tick. It is supply chain risk management by another name. Every forced labour finding, every deforestation link, every carbon liability is a business risk — financial, legal, and reputational — that procurement owns.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Extract: product categories, supplier countries, destination markets, existing ESG policies, certifications held, and any known compliance concerns.

---

## Step 1: Regulatory Exposure Mapping

Before auditing any supplier, map which regulations apply based on three factors: **what** you're buying, **where** it's made, and **where** it's sold.

### 1A. Mandatory Regulations by Destination Market

#### United States

**UFLPA — Uyghur Forced Labour Prevention Act (effective June 2022)**
- Creates a rebuttable presumption that ANY goods produced wholly or in part in Xinjiang, China — or by entities on the UFLPA Entity List — are made with forced labour and are banned from import.
- Rebuttable only with "clear and convincing evidence" — an extremely high standard.
- Affected product categories: cotton, polysilicon (solar), tomatoes, coal, aluminium, steel, and any manufactured goods with Xinjiang-origin components.
- Practical impact: any supply chain touching Xinjiang — even upstream (yarn → fabric → garment) — creates liability. Tier 2 and Tier 3 supplier mapping is now mandatory for at-risk categories.
- Entity List: regularly updated. Always check current UFLPA Entity List via CBP.gov before clearing a shipment.
- **Importer of record bears full responsibility** — "I didn't know" is not a defence.

**Tariff Act Section 307 (19 U.S.C. § 1307)**
- Broader than UFLPA: prohibits import of goods made wholly or in part by convict, forced, or indentured labour globally. Predates UFLPA.
- WROs (Withhold Release Orders) can target specific companies, regions, or products worldwide.
- Check active WROs at: cbp.gov/trade/forced-labor/withhold-release-orders-and-findings

**Dodd-Frank Act Section 1502 — Conflict Minerals**
- Applies to SEC-registered companies (US-listed).
- Covers 3TG: tin (cassiterite), tantalum (coltan), tungsten (wolframite), gold — if sourced from Covered Countries (DRC and adjoining nations).
- Annual filing requirement: Form SD with conflict minerals report.
- Due diligence standard: OECD Due Diligence Guidance for Responsible Supply Chains of Minerals.

**California Transparency in Supply Chains Act (SB 657)**
- Applies to retailers and manufacturers with >$100M annual global gross receipts doing business in California.
- Requires disclosure of efforts to eradicate slavery and human trafficking from direct supply chain.
- Disclosure only — no specific compliance standard mandated, but weak disclosures attract reputational and litigation risk.

#### European Union

**EUDR — EU Deforestation Regulation (Regulation 2023/1115)**
- In force: applies to large companies from December 2024; SMEs from June 2025 (dates subject to revision — verify current status).
- Products covered: cattle, cocoa, coffee, palm oil, soy, wood, rubber — AND derived products (leather, chocolate, furniture, paper, tyres, cosmetics with palm).
- Requirement: operators must conduct due diligence to ensure products are: (a) deforestation-free (no production on land deforested after 31 December 2020); (b) produced in compliance with laws of producing country; (c) covered by a due diligence statement.
- Geolocation data: suppliers must provide GPS coordinates of production plots.
- Risk classification: countries classified as low, standard, or high risk — high-risk countries face enhanced scrutiny.
- Penalty: up to 4% of annual EU turnover for violations.

**CBAM — Carbon Border Adjustment Mechanism (Regulation 2023/956)**
- Transitional phase: October 2023 – December 2025 (reporting only, no payment).
- Full implementation: from January 2026, importers must purchase CBAM certificates for embedded carbon in imports.
- Sectors covered: cement, iron/steel, aluminium, fertilisers, electricity, hydrogen — with planned expansion.
- Calculation: embedded carbon emissions in imported goods × EU ETS carbon price.
- Implication for sourcing: suppliers in high-carbon production locations now carry a financial cost. Low-carbon suppliers gain competitive advantage.

**CSDDD — Corporate Sustainability Due Diligence Directive (EU 2024/1760)**
- Phased application: large companies (>1,000 employees, >€450M turnover) from 2027; smaller large companies from 2028.
- Requires: identification, prevention, mitigation, and remediation of actual and potential adverse human rights and environmental impacts in own operations and value chains.
- Covers: entire supply chain (upstream and partially downstream).
- Transition plans required to align with Paris Agreement 1.5°C pathway.
- Civil liability: companies can be held liable for harm caused by failure of due diligence.

**EU Forced Labour Regulation (Proposed — expected 2025–2026)**
- Would ban products made with forced labour from the EU market.
- Modelled on UFLPA concept but applicable globally (not just Xinjiang-specific).
- Investigation authority: national competent authorities with EU Commission coordination.
- Status: advancing through EU legislative process — monitor for final adoption date.

#### United Kingdom

**UK Modern Slavery Act 2015 (Section 54)**
- Applies to organisations with >£36M annual turnover supplying goods/services in the UK.
- Requires annual Transparency Statement disclosing steps taken to ensure slavery and human trafficking are not occurring in supply chain or own business.
- Statement must be approved by board and signed by a director.
- No specific due diligence standard mandated — but "we had no modern slavery policy" is a reputational crisis waiting to happen.

**UK CBAM (proposed — implementation 2027)**
- Following EU model; sectors likely to mirror EU CBAM.

#### Germany

**LkSG — Lieferkettensorgfaltspflichtengesetz (Supply Chain Due Diligence Act)**
- In force: January 2023 (>3,000 employees); January 2024 (>1,000 employees).
- Requires: identification, prevention, mitigation, and documentation of human rights and certain environmental risks across own operations and direct suppliers, with due diligence also for indirect suppliers where there is "substantiated knowledge" of violations.
- Risks covered: child labour, forced labour, slavery, hazardous working conditions, freedom of association, land rights, environmental damage, mercury, persistent organic pollutants.
- Complaints mechanism: must be established and accessible to anyone.
- Enforcement: Federal Office for Economic Affairs and Export Control (BAFA); fines up to 2% of global annual turnover for large companies; exclusion from public procurement up to 3 years.

#### France

**Loi de Vigilance (Duty of Vigilance Law, Law 2017-399)**
- Applies to: French companies with >5,000 employees in France OR >10,000 employees worldwide.
- Requires: annual vigilance plan identifying risks and preventive measures for human rights, health/safety, and environmental impacts in own operations and supply chain (including subsidiaries and controlled subcontractors).
- Civil liability: companies can be held liable for harm arising from failure to establish or implement the plan.

#### Australia

**Modern Slavery Act 2018**
- Applies to: entities with annual consolidated revenue >AUD 100M doing business in Australia.
- Requires: annual Modern Slavery Statement describing actions taken to assess and address modern slavery risks in operations and supply chains.
- Seven criteria must be addressed including: structure and operations, risks identified, actions taken, assessment of effectiveness.

#### Other Jurisdictions to Monitor
- **Canada:** Fighting Against Forced Labour and Child Labour in Supply Chains Act (S-211) — in force 2024
- **Netherlands:** Child Labour Due Diligence Act (pending implementation)
- **Norway:** Transparency Act — in force 2022
- **Switzerland:** Non-Financial Reporting Ordinance (with supply chain due diligence for conflict minerals and child labour)
- **Japan:** Guidelines on Respecting Human Rights in Responsible Supply Chains (2022) — voluntary but expectation-setting

---

### 1B. Regulatory Applicability Matrix

Quickly determine which regulations apply based on product and market:

| Regulation | Product trigger | Market trigger | Action required |
|-----------|----------------|----------------|-----------------|
| UFLPA | Any goods with Xinjiang-origin components (esp. cotton, polysilicon, tomatoes, coal) | Export to USA | Map Tier 2–3 suppliers; obtain affidavits; avoid UFLPA entities |
| EUDR | Cattle, cocoa, coffee, palm, soy, wood, rubber + derivatives | Export to EU | GPS coordinates; deforestation-free evidence; due diligence statement |
| CBAM | Cement, steel, aluminium, fertilisers, electricity, hydrogen | Export to EU | Carbon content reporting; certificate purchase from Jan 2026 |
| CSDDD | Any goods in large company supply chain | EU company in supply chain | Due diligence programme; remediation |
| LkSG | Any goods supplied to/by German entity >1,000 employees | German supply chain | Risk assessment; complaints mechanism |
| Conflict minerals | Electronics, auto parts, jewellery, aerospace containing 3TG | SEC-listed company | OECD due diligence; Form SD filing |
| UK Modern Slavery | Any goods >£36M UK revenue | UK market | Annual statement; board sign-off |
| AU Modern Slavery | Any goods >AUD 100M revenue | Australian entity | Annual statement; seven criteria |

---

## Step 2: ESG Risk Profiling

### 2A. Country Risk Profile

Assign a baseline ESG risk rating to each supplier's country of production:

**🔴 Highest Risk — Enhanced due diligence mandatory:**
- North Korea (forced labour, forced labour exports known)
- Xinjiang, China (UFLPA presumption of forced labour)
- Turkmenistan (state-sponsored forced labour in cotton)
- Uzbekistan (historic cotton forced labour — improved but monitor)
- Myanmar/Burma (military junta; sanctions; labour rights violations)
- Eritrea (government-imposed labour; mining sector)
- Libya, Yemen (conflict; rule of law absent)

**🟠 High Risk — Heightened scrutiny required:**
- Bangladesh (RMG: building safety, fire safety, wage theft history; improve
ment trajectory but ongoing issues)
- Pakistan (cotton sector; brick kilns; bonded labour in agriculture)
- India (bonded labour in specific sectors: stone quarrying, brick kilns, agriculture, fisheries; child labour in informal sector)
- China (outside Xinjiang: general labour rights restrictions; freedom of association absent)
- Vietnam (labour rights restrictions; migrant workers in manufacturing)
- Cambodia (garment sector; land grabbing; labour rights)
- Ethiopia (conflict regions; land rights; labour rights in floriculture)
- Brazil (Amazon deforestation; rural slave labour — particularly in cattle and soy)
- DRC and adjoining countries (conflict minerals; artisanal mining)
- Bolivia, Peru, Ecuador (artisanal and small-scale mining; child labour)
- Indonesia (palm oil — deforestation, land rights, labour; fisheries — forced labour)
- Malaysia (electronics, rubber gloves — documented migrant worker abuses)
- Philippines (fisheries — forced labour documented)
- Gulf states (UAE, Saudi, Qatar, Kuwait — migrant worker kafala system)

**🟡 Medium Risk — Standard due diligence:**
- Mexico (labour rights gaps; cartel influence in some sectors; femicide in maquiladoras)
- Colombia (land rights; FARC legacy in coca-adjacent regions)
- Thailand (fishing industry — documented forced labour; improving)
- Sri Lanka (documented improvement; tea sector improving)
- Turkey (Syrian refugee labour in agriculture and informal manufacturing)
- Morocco, Tunisia, Egypt (labour rights gaps; freedom of association limited)
- Romania, Bulgaria (vulnerable migrant workers; Roma exploitation risk)
- West Africa — Ghana, Côte d'Ivoire (cocoa child labour: major ongoing issue)
- Nigeria (oil sector; community conflicts; artisanal mining)
- South Africa (labour rights generally good; mining safety concerns)

**🟢 Lower Risk — Standard verification:**
- Western Europe, Nordic countries, Australia, New Zealand, Japan, South Korea, Canada, USA

**Note:** Country risk is a starting point, not a conclusion. A compliant factory in a high-risk country can be lower risk than a negligent factory in a low-risk country. Individual facility assessment is always required.

---

### 2B. Product / Sector Risk Profile

Some products carry inherent ESG risk regardless of country:

**Forced labour / child labour highest risk sectors:**
- Cotton (Xinjiang, Turkmenistan, Uzbekistan, parts of India and West Africa)
- Cocoa (Côte d'Ivoire, Ghana — child labour extensively documented)
- Coffee (some origin countries — child labour and migrant worker risks)
- Seafood / fish / shrimp (Thailand, Indonesia, China — forced labour on vessels documented)
- Rubber gloves (Malaysia — Cambodian and other migrant worker abuse documented)
- Solar panels / polysilicon (Xinjiang supply chain — UFLPA)
- Steel and aluminium (Xinjiang coal; production emissions; CBAM)
- Palm oil (Indonesia, Malaysia — deforestation, land rights, labour)
- Tobacco (child labour in curing barns — Malawi, Zimbabwe, Philippines)
- Bricks (bonded labour — India, Pakistan, Nepal)
- Stone / granite / mica (India — child labour, silicosis risk)
- Gold and precious metals (artisanal mining — DRC, West Africa, South America)
- Electronics / 3TG minerals (conflict minerals — DRC adjacent)
- Sugarcane (Brazil, India — debt bondage; hazardous child labour)
- Garments / textiles (Bangladesh, Myanmar, Cambodia — wages, hours, building safety)
- Domestic workers (Gulf states — kafala system creates exploitation risk)

**Environmental highest risk sectors:**
- Timber and wood products (deforestation — EUDR)
- Beef / leather (Amazon deforestation — EUDR)
- Soy (Amazon, Cerrado deforestation — EUDR)
- Palm oil (Borneo, Sumatra peatland destruction — EUDR)
- Coal, oil and gas (Scope 3 emissions; stranded asset risk)
- Cement (high carbon intensity — CBAM)
- Aluminium (high energy; carbon — CBAM)
- Fast fashion (microplastics; chemical discharge; waste)
- Electronics (e-waste; hazardous materials; rare earth mining)
- Chemicals (persistent organic pollutants; waterway contamination)

---

## Step 3: ESG Supplier Questionnaire

Issue this questionnaire to suppliers before onboarding and annually thereafter. Tailor sections based on product/country risk profile.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ESG SUPPLIER SELF-ASSESSMENT QUESTIONNAIRE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Supplier:           [Legal entity name]
Country:            [Country of production]
Product category:   [Category]
Completed by:       [Name, Title]
Date:               [Date]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SECTION A: COMPANY AND CERTIFICATIONS

A1. Provide your current social compliance certifications:
    ☐ SMETA 2-pillar audit (date: ___ result: ___)
    ☐ SMETA 4-pillar audit (date: ___ result: ___)
    ☐ SA8000 (certificate number: ___ expiry: ___)
    ☐ WRAP (level: ___ expiry: ___)
    ☐ BSCI (date: ___ result: ___)
    ☐ Fair Trade (certificate: ___)
    ☐ Better Work programme (participating: Y/N)
    ☐ ISO 45001 (Health & Safety — expiry: ___)
    ☐ None — explain: ___________________________

A2. Environmental certifications:
    ☐ ISO 14001 (expiry: ___)
    ☐ ISO 50001 (Energy — expiry: ___)
    ☐ Bluesign (textiles)
    ☐ OEKO-TEX STANDARD 100 (expiry: ___)
    ☐ OEKO-TEX MADE IN GREEN
    ☐ FSC (certificate number: ___ expiry: ___)
    ☐ PEFC
    ☐ Rainforest Alliance (certificate: ___)
    ☐ RSPO (palm oil — membership number: ___)
    ☐ None — explain: ___________________________

A3. Do you subcontract any part of production?
    ☐ No  ☐ Yes — list subcontractors and locations: ________________
    Do subcontractors meet the same ESG standards? ☐ Y ☐ N ☐ Unknown

A4. Who are your Tier 2 key material suppliers (raw material, components)?
    [List: Name, Country, Material/Component]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION B: LABOUR AND HUMAN RIGHTS

B1. Wages and working hours
    Minimum wage compliance: ☐ Yes ☐ No — explain: ____________
    Actual average monthly wage (production workers): ___________
    Living wage benchmark for your location: ___________________
    Maximum regular hours per week: ____
    Maximum overtime hours per week: ____
    Overtime is: ☐ Voluntary  ☐ Mandatory  ☐ Mixed
    Overtime pay rate vs. regular: ____× base rate

B2. Freedom of association
    Workers have right to organise / join trade union:
    ☐ Yes, active union present  ☐ Yes, right exists, no union
    ☐ Restricted by national law (explain: _______________)
    Worker representation mechanism: ☐ Union  ☐ Works council
    ☐ Worker committee  ☐ None
    Last negotiation / dialogue with workers' representatives: [Date]

B3. Forced labour
    Do any workers pay recruitment fees to obtain employment?
    ☐ No  ☐ Yes — amount and policy: _____________________
    Are workers required to surrender documents (passport, ID)?
    ☐ No  ☐ Yes — explain: _______________________________
    Are workers from a specific ethnic group, region, or labour
    programme? ☐ No  ☐ Yes — describe: ____________________
    [If Xinjiang origin workers or government labour transfer
    programme involved: automatic escalation]

B4. Child labour
    Minimum age for employment at your facility: _____ years
    Minimum age per national law: _____ years
    Age verification process: _______________________________
    Are any workers under 18 employed? ☐ No ☐ Yes (describe protections):
    Last age verification audit: [Date]

B5. Migrant and contract workers
    % of workforce that are migrant workers: ____%
    % engaged through labour agents / contractors: ____%
    Recruitment fee policy (buyer pays principle):
    ☐ We have and enforce a zero-recruitment-fee policy
    ☐ Policy exists but compliance not fully verified
    ☐ No formal policy
    Contract workers receive same pay as direct employees for
    same work: ☐ Yes  ☐ No — explain: _____________________

B6. Health and safety
    Lost Time Injury Frequency Rate (LTIFR) last 12 months: ______
    Fatalities in last 3 years: ____
    Building structural assessment completed: ☐ Y ☐ N  Date: ______
    Fire safety assessment completed: ☐ Y ☐ N  Date: ______
    Emergency evacuation drill frequency: ______________________
    Medical facilities on-site: ☐ Y ☐ N
    PPE provided free of charge: ☐ Y ☐ N

B7. Grievance mechanism
    Grievance / whistleblower channel available to workers:
    ☐ Yes — describe: ___________________________________
    ☐ No
    Anonymous reporting possible: ☐ Y ☐ N
    Number of grievances filed last 12 months: ____
    Average resolution time: ____ days

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION C: ENVIRONMENT

C1. Energy and carbon
    Total energy consumption (last 12 months): ____ MWh
    Renewable energy share: ____%
    Total Scope 1 GHG emissions: ____ tCO2e
    Total Scope 2 GHG emissions: ____ tCO2e
    Carbon reduction target: ☐ Yes (target: ___ by ___) ☐ No
    Science-Based Target (SBTi): ☐ Committed ☐ Approved ☐ Not started

C2. Water
    Total water consumption: ____ m³/year
    Water source: ☐ Municipal  ☐ Groundwater  ☐ Surface water
    Water recycling/recirculation: ____%
    Located in water-stressed area: ☐ Y ☐ N (per WRI Aqueduct or equivalent)
    Wastewater treatment before discharge: ☐ Y ☐ N ☐ N/A
    Effluent testing frequency: ___________________________

C3. Chemicals and hazardous materials
    Restricted substances list compliance: ☐ Y ☐ N
    REACH compliance: ☐ Y ☐ N ☐ N/A
    RoHS compliance: ☐ Y ☐ N ☐ N/A
    Chemical inventory maintained: ☐ Y ☐ N
    Chemical storage and handling training: ☐ Y ☐ N

C4. Waste
    Waste-to-landfill: ____%
    Hazardous waste disposal method: ______________________
    Licensed hazardous waste contractor: ☐ Y ☐ N

C5. Deforestation (for EUDR-relevant products only)
    Do any of your raw materials (wood, paper, palm, soy, cocoa,
    coffee, cattle/leather, rubber) come from land cleared after
    31 December 2020?
    ☐ No (provide evidence: GPS coordinates, satellite mapping)
    ☐ Unknown — in process of mapping
    ☐ Yes — describe: ____________________________________
    Can you provide plot-level GPS coordinates for all
    agricultural/forestry raw material sourcing?
    ☐ Yes  ☐ Partially  ☐ No

C6. Supply chain deforestation mapping (EUDR applicable only)
    Are your raw material suppliers also providing deforestation
    declarations? ☐ Y ☐ N ☐ In progress

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION D: CONFLICT MINERALS (for electronics, auto, jewellery, aerospace)

D1. Do your products contain tin, tantalum, tungsten, or gold (3TG)?
    ☐ No  ☐ Yes  ☐ Unknown

D2. If yes, do you have a Conflict Minerals Policy?
    ☐ Yes (attach)  ☐ No

D3. Have you completed OECD-aligned supply chain due diligence
    for conflict minerals?
    ☐ Yes — attach CMRT (Conflict Minerals Reporting Template)
    ☐ In progress  ☐ No

D4. Are any smelters/refiners in your supply chain RMAP-compliant
    (Responsible Minerals Assurance Process)?
    ☐ Yes — % RMAP compliant smelters: ____%
    ☐ Unknown  ☐ No

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION E: GOVERNANCE

E1. Anti-corruption and anti-bribery
    Anti-corruption policy: ☐ Yes ☐ No
    Anti-corruption training for employees: ☐ Yes ☐ No
    Gifts and entertainment policy: ☐ Yes ☐ No
    Last 3 years: any corruption-related legal proceedings?
    ☐ No  ☐ Yes — describe: _____________________________

E2. Business ethics
    Code of conduct: ☐ Yes (attach) ☐ No
    Supplier code of conduct communicated to your suppliers?
    ☐ Yes  ☐ No
    Whistleblower protection policy: ☐ Yes ☐ No
    Data privacy policy (GDPR / equivalent): ☐ Yes ☐ No

E3. Management systems
    ESG/sustainability officer or dedicated function?
    ☐ Yes — role: __________  ☐ No — owner: ______________
    Annual ESG report published: ☐ Yes (attach) ☐ No
    ESG targets set and tracked: ☐ Yes ☐ No — describe: ______

E4. Financial stability
    Any insolvency, administration, or receivership proceedings?
    ☐ No  ☐ Yes — describe: ____________________________
    Any material litigation affecting the business?
    ☐ No  ☐ Yes — describe: ____________________________

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DECLARATION

I declare that the information provided in this questionnaire is accurate
and complete to the best of my knowledge. I acknowledge that providing
false information may result in immediate termination of our commercial
relationship and may be reported to relevant authorities.

Name: _____________________ Title: ___________________
Signature: _________________ Date: ___________________
Company stamp:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 4: ESG Scoring Framework

Score each supplier across five ESG dimensions to produce a composite rating.

### Dimension 1: Forced Labour & Child Labour Risk (30% weight)

The highest-weight dimension because the consequences — seizure, ban, criminal liability — are the most severe.

| Finding | Score | Action |
|---------|-------|--------|
| No indicators; SMETA/SA8000 clean; sub-supplier mapped | 100 | Approved |
| Minor findings; corrective actions implemented; no systemic issues | 75 | Monitor |
| Unverified sub-supplier chain; recruitment fees not ruled out | 50 | Enhanced due diligence required |
| Government labour transfer programme involvement (Xinjiang) | 0 | Automatic fail — exit |
| Document retention of workers | 0 | Automatic fail — exit |
| Child labour found (under 15) | 0 | Automatic fail — immediate exit + report |
| Confirmed forced labour | 0 | Automatic fail — immediate exit + report |

**Automatic fail triggers — regardless of all other scores:**
- Any confirmed forced labour including state-sponsored labour programmes in Xinjiang
- Any child labour under 15 (or 14 in countries where ILO minimum age convention permits)
- Worker passport or document confiscation
- Workers unable to leave premises or terminate employment freely
- Products on UFLPA Entity List or subject to active WRO

### Dimension 2: Labour Rights & Working Conditions (25% weight)

| Factor | Excellent (100) | Good (75) | Acceptable (50) | Poor (25) | Fail (0) |
|--------|----------------|-----------|-----------------|-----------|---------|
| Wages | >living wage | At living wage | At minimum wage | Below minimum | Wage theft |
| Working hours | ≤48hr/wk regular | 48–54hr | 54–60hr with consent | >60hr | Coerced excessive overtime |
| Freedom of association | Active union or genuine dialogue | Right exists, no union | Restricted by law, alternatives exist | Suppressed | Workers punished for organising |
| H&S | LTIFR<1; zero fatalities 3yr | LTIFR 1–3 | LTIFR 3–5 | LTIFR>5 | Fatalities or concealment |
| Grievance mechanism | Independent, anonymous, effective | Exists and used | Exists, rarely used | Exists, dysfunctional | None |
| Migrant workers | Zero-fee; equal treatment | Minimal fees; mostly equal | Some fee issues | Widespread fees | Systemic exploitation |

### Dimension 3: Environmental Compliance (20% weight)

| Factor | Score |
|--------|-------|
| ISO 14001 or equivalent certified + carbon reduction targets set | 100 |
| Environmental management system exists; not certified; improving | 75 |
| Basic compliance only; no targets or measurement | 50 |
| Non-compliant with local environmental law | 25 |
| Active environmental violation / enforcement action | 0 |
| Deforestation link (EUDR products) | 0 — Automatic fail for EU supply chain |

**Carbon/CBAM scoring (for relevant sectors):**

| Carbon intensity vs. sector average | Score |
|------------------------------------|-------|
| >30% below sector average | 100 |
| 10–30% below sector average | 75 |
| At sector average | 50 |
| 10–30% above sector average | 25 |
| >30% above sector average | 0 |

### Dimension 4: Governance & Transparency (15% weight)

| Factor | Score |
|--------|-------|
| Anti-corruption policy; code of conduct; ESG report published; SBTi committed | 100 |
| Most governance elements present; no ESG report | 70 |
| Basic code of conduct; no anti-corruption programme | 40 |
| No formal governance documents | 20 |
| Active bribery / corruption proceedings | 0 |

### Dimension 5: Supply Chain Transparency (10% weight)

| Transparency level | Score |
|-------------------|-------|
| Tier 1 and Tier 2 fully mapped and disclosed | 100 |
| Tier 1 fully mapped; Tier 2 partially | 70 |
| Tier 1 only known | 40 |
| Refuses to disclose subcontractors | 0 |

---

## Step 5: ESG Scorecard Output

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ESG COMPLIANCE SCORECARD
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Supplier:         [Name]
Country:          [Country]
Product:          [Category]
Destination:      [Market]
Assessment date:  [Date]
Assessor:         [Name]
Assessment type:  [Desk review / Questionnaire / On-site audit / Third-party]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

REGULATORY EXPOSURE
──────────────────────────────────────────────────────
Applicable regulations:
  ☐ UFLPA (USA)              Risk level: [High/Medium/Low]
  ☐ EUDR (EU)                Risk level: [High/Medium/Low]
  ☐ CBAM (EU)                Estimated annual cost: [USD/EUR]
  ☐ LkSG (Germany)           Compliance status: [Y/N/Partial]
  ☐ UK Modern Slavery Act     Statement required: [Y/N]
  ☐ Conflict Minerals         CMRT received: [Y/N]
  ☐ CSDDD (EU — upcoming)    Preparation level: [Early/None]

AUTOMATIC FAIL CHECK
──────────────────────────────────────────────────────
☐ Xinjiang / UFLPA entity involvement:     [None confirmed / RISK / CONFIRMED]
☐ Active WRO or import ban:                [None / ACTIVE]
☐ Child labour finding:                    [None / FINDING]
☐ Forced labour finding:                   [None / FINDING]
☐ Document confiscation:                   [None / FINDING]
☐ Deforestation violation (EUDR):          [None / FINDING]
──────────────────────────────────────────────────────
[If ANY automatic fail confirmed: STOP — do not score. Immediate exit recommended.]

ESG DIMENSION SCORES
──────────────────────────────────────────────────────
Dimension               Weight   Score    Weighted   Status
─────────────────────── ──────── ──────── ────────── ──────────────────────
Forced/Child Labour     30%      [X]/100  [X.X]      [Clean/Monitor/Risk/FAIL]
Labour Rights           25%      [X]/100  [X.X]      [Clean/Monitor/Risk/FAIL]
Environment             20%      [X]/100  [X.X]      [Clean/Monitor/Risk/FAIL]
Governance              15%      [X]/100  [X.X]      [Clean/Monitor/Risk/FAIL]
Supply Chain Transp.    10%      [X]/100  [X.X]      [Clean/Monitor/Risk/FAIL]
─────────────────────── ──────── ──────── ────────── ──────────────────────
COMPOSITE ESG SCORE:             [XX]/100
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RATING:
  80–100: ✅ ESG Preferred — meets or exceeds standards
  65–79:  🟡 ESG Approved — minor improvements required
  50–64:  🟠 ESG Conditional — improvement plan required; monitor closely
  35–49:  🔴 ESG Risk — significant remediation required before/after sourcing
  <35:    ⛔ ESG Fail — do not onboard / exit relationship

KEY FINDINGS
──────────────────────────────────────────────────────
🚨 Critical (must resolve before commercial relationship):
  1. [Finding — specific, evidenced]
  2. [Finding]

⚠️ Major (resolve within 90 days):
  1. [Finding]
  2. [Finding]

🔵 Minor (resolve within 12 months):
  1. [Finding]

✅ Strengths:
  1. [What the supplier does well — be specific]
  2. [Strength]

RECOMMENDED ACTIONS
──────────────────────────────────────────────────────
# | Action                           | Owner      | Deadline  | Consequence if missed
──┼───────────────────────────────────┼────────────┼───────────┼──────────────────────
1 | [Specific action]                 | Supplier   | [Date]    | Sourcing suspended
2 | [Specific action]                 | Buyer      | [Date]    | Internal
3 | [Specific action]                 | Both       | [Date]    | Escalate to review

DECISION
──────────────────────────────────────────────────────
☐ Approve — proceed with sourcing
☐ Conditional approval — resolve [specific items] by [date]
☐ Probationary — improvement plan mandatory; 6-month review
☐ Do not approve — [reason]
☐ Exit — [reason]; transition plan attached

Next assessment due: [Date]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 6: Forced Labour Red Flag Detection

The most legally consequential ESG risk. Apply this checklist to every new supplier in a high-risk country or product category.

### Structural Red Flags (supply chain level)

- ❌ Supplier is located in or sources materials from Xinjiang
- ❌ Supplier participates in any government-sponsored labour transfer, placement, or poverty alleviation programme that moves workers from one region to another
- ❌ Supplier is on the UFLPA Entity List (check: cbp.gov)
- ❌ Supplier uses prison, military, or state-supervised labour
- ❌ Supplier's raw material is sourced from a country with state-imposed forced labour (Turkmenistan cotton, North Korean exports)
- ❌ Tier 2 supplier is on a WRO or UFLPA Entity List even if Tier 1 is not

### Operational Red Flags (facility level)

- ❌ Workers cannot freely resign and leave the facility
- ❌ Workers' identity documents (passport, national ID, work permit) held by employer or recruiter
- ❌ Workers owe debt to employer or recruiter that must be "worked off"
- ❌ Workers paid far below market rate for the location and sector
- ❌ Workers housed in employer-controlled accommodation they cannot leave freely
- ❌ Workers from a specific ethnic, regional, or vulnerable group disproportionately represented without explanation
- ❌ CCTV monitoring of worker movements beyond standard security
- ❌ Workers cannot communicate freely with auditors or inspectors
- ❌ Workers unable to speak about their situation without a supervisor or manager present
- ❌ Workers coached on what to say before or during audit
- ❌ High workforce turnover with no explanation
- ❌ Workers recruited through a single agency with exclusive arrangement
- ❌ Payslips show regular deductions workers cannot explain
- ❌ Workers unaware of their employment terms or contract provisions

### Document Red Flags

- ❌ Factory unable or unwilling to disclose subcontractors or raw material origins
- ❌ Multiple inconsistent versions of payroll records
- ❌ Recruitment records do not match worker headcount
- ❌ Production records inconsistent with claimed labour hours
- ❌ Raw material invoices from unknown or unverifiable sources
- ❌ Certificate of origin claiming a country of manufacture inconsistent with actual production evidence

### UFLPA-Specific Due Diligence

If goods may have a Xinjiang nexus, additional documentation required:

1. **Supply chain mapping to raw material origin** — not just Tier 1; go to Tier 4 if necessary for cotton and polysilicon
2. **Input-output analysis** — is the volume of Xinjiang-origin raw material consistent with claimed production volumes?
3. **Mill certifications** — for cotton: STeP by OEKO-TEX, GOTS; and positive origin testing
4. **DNA or isotope tracing** — for cotton: Oritain, Applied DNA Sciences testing can confirm origin
5. **Affidavit from supplier** — signed declaration that no inputs from Xinjiang or UFLPA entities
6. **Third-party supply chain audit** — to Tier 2 and Tier 3 for high-risk categories

---

## Step 7: EUDR Compliance Checklist

For any product containing cattle/leather, cocoa, coffee, palm oil, soy, wood, rubber, or derivatives:

```
EUDR DUE DILIGENCE CHECKLIST
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Product:     [Name]
Commodity:   [Cattle / Cocoa / Coffee / Palm / Soy / Wood / Rubber]
Origin:      [Country, Region, Plot]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

INFORMATION REQUIREMENTS
─────────────────────────────────────────────────
☐ Description of product and commodity content
☐ Country of production
☐ Geolocation of plots/areas where commodity was produced:
  - GPS polygon or point coordinates for each plot
  - Area in hectares
☐ Producer/operator name and contact
☐ Quantity (mass or volume)

DEFORESTATION-FREE EVIDENCE
─────────────────────────────────────────────────
☐ Satellite imagery or remote sensing data confirming:
  - No forest cover loss on the production area after 31 Dec 2020
  - Data source: [Global Forest Watch / Satelligence / SarVision / equivalent]
☐ Forest definition applied: [FAO definition as adopted by EU regulation]
☐ Date of land use change (if any): [Must be before 31 Dec 2020]

LEGAL COMPLIANCE IN COUNTRY OF PRODUCTION
─────────────────────────────────────────────────
☐ Land tenure rights: producer holds legal rights to land
  (title deed, customary rights, lease — provide documentation)
☐ Environmental laws: production complies with applicable
  conservation laws (protected areas, biodiversity)
☐ Labour laws: compliant with applicable employment law
☐ Human rights: free, prior, and informed consent (FPIC) for
  indigenous peoples if land historically theirs

DUE DILIGENCE RISK ASSESSMENT
─────────────────────────────────────────────────
Country risk classification (EU designation):
  ☐ Low risk — simplified due diligence possible
  ☐ Standard risk — full due diligence required
  ☐ High risk — enhanced due diligence required + competent
    authority notification

Risk mitigation measures applied:
  [Describe what additional steps taken for non-low-risk origins]

DUE DILIGENCE STATEMENT
─────────────────────────────────────────────────
If the above is complete and satisfactory, the operator
(EU importer) must file a Due Diligence Statement (DDS) via
the EU EUDR information system before placing on EU market.
Reference number of filed DDS: [Number]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 8: CBAM Carbon Cost Estimator

For steel, aluminium, cement, fertilisers, electricity, and hydrogen imports into the EU:

```
CBAM COST ESTIMATE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Product:              [Name]
CBAM sector:          [Steel / Aluminium / Cement / Fertiliser /
                       Electricity / Hydrogen]
Origin country:       [Country]
Annual import volume: [X,000] tonnes
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

EMBEDDED CARBON CALCULATION
─────────────────────────────────────────────────
Embedded carbon intensity (supplier's):    [X] tCO2e/tonne
Default embedded carbon (EU default):      [X] tCO2e/tonne
[Use supplier's actual figure if certified; else use EU default]

Total embedded carbon:
  [X,000] tonnes × [X] tCO2e/tonne = [X,000] tCO2e

CBAM CERTIFICATE COST
─────────────────────────────────────────────────
EU ETS carbon price (current):  €[XX] per tCO2e
[Search current EU ETS price before calculation]

Annual CBAM cost:
  [X,000] tCO2e × €[XX] = €[X,XXX,XXX]

Carbon price already paid in origin country: €[X] per tCO2e
[If origin country has carbon pricing, this can be deducted]

Net CBAM liability: €[X,XXX,XXX] per year

IMPACT ASSESSMENT
─────────────────────────────────────────────────
CBAM cost as % of product value:  [X.X]%
Per-tonne product cost addition:  €[XX]/tonne

MITIGATION OPTIONS
─────────────────────────────────────────────────
1. Source from lower-carbon producer in same country:
   Potential saving at [lower carbon intensity]:  €[X,XXX]
2. Shift sourcing to country with carbon pricing
   (deductible carbon cost):  €[X,XXX] CBAM reduction
3. Renegotiate price with supplier to share CBAM burden:
   [X]% to supplier / [X]% to buyer
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 9: Conflict Minerals Assessment

For electronics, automotive, aerospace, jewellery, and any product potentially containing tin, tantalum, tungsten, or gold:

```
CONFLICT MINERALS ASSESSMENT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Product:      [Name]
3TG present:  ☐ Tin ☐ Tantalum ☐ Tungsten ☐ Gold ☐ None
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

STEP 1: REQUEST CMRT FROM SUPPLIER
─────────────────────────────────────────────────
Request Conflict Minerals Reporting Template (CMRT v6.x)
from each Tier 1 supplier. CMRT is a free industry standard
template from the Responsible Business Alliance (RBA).

CMRT received: ☐ Y ☐ N (follow up if not received within 14 days)

STEP 2: CMRT REVIEW
─────────────────────────────────────────────────
Check for:
☐ Is the product in scope? (contains 3TG)
☐ Country of origin declared for each 3TG metal
☐ Covered Countries (DRC, CAR, South Sudan, Rwanda, Uganda,
  Tanzania, Zambia, Angola, Republic of Congo, Burundi)
  involvement: ☐ Y ☐ N

STEP 3: SMELTER/REFINER LIST
─────────────────────────────────────────────────
All smelters and refiners identified by supplier:
☐ Reviewed against RMAP conformant smelter list
  (responsibleminerals.org — updated quarterly)
% of smelters/refiners RMAP conformant: [X]%

Non-conformant smelters (if any):
  [List — and action to qualify or replace]

STEP 4: RISK DETERMINATION
─────────────────────────────────────────────────
☐ No Covered Countries sourcing: DRC Conflict Free designation
☐ Covered Countries sourcing but all smelters RMAP: DRC Conflict Free
☐ Covered Countries sourcing; smelters not all RMAP: NOT Conflict Free
☐ Unable to determine: additional supplier engagement required
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 10: Modern Slavery Statement Support

For UK Modern Slavery Act and Australian Modern Slavery Act compliance:

The statement must cover (UK — six criteria; Australia — seven criteria):

```
MODERN SLAVERY STATEMENT — REQUIRED DISCLOSURES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. ORGANISATION STRUCTURE AND SUPPLY CHAINS
   - Business description and structure
   - Supply chains: countries sourced from; product categories;
     tier depth of supply chain

2. POLICIES IN RELATION TO SLAVERY AND TRAFFICKING
   - Modern slavery policy (if exists)
   - Supplier code of conduct
   - Procurement policy
   - Whistleblower/grievance policy

3. DUE DILIGENCE PROCESSES
   - How do you assess modern slavery risk in suppliers?
   - Supplier questionnaires issued: Y/N — coverage: X%
   - Third-party audits conducted: Y/N — how many: X
   - High-risk countries / sectors identified
   - How are identified risks addressed?

4. RISK ASSESSMENT AND MANAGEMENT
   - Risk identification methodology
   - Highest-risk parts of supply chain identified
   - Actions taken to address identified risks

5. KEY PERFORMANCE INDICATORS
   - % suppliers issued code of conduct
   - % suppliers with social compliance certification
   - Number of audits conducted
   - Number of issues identified and remediated
   - Grievances received and resolved

6. TRAINING
   - Who receives modern slavery training?
   - Training content and frequency
   - Senior leadership awareness

7. EFFECTIVENESS ASSESSMENT (Australia — additional)
   - How do you know if actions are working?
   - What has changed as a result of your actions?
   - What is not working and what will you do differently?

BOARD APPROVAL AND SIGNATURE
─────────────────────────────────────────────────
UK: Statement must be approved by the board and signed by
a director or equivalent.
Australia: Statement must be approved by the principal governing body.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 11: ESG Supplier Development Programme

For suppliers who score 50–79 — too important to exit but needing improvement:

```
ESG IMPROVEMENT PLAN — 12 MONTHS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Supplier:          [Name]
Current ESG score: [X]/100
Target ESG score:  [X]/100 by [Date]
Plan issued:       [Date]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PRIORITY IMPROVEMENTS (with buyer support offered)
─────────────────────────────────────────────────
1. [Finding] → [Specific action] → [By date]
   Buyer support: [Training / Cost sharing / Introduction to consultant]

2. [Finding] → [Specific action] → [By date]
   Buyer support: [Audit funding / Technical support]

3. [Finding] → [Specific action] → [By date]
   Buyer support: [Policy template / Introduction to NGO]

MILESTONES
─────────────────────────────────────────────────
Month 3:  [Milestone] — evidence required: [Document]
Month 6:  [Milestone] — assessment: [Re-assessment or self-declaration]
Month 12: Full re-assessment — target score: [X]/100

CONSEQUENCES IF MILESTONES MISSED
─────────────────────────────────────────────────
Month 3 fail:  Volume reduction [X]%; dual-source initiated
Month 6 fail:  Probationary status; last order placed
Month 12 fail: Exit — transition plan activated
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Related Skills
- `vendor-qualification` — ESG is a mandatory dimension of initial supplier qualification
- `sourcing-project-context` — for company ESG policy, blacklisted countries, certification requirements
- `contract-redlining` — ESG warranties, modern slavery, UFLPA representations belong in every supplier contract
- `resilience-geopolitical-radar` — regulatory changes and enforcement actions are supply chain disruption events
- `rfq-drafting` — ESG requirements must be specified in the RFQ before suppliers even quote
- `tariff-hs-lookup` — CBAM assessment requires correct HS/tariff classification and origin
- `supplier-performance-scorecard` — ESG compliance is a scored dimension of ongoing supplier performance
- `negotiation-playbook` — ESG certification costs may be a legitimate commercial concession to negotiate
