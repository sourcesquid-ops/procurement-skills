---
name: dfm-bridge
description: Use this skill when the user wants to review a product design, CAD drawing, 3D model description, or specification from a manufacturing perspective before sending an RFQ. Also trigger when the user mentions "DFM", "design for manufacturing", "design for manufacture", "tooling cost review", "will this be expensive to make", "can the factory make this", "design review before quoting", "reduce tooling cost", "simplify for production", "factory feedback on design", or uploads a drawing or spec sheet. This skill critiques any product design through the factory's eyes — identifying features that drive up cost, increase rejection rates, or create manufacturability issues — before money is spent on tooling or sampling. Works across all manufacturing processes: injection moulding, die casting, CNC machining, sheet metal fabrication, forging, extrusion, PCB assembly, textile/cut-and-sew, thermoforming, 3D printing, composite layup, blow moulding, and more.
---

# DFM Bridge

Critiques a product design from the factory's perspective — identifying what will be expensive, difficult, slow, or risky to manufacture — before the RFQ goes out and tooling money is committed. This is the skill that saves the most money per hour of use.

**Core philosophy:** The best time to reduce cost is before the mould is cut, not after.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Note target country of manufacture, quality standards, and cost targets. These affect which manufacturing process is appropriate and what trade-offs are acceptable.

## Workflow

### Step 1: Understand the Product and Process

Gather from the user (or extract from attached drawing/spec):

- Product name and function
- Intended manufacturing process (or ask if unknown)
- Target material(s)
- Target country/region of manufacture
- Annual production volume
- Target unit cost (if known)
- Is tooling new or existing?
- Any non-negotiable design features (aesthetic requirements, functional constraints, regulatory geometry)?

If the user uploads a drawing, image, or spec, analyse it before proceeding.

### Step 2: Select Process-Specific DFM Rules

Load the relevant section from `references/process-dfm-rules.md` based on the manufacturing process:

| Process | When to apply |
|---------|---------------|
| Injection moulding | Plastic parts, high volume, complex geometry |
| Die casting (zinc/aluminium) | Metal parts, medium-high volume, tight tolerance |
| CNC machining | Low volume, tight tolerance, complex metal/plastic |
| Sheet metal fabrication | Enclosures, brackets, stampings, weldments |
| Forging (open/closed die) | High-strength structural parts, high volume |
| Extrusion (aluminium/plastic) | Constant cross-section profiles |
| PCB / Electronics assembly | Boards, PCBA, SMT components |
| Textile / Cut-and-sew | Apparel, bags, soft goods, technical fabric |
| Thermoforming / Vacuum forming | Thin-wall plastic trays, covers, shells |
| Blow moulding | Hollow plastic containers, bottles |
| 3D printing (FDM/SLS/SLA) | Prototypes, low volume, complex geometry |
| Composite / Fibre layup | Carbon fibre, fibreglass, structural composites |
| Wood / Furniture | Solid wood, MDF, plywood, joinery |
| Casting (investment/sand) | Complex metal parts, low-medium volume |
| Stamping / Progressive die | High-volume metal parts, flat geometry |
| Bio-material / Compression moulding | Natural fibre composites, rice husk, coffee ground |

### Step 3: Run the DFM Critique

Analyse the design against the loaded process rules. Structure your critique in five dimensions:

---

#### DIMENSION 1: Geometry & Features

Review every geometric feature. Flag:

- **Undercuts**: Features that prevent part ejection from the mould/die. Each undercut requires a side action or lifter — adds $500–$5,000+ to tooling cost and complexity.
- **Draft angles**: Insufficient draft (typically <1°) causes drag marks, sticking, and rejection. Flag every vertical wall.
- **Wall thickness**: Inconsistent wall thickness causes sink marks, warpage, and internal voids. Ideal: uniform, within process-specific range.
- **Sharp corners / fillets**: Internal sharp corners create stress concentration and tool wear. External sharp corners create flash and safety risks.
- **Thin sections**: Below minimum wall for process — will have fill issues or require special gating.
- **Bosses and ribs**: Check height-to-width ratio, proximity to wall, rib thickness vs. wall thickness.
- **Tolerances**: Flag any tolerance tighter than the process naturally achieves — will require secondary operations or precision tooling.
- **Symmetry**: Asymmetric parts that could be symmetrised reduce tooling cavities and handling errors.

#### DIMENSION 2: Material Selection

- Is the specified material appropriate for the process?
- Is it available in the target manufacturing country (e.g., specific grades may not be locally stocked in Vietnam or Turkey)?
- Is there a lower-cost alternative with equivalent performance?
- Does the material require special handling (drying, controlled humidity, clean room)?
- For food/pharma contact: is food-grade / medical-grade grade specified explicitly?
- For sustainability: is recycled content viable? Does it affect structural performance?
- For electronics: RoHS-compliant? Halogen-free?

#### DIMENSION 3: Tooling & Setup Cost Drivers

Flag items that increase tooling cost:

- Number of cavities needed (1-cavity vs. multi-cavity tool)
- Tool steel grade required (P20 vs. H13 vs. S136 — driven by abrasive material or high volume)
- Hot runner vs. cold runner (hot runner adds $3,000–$15,000 but eliminates sprues)
- Surface finish requirements (mirror polish, EDM texture, spark erosion)
- Number of side actions (each adds ~$1,000–$3,000)
- Inserts (threaded, heat-set, overmoulded)
- Secondary operations: painting, plating, pad printing, assembly, ultrasonic welding
- Number of separate components that could be combined

**Quick wins — common cost reductions:**
- Eliminating one side action by redesigning the undercut = save $1,500–$4,000
- Standardising wall thickness = reduce warpage rejects by 30–60%
- Adding 2° draft = eliminate secondary polishing operation
- Combining two parts into one = eliminate an assembly step

#### DIMENSION 4: Quality & Rejection Risk

- Which features are most likely to cause defects at the factory?
- What inspection challenge will this create? (Hidden surfaces, tight bores, complex profiles)
- What is the expected first-pass yield for this design? (Flag if likely below 90%)
- Are there features that make visual inspection difficult or subjective?
- Are critical dimensions on the drawing actually measurable with standard CMM / go-no-go gauges?
- Will the product require a PPAP, FMEA, or control plan?

#### DIMENSION 5: Assembly & Logistics

- Can the part be assembled without fixtures? (Poka-yoke features present?)
- Packaging: will the geometry cause damage in transit? (Thin protrusions, snap features)
- Stack height: does the geometry allow efficient packing (flat-pack vs. bulky)?
- Orientation: is there a risk of wrong-way assembly?
- Serviceability: can it be disassembled for repair?

---

### Step 4: Prioritise and Score

Score each finding:

| Severity | Definition | Action |
|----------|-----------|--------|
| 🔴 Critical | Will fail to manufacture or cause >20% reject rate | Must fix before RFQ |
| 🟡 Major | Adds significant cost or risk; fix recommended | Fix before tooling commit |
| 🟢 Minor | Optimisation opportunity; low-cost improvement | Implement if time allows |

Present findings as a structured report:

```
DFM CRITIQUE REPORT
Product: [Name]
Process: [Manufacturing process]
Target country: [Country]
Review date: [Date]

CRITICAL ISSUES (must fix before RFQ)
1. [Issue] — [Location on drawing] — [Impact] — [Recommended fix]

MAJOR ISSUES (fix before tooling commit)
2. [Issue] — [Location] — [Estimated cost/risk] — [Recommended fix]

MINOR OPTIMISATIONS (implement if possible)
3. [Issue] — [Opportunity] — [Benefit]

ESTIMATED TOOLING COST IMPACT IF ISSUES LEFT UNFIXED: $X,XXX – $XX,XXX
ESTIMATED UNIT COST IMPACT: $X.XX per unit (at [volume])

RECOMMENDED NEXT STEPS
1. [Specific action with owner]
2. [Action]
3. Schedule DFM review call with top 2 shortlisted suppliers before committing to tool
```

### Step 5: Supplier DFM Recommendation

After internal DFM, advise the user to:

1. **Include the DFM report in the RFQ package** — ask suppliers to confirm or challenge the findings. A factory that identifies additional issues is more engaged and more trustworthy.
2. **Request a supplier DFM feedback form** — many good factories will do this free of charge before tooling commit.
3. **Negotiate tooling payment in milestones** — never pay 100% upfront. Standard: 50% on PO, 30% on T1 sample approval, 20% on first production approval.
4. **Request 2D drawing sign-off** — before cutting any tool, get factory to sign the 2D drawing acknowledging dimensions.

### Step 6: Optional — Should-Cost Estimate

After DFM critique, offer to run `should-cost-modelling` using the cleaned-up design to estimate what the product should cost to manufacture.

## Process-Specific Quick Reference

**Injection moulding red flags:**
- Wall thickness variation >25% between adjacent sections
- Draft angle <0.5° on textured surfaces (need 3–5°)
- Rib height >3× wall thickness
- Boss diameter <2× insert diameter
- Gate location on visible surface without texture to hide mark

**Die casting red flags:**
- Wall thickness <0.8mm for zinc, <1.5mm for aluminium
- Unrealistic tolerances (die cast: ±0.1mm achievable; ±0.01mm needs machining)
- Complex internal cavities (die casting is open-face only)
- Porosity-sensitive applications (pressure vessel, structural load)

**Sheet metal red flags:**
- Bend radius <1× material thickness
- Hole-to-edge distance <1.5× material thickness
- Feature proximity to bend line <3× material thickness
- Missing bend allowance in flat pattern

**Textiles red flags:**
- Seam allowance not specified (<6mm is difficult)
- Mixed fibre content without testing protocol
- Complex pattern with multiple small panels (labour cost driver)
- Colour matching without Pantone reference

**PCB/electronics red flags:**
- Component placement <0.1mm from board edge
- Via-in-pad without filled/capped vias specified
- Impedance-controlled traces without stackup defined
- Conflicting silkscreen and copper layers

## Related Skills
- `rfq-drafting` — after DFM, use this to write the RFQ incorporating fixes
- `should-cost-modelling` — estimate cost impact of design changes
- `vendor-qualification` — assess whether shortlisted factories have DFM capability
- `sourcing-project-context` — for company and project context

## Reference Files
- `references/process-dfm-rules.md` — detailed rules per manufacturing process (load relevant section)
