---
name: supplier-outreach
description: Use this skill when the user wants to write emails, messages, or outreach sequences to contact manufacturers or suppliers for the first time, follow up on RFQs, or communicate with factories. Also trigger when the user says "write an email to a supplier", "contact a factory in China", "follow up on my RFQ", "draft a sourcing inquiry", "write to a manufacturer in Vietnam / India / Turkey / Bangladesh", "supplier introduction email", "how do I reach out to factories on Alibaba", or needs any written communication directed at a supplier or manufacturer. Produces culturally appropriate, professional outreach in English and optionally in the supplier's local language (Chinese, Vietnamese, Hindi, Turkish, Spanish, Arabic, German, Bengali, etc.). Includes cold outreach, RFQ cover emails, follow-up sequences, sample request emails, and negotiation openers.
---

# Supplier Outreach

Writes professional, culturally appropriate supplier communications — from cold initial contact through to negotiation. Multi-language. Structured for high response rates.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Use company name, product, commercial parameters, and Incoterms to pre-fill emails. Don't ask for information already in context.

## Communication Types

| Type | When to use | Template |
|------|-------------|----------|
| Cold intro + capability inquiry | First contact, no prior relationship | Template A |
| RFQ cover email | Sending an RFQ document to factory | Template B |
| Sample request | Requesting pre-production samples | Template C |
| Follow-up (no response) | Chasing after 5–7 days of silence | Template D |
| Negotiation opener | Opening price negotiation after quote | Template E |
| PO confirmation | Placing first order | Template F |
| Quality issue notification | Flagging defects or concerns | Template G |
| Relationship maintenance | Staying warm with existing suppliers | Template H |

## Workflow

### Step 1: Context Gathering

Ask:
- Type of communication needed
- Supplier name and contact name (if known)
- Supplier country (determines language option and cultural tone)
- Product being discussed
- What is the user's goal for this communication?
- Any specific points to emphasise or avoid?

### Step 2: Draft the Communication

---

**TEMPLATE A — Cold Introduction + Capability Inquiry**

```
Subject: Sourcing Inquiry — [Product Category] — [Your Company Name]

Dear [Supplier Name / Factory Name Team],

My name is [Name] and I am the [Title] at [Company Name], based in [City, Country].

We are a [brief company description: e.g., "product development company specialising in sustainable homeware"] currently in the process of identifying manufacturing partners for [product category].

We came across your company via [Alibaba / Google / trade fair / referral] and your profile suggests you may be a strong fit for our requirements.

We are looking for:
- Product: [Product name and brief description]
- Annual volume: [Approx. quantity]
- Timeline: [First order expected by / target date]
- Quality standard: [ISO 9001 / CE / FDA / other]

To help us assess compatibility, could you please share:
1. Your factory profile and production capabilities for this product
2. Relevant certifications
3. A brief pricing indication (EXW or FOB [port]) for the volumes above
4. Current lead time for a first order
5. Whether you can supply samples before bulk order

We look forward to hearing from you. If you have questions, please don't hesitate to reach out directly.

Best regards,
[Name]
[Title]
[Company Name]
[Email] | [Phone/WhatsApp]
[Website]
```

**TEMPLATE B — RFQ Cover Email**

```
Subject: RFQ-[Number] | [Product Name] | [Your Company Name] — Response Required by [Date]

Dear [Contact Name],

Thank you for your interest in working with [Company Name].

Please find attached our Request for Quotation (RFQ-[Number]) for [Product Name]. We are actively evaluating [X] suppliers for this project and plan to place a first order with our selected partner within [timeframe].

Key details:
- Product: [Name]
- Volume: [Quantity per order] / [Annual forecast]
- Delivery terms: [Incoterms + Port]
- Required delivery: [Date]
- Response deadline: [Date]

Please submit your quote in the format specified in the RFQ document. If you have any technical questions about the specification, contact [Name] at [email].

We look forward to receiving your competitive quotation.

Best regards,
[Name]
```

**TEMPLATE C — Sample Request**

```
Subject: Sample Request — [Product Name] — [Your Company Name]

Dear [Name],

Following our initial discussions about [Product Name], we would like to proceed to the sample stage.

Please provide:
- [X] units of [product / specification reference]
- Finish: [colour, texture, surface treatment]
- Packaging: [how the sample should be packed]

Please confirm:
- Sample cost: USD [___]
- Sample lead time: [___] working days
- Courier account: We will use our DHL account [account number] / Please invoice sample courier separately

Our delivery address for samples:
[Name]
[Company]
[Full address including postal code and country]
[Phone for courier]

Please send a sample tracking number once dispatched.

Best regards,
[Name]
```

**TEMPLATE D — Follow-Up (No Response)**

```
Subject: Follow-up: [Original subject line] — [Your Company Name]

Dear [Name],

I am following up on my email of [date] regarding [product / RFQ reference].

We are keen to move forward and would appreciate your response by [new date] to stay on our evaluation timeline.

If you have any questions or if this product is outside your current production scope, please let me know — we are happy to discuss.

Best regards,
[Name]
```

**TEMPLATE E — Negotiation Opener**

```
Subject: Re: Quotation [RFQ-Number] — [Product Name] — [Your Company Name]

Dear [Name],

Thank you for your quotation dated [date]. We appreciate the detail provided.

We have reviewed your pricing and want to work with you on this project. However, for us to move forward, we need to align on the following:

1. Unit price: Your quote of [USD X.XX] FOB [Port] is above our target of [USD X.XX]. Based on our analysis of material and production costs at [volume], we believe [USD X.XX] is achievable. Can you review?

2. [If applicable] Payment terms: We propose [30% advance, 70% against BL] rather than [supplier's proposed terms].

3. [If applicable] MOQ: We would like to start with [quantity] — can you accommodate this for the first order?

We are ready to commit to a first PO of [volume] if we can align on the above. We are also open to discussing a multi-order commitment to support better pricing.

Please let us know your best position on the above points.

Best regards,
[Name]
```

---

### Step 3: Language Output

**Chinese (Simplified) — for mainland China:**
Generate full Chinese translation of the email. Key phrases:
- "您好" (formal greeting if no name) / "尊敬的[Name]" (Dear [Name] formal)
- Always include English version alongside Chinese — most Chinese factory export staff prefer bilingual correspondence
- WeChat / WhatsApp preference: shorter, more direct messages work better on messaging apps

**Vietnamese:**
- "Kính gửi [Name]" (Dear [Name])
- Formal Vietnamese business tone
- Include English version

**Hindi/English (India):**
- India factory comms are almost always in English — Hindi version rarely needed
- Include WhatsApp-friendly shorter version

**Turkish:**
- "Sayın [Name]" (Dear [Name])
- Turkish suppliers appreciate formal tone for initial contact

**Spanish (Mexico / LATAM):**
- "Estimado/a [Name]"
- LATAM suppliers: include WhatsApp number in signature — WhatsApp is primary B2B channel

**Arabic (Middle East):**
- "عزيزي [Name]"
- Right-to-left format; include English version

**German / Polish / Romanian (Eastern Europe):**
- "Sehr geehrte/r [Name]" (German)
- "Szanowny/a Pan/i [Name]" (Polish)
- Include English version; most Eastern European factory staff have strong English

**Bengali (Bangladesh):**
- "প্রিয় [Name]"
- RMG sector: English is universally used; Bengali version is rare but builds goodwill

### Step 4: Channel Guidance

**Email:** Professional, full templates above. Attach RFQ/docs.

**Alibaba messaging:** Shorter version. Maximum 150 words for first message. Include product title from their listing. No attachments in first message.

**WhatsApp/WeChat:** Maximum 3–4 sentences. Casual but professional. Follow with "Can I send you our RFQ document?" Do not send full specs on first message.

**LinkedIn:** For management contact at suppliers. Keep to 2–3 sentences. Request connection before pitching.

### Step 5: Response Rate Optimisation

Tips to include with outreach:
- Send at supplier's local morning (9–11am their time): China → 9–11am CST (UTC+8); India → 10am IST; Vietnam → 9am ICT
- Subject line should include product name — "Sourcing Inquiry" alone gets ignored
- WhatsApp video of sample or sketch increases response rate vs. text-only
- First message on Alibaba: reference something specific from their storefront to show you actually visited
- Follow up sequence: Day 1 (send), Day 5 (follow up 1), Day 10 (follow up 2 — different channel), Day 15 (final, move on)

## Related Skills
- `rfq-drafting` — the document that accompanies Template B
- `vendor-qualification` — run before committing to a supplier who responds positively
- `incoterms-advisor` — ensure correct Incoterms are stated in all outreach
- `sourcing-project-context` — for company profile and product details
