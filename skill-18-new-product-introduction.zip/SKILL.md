---
name: new-product-introduction
description: Use this skill when the user wants to manage, plan, or execute a new product introduction (NPI), product launch from a new supplier, or first-time production of a new item. Trigger when the user says "NPI", "new product introduction", "first article", "T1 samples", "tooling approval", "PPAP", "golden sample", "pre-production approval", "sample sign-off", "production trial", "first production run", "supplier qualification for new product", "design to production", "product launch timeline", or "manufacturing readiness". Covers the full NPI gate review framework from design freeze through first commercial shipment. Works for any product category, any manufacturing process, any supplier country.
---

# New Product Introduction (NPI)

The bridge between a product design and a commercially viable, reliably manufactured item. NPI is where most sourcing failures are born — not in production, but in the rushed, underdisciplined process of getting from sample approval to mass production. This skill encodes a rigorous, gate-controlled NPI framework that catches problems before they become expensive.

**Core philosophy:** Every hour spent in NPI saves ten hours in production firefighting. Every dollar spent on proper sample qualification saves a hundred dollars in field failures, recalls, and supplier disputes. The gate is there to protect you — don't skip it.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Extract: product category, manufacturing process, supplier country, quality standards required, target launch date, and any existing tooling or sample history.

---

## Step 1: NPI Mode Selection

Identify which NPI scenario applies:

| Scenario | Description | Risk level | Gate strictness |
|----------|-------------|------------|-----------------|
| **New product, new supplier** | First time sourcing this item from this factory | Highest | Full gates — no shortcuts |
| **New product, existing supplier** | Known factory, new item category | High | Full gates with supplier familiarity credit |
| **Existing product, new supplier** | Re-sourcing a known item from a new factory | High | Compressed but complete gates |
| **Product change, existing supplier** | Design or specification change on running item | Medium | Change-controlled NPI from change point |
| **Product line extension** | Adding variant (colour, size, SKU) to existing item | Lower | Abbreviated gates; focus on delta changes only |
| **Tooling refresh / new tool** | Same product, new or replacement mould/die | Medium | Tool-specific qualification |

---

## Step 2: NPI Gate Framework Overview

The NPI process runs through six sequential gates. No gate may be passed without documented evidence. Skipping a gate is a decision — not an oversight — and must be recorded with rationale and risk acceptance sign-off.

```
DESIGN     SUPPLIER    TOOLING     SAMPLE      PRE-PROD    PRODUCTION
FREEZE  →  AWARD    →  BUILD    →  APPROVAL →  TRIAL    →  RELEASE
  G0          G1          G2          G3          G4          G5

G0: Design Freeze & DFM Review
G1: Supplier Award & NPI Kick-off
G2: Tooling Completion & T0 Samples
G3: T1/T2 Sample Approval
G4: Pre-Production Trial (PPT) & PPAP
G5: First Production Release & Ramp
```

Each gate has: entry criteria (what must be true to enter), activities (what happens during), and exit criteria (what must be confirmed to pass).

---

## Gate 0: Design Freeze and DFM Review

**Purpose:** Confirm the design is complete, manufacturable, and will not change during tooling. Changes after Gate 0 cost money — changes after Gate 2 cost a lot of money.

**Entry criteria:**
- Product specification document completed and version-controlled
- Intended manufacturing process identified
- Target cost defined (use `should-cost-modelling` skill)
- Regulatory and compliance requirements identified

### G0 Checklist

```
GATE 0 — DESIGN FREEZE AND DFM REVIEW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DESIGN DOCUMENTATION COMPLETE
☐ 2D engineering drawing — revision-controlled, all dimensions toleranced
☐ 3D model (STEP/STP) — matches 2D drawing
☐ Bill of Materials (BOM) — all materials specified with grades
☐ Product specification — performance requirements, test methods
☐ Approved reference sample (if applicable — golden sample from previous supplier)
☐ Colour standard — Pantone reference, RAL code, or physical chip
☐ Packaging specification — inner and outer

REGULATORY SIGN-OFF
☐ Applicable standards identified: [ISO / CE / BIS / FDA / RoHS / REACH / FSC / etc.]
☐ Required certifications mapped: [List certifications needed on finished product]
☐ Restricted substances checked: [REACH SVHC, RoHS, Prop 65 as applicable]
☐ Country of destination labelling requirements confirmed

DFM (DESIGN FOR MANUFACTURING) REVIEW
☐ DFM review completed using `dfm-bridge` skill
☐ Critical DFM findings resolved or risk-accepted
☐ Draft angle, wall thickness, undercuts reviewed (for moulded parts)
☐ Tolerances achievable by target manufacturing process confirmed
☐ Material availability confirmed in target manufacturing country
☐ Tooling type and estimated tooling cost confirmed

COST SIGN-OFF
☐ Should-cost model completed
☐ Target unit cost approved
☐ Tooling budget approved
☐ NPI project budget (samples, testing, travel) approved

CHANGE CONTROL
☐ Design freeze declared — version: [Rev X]
☐ Change control process defined: any post-freeze change requires
  [Name/Title] sign-off and NPI schedule impact assessment
☐ Open design issues: [None / List with resolution plan and owner]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
G0 DECISION: ☐ PASS  ☐ PASS WITH CONDITIONS  ☐ HOLD
Conditions / open items: ________________________________
Signed off by: ________________________ Date: __________
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Gate 1: Supplier Award and NPI Kick-off

**Purpose:** Select the manufacturing partner, issue the tooling PO, align on the NPI schedule, and formally kick off the program at the supplier.

**Entry criteria:** G0 passed. RFQ completed. Supplier selected and commercially agreed.

### G1 Checklist

```
GATE 1 — SUPPLIER AWARD AND NPI KICK-OFF
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SUPPLIER SELECTION COMPLETE
☐ Supplier qualification completed (`vendor-qualification` skill)
☐ Quote compared against should-cost — variance acceptable
☐ NDA signed
☐ Supplier accepted quality requirements in writing
☐ Supplier's DFM feedback reviewed and incorporated (if any)

COMMERCIAL TERMS AGREED
☐ Unit price confirmed for production volumes
☐ Tooling cost confirmed and payment milestones agreed
☐ Lead time for first production confirmed
☐ MOQ for production agreed
☐ Payment terms for production agreed
☐ Tooling ownership clause confirmed (buyer owns tooling)

TOOLING PURCHASE ORDER ISSUED
☐ Tooling PO issued with:
  ☐ Tooling description and drawing reference
  ☐ Number of cavities
  ☐ T1 sample delivery date
  ☐ Payment milestone schedule
  ☐ Tooling ownership clause
  ☐ T1 sample requirements and approval process
  ☐ Penalty for late T1 delivery (if applicable)

NPI KICK-OFF MEETING COMPLETED
☐ Kick-off meeting held (in person or video) with supplier
☐ Attendees: [buyer NPI lead, supplier production manager, quality manager, tooling manager]
☐ NPI schedule agreed and signed by both parties
☐ Key contacts and escalation path confirmed
☐ Tooling drawing sign-off completed — supplier signed 2D drawing
   acknowledging all dimensions before cutting begins
☐ Weekly NPI status update cadence agreed: [Day and time]

NPI SCHEDULE
────────────────────────────────────────────────────────
Milestone                    Target Date   Owner      Status
─────────────────────────────────────────────────────────
G0 Design freeze             [Date]        Buyer      ✓ Done
G1 Tooling PO issued         [Date]        Buyer      ✓ Done
   Tooling machining start   [Date]        Supplier
   Tooling trial shots       [Date]        Supplier
G2 T0 samples to buyer       [Date]        Supplier
   T0 review and feedback    [Date]        Buyer
   Tooling correction        [Date]        Supplier
G3 T1 samples to buyer       [Date]        Supplier
   T1 dimensional report     [Date]        Supplier
   T1 test reports           [Date]        Buyer/Lab
   T1 approval               [Date]        Buyer
G4 Pre-production trial      [Date]        Supplier
   PPAP submission           [Date]        Supplier
   PPAP approval             [Date]        Buyer
G5 First production PO       [Date]        Buyer
   First production ready    [Date]        Supplier
   First shipment            [Date]        Supplier
Target: First commercial shipment          [Date]
─────────────────────────────────────────────────────────

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
G1 DECISION: ☐ PASS  ☐ PASS WITH CONDITIONS  ☐ HOLD
Signed off by: ________________________ Date: __________
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Gate 2: Tooling Completion and T0 Samples

**Purpose:** Verify tooling is built correctly before investing in corrections. T0 (Trial 0) samples are the raw output of the new tool — unadjusted, unselected. They show the tool's current capability and what corrections are needed.

**Entry criteria:** G1 passed. Tooling construction complete. T0 samples produced.

**Note:** Many programs skip T0 and go straight to T1 — this is acceptable for low-complexity tooling (simple shapes, wide tolerances). For complex tools, T0 saves significant time and money by catching tool errors before claiming T1 approval.

### G2 Checklist

```
GATE 2 — TOOLING COMPLETION AND T0 REVIEW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TOOLING STATUS
☐ Tool construction complete — supplier confirmation received
☐ Tool trial shots completed — [X] shots per cavity
☐ T0 samples shipped to buyer: tracking number [___]
☐ Tooling payment Milestone 1 triggered (if milestone is tool completion)

T0 SAMPLE REVIEW CHECKLIST
☐ One sample from each cavity (label which cavity each sample is from)
☐ Visual review against drawing and reference:
  ☐ Overall shape and dimensions — gross check
  ☐ Surface finish — acceptable / to be corrected
  ☐ Gate location and gate vestige — acceptable / to be corrected
  ☐ Ejector pin marks — location and severity
  ☐ Parting line — location and flash level
  ☐ Any sink marks, warpage, short shots, flow lines
  ☐ Colour (if applicable) — against Pantone / reference chip
  ☐ Any labels, engravings, or logos — readability and position
☐ Spot check key dimensions with calipers/CMM
☐ Snap-fit / press-fit / assembly check (if applicable)

T0 FINDINGS REPORT
Document every finding with:
  - Finding number
  - Description and location on part
  - Photo
  - Root cause (tool issue / process issue / design issue)
  - Required correction
  - Who is responsible (supplier / tool maker / buyer design change)
  - Correction deadline

TOOLING CORRECTION DECISION
☐ No corrections required — proceed directly to T1
☐ Minor corrections required — supplier to correct and produce T1
  Correction list: [List or attach]
  T1 target date after correction: [Date]
☐ Major corrections required — T0 review meeting with supplier required
  Meeting date: [Date]
☐ Tool redesign required — NPI schedule impact: [+X weeks]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
G2 DECISION: ☐ PASS TO T1  ☐ CORRECT AND RESUBMIT  ☐ HOLD
Open correction items: [Number and list]
T1 target date: [Date]
Signed off by: ________________________ Date: __________
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Gate 3: Sample Approval (T1 / T2)

**Purpose:** Confirm the tool produces parts that meet all dimensional, visual, material, and functional requirements. This is the most critical gate — T1 approval is the green light for tooling payment Milestone 2 and for proceeding to production.

**Entry criteria:** G2 passed. Tooling corrections complete. T1 samples produced.

### T1 Sample Review — Full Protocol

```
GATE 3 — T1/T2 SAMPLE APPROVAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SAMPLE SUBMISSION REQUIREMENTS (supplier to provide)
☐ Minimum [5] samples per cavity (label clearly: Cav 1, Cav 2, etc.)
☐ Full dimensional report:
  ☐ All dimensions on drawing measured and reported
  ☐ Measured using [CMM / optical comparator / calibrated calipers]
  ☐ Report format: bubble drawing + measurement table
  ☐ Measurement equipment calibration certificate attached
☐ Material certificate:
  ☐ Confirms specified material grade/compound was used
  ☐ Lot number traceable to material supplier
  ☐ Material test data (MFI, tensile, density, etc.) if required
☐ Process parameters record (injection moulding):
  ☐ Injection pressure, temperature, cooling time, cycle time
  ☐ Confirms parts produced at production-representative conditions
  ☐ NOT optimised for samples only — this is critical
☐ Colour confirmation:
  ☐ Measured against Pantone/RAL/buyer colour standard
  ☐ Spectrophotometer reading (L*a*b* values) if required
☐ Surface finish confirmation:
  ☐ Profilometer reading (Ra value) if specified
  ☐ Visual comparison against approved surface standard

DIMENSIONAL REVIEW
☐ All critical dimensions (annotated on drawing) — MUST be in tolerance
☐ All major dimensions — must be in tolerance
☐ Minor dimensions — record actuals; deviations to be assessed
☐ Cavity-to-cavity consistency — all cavities must perform equally

Dimensional outcome:
  ☐ All dimensions in tolerance — proceed
  ☐ Minor deviations — deviation request process (below)
  ☐ Critical dimension out of tolerance — tooling correction required
  ☐ Multiple dimensions out — tool redesign discussion required

VISUAL AND AESTHETIC REVIEW
☐ Surface finish — matches approved standard / free of defects
☐ Colour — within acceptable range of standard
☐ Texture — matches specified texture
☐ Logos, engravings, markings — correct, readable, correct depth
☐ Flash — level acceptable / requires correction
☐ Sink marks — none visible / within acceptable range
☐ Weld lines — location acceptable / not in critical area
☐ Gate mark — acceptable size and location / to be dressed
☐ Overall visual appearance — pass / fail vs. golden sample

FUNCTIONAL REVIEW
☐ Assembly check: part assembles correctly with mating parts
☐ Snap-fit: engagement and retention force within specification
☐ Clearance: all mating clearances correct
☐ Mechanical function: [Describe function test] — pass / fail
☐ Drop test / handling test (if applicable)
☐ Weight — actual vs. nominal: [X.XX g vs. X.XX g spec]

MATERIAL AND COMPLIANCE TESTING (send to accredited lab if required)
☐ Chemical composition / material analysis
  Test method: [FTIR / XRF / GC-MS]  Lab: _______________
  Result: _____________ vs. spec: _____________ [Pass/Fail]
☐ Mechanical properties (tensile, flexural, impact)
  Standard: [ISO / ASTM]  Result: [Pass/Fail]
☐ Flammability (if applicable)
  Standard: [UL94 / BS5852 / EN 13501]  Result: [Pass/Fail]
☐ Migration testing (for food contact materials)
  Standard: [EN 1186 / FDA 21 CFR]  Result: [Pass/Fail]
☐ RoHS screening (for electronics / electrical)
  Method: [XRF screening + wet chemistry for marginals]
  Result: [Pass/Fail]
☐ REACH SVHC (>0.1% threshold)
  Result: [Pass/Fail]
☐ [Product-specific certification test]: _________________
  Result: [Pass/Fail]

DEVIATION REQUEST PROCESS
For any dimension or attribute that cannot be met as drawn but
the deviation does not affect function or safety:

Deviation Request Form fields:
  - Drawing dimension reference (bubble number)
  - Nominal / tolerance on drawing
  - Actual measured value
  - Reason change cannot be met at drawing spec
  - Functional impact assessment (why is this acceptable)
  - Proposed alternative tolerance
  - Duration: permanent deviation or until drawing update

Deviations must be approved in writing by buyer's engineering/
quality representative before T1 is approved with deviation.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
T1 APPROVAL DECISION

☐ FULL APPROVAL — all dimensions, visual, functional, materials pass
  → Trigger: Tooling payment Milestone 2
  → Action: Proceed to G4 Pre-Production Trial

☐ CONDITIONAL APPROVAL — minor open items, non-critical
  Open items: _________________________________________
  Resolution deadline: ________________________________
  → Action: Proceed to G4 while resolving open items
  → Condition: Full approval required before first production release

☐ PARTIAL APPROVAL — proceed on some cavities only
  Approved cavities: ___________________________________
  Rejected cavities: ___________________________________
  Correction required: _________________________________
  → Action: Proceed on approved cavities; correct rejected cavities

☐ REJECTED — significant dimensional or functional failures
  Key failures: _______________________________________
  Tooling correction required: _________________________
  T2 sample required by: [Date]
  → Action: Do NOT proceed. Tooling correction first.

Golden Sample designation:
  ☐ One approved T1 sample designated as Golden Sample
  ☐ Marked and serialised: [Golden Sample Ref: GS-XXXXXX-[Date]]
  ☐ One copy retained by buyer; one copy held at supplier
  ☐ All future production checked against this Golden Sample

Signed off by: [Name, Title] Date: __________
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Gate 4: Pre-Production Trial and PPAP

**Purpose:** Confirm the supplier can produce the product consistently at production speed, with production operators, production materials, and production process parameters. The Pre-Production Trial (PPT) is where process capability is established.

**Entry criteria:** G3 passed. Golden Sample approved. Production schedule aligned.

### PPAP — Production Part Approval Process

PPAP (from the automotive industry, now widely used across manufacturing) is a formal package of documentation proving the production process is capable of consistently meeting requirements.

**PPAP Level selection:**

| Level | Scope | When to use |
|-------|-------|-------------|
| Level 1 | Part Submission Warrant (PSW) only | Low-risk, simple parts, trusted suppliers |
| Level 2 | PSW + selected supporting samples/data | Standard new product introduction |
| Level 3 | PSW + full supporting documentation + samples | Complex parts, high risk, new supplier, regulated products |
| Level 4 | Customer-defined | Specific buyer requirements |
| Level 5 | PSW + all documentation reviewed at supplier's site | Highest risk; critical safety or regulated parts |

**Default for this skill: Level 2–3 depending on risk.**

```
GATE 4 — PRE-PRODUCTION TRIAL AND PPAP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PRE-PRODUCTION TRIAL EXECUTION
Trial run parameters:
☐ Trial quantity: minimum [300–500 pcs] or [X hours of production]
    (Large enough to expose process stability — not just a few shots)
☐ Production line: the actual production line, not a prototype cell
☐ Operators: production operators (not technicians who set up T1)
☐ Materials: from the production material lot or representative batch
☐ Process parameters: documented and locked — same as T1 approval
☐ Supervision: supplier quality manager present throughout

PRODUCTION PROCESS DOCUMENTATION (to be completed by supplier)
☐ Process Flow Diagram — all production steps from material receipt
    to shipping
☐ Control Plan — what is measured at each step, how often, by whom,
    reaction plan if out of control
☐ PFMEA (Process Failure Mode and Effects Analysis) — what can go
    wrong at each step; severity, occurrence, detection ratings;
    recommended actions for high RPN items
☐ Work Instructions — operator-level instructions at each station
    (with photos — operators must understand without reading prose)
☐ Inspection records — IQC, IPQC, FQC checksheets defined
☐ Process parameters record — all key parameters locked with ranges

DIMENSIONAL AND VISUAL FROM TRIAL RUN
☐ Sample size: [30–100 pcs] randomly selected from trial run
☐ Full dimensional check on [5–10] pieces (all critical dimensions)
☐ First-pass visual inspection yield: ____%
☐ Defect types found during trial (if any):
    Type: _______________ Count: ___ % of trial run: ___
    Type: _______________ Count: ___ % of trial run: ___

PROCESS CAPABILITY STUDY (for critical dimensions)
For each critical dimension (Cp / Cpk analysis):

Dimension: ___________  Nominal: ___  Tolerance: ___
  Sample size: [25 minimum]
  Mean (X̄): ___  Std Dev (σ): ___
  Cp: ___  Cpk: ___
  
  Acceptance criteria:
  ☐ Cpk ≥ 1.67 — Excellent — approved
  ☐ Cpk 1.33–1.66 — Good — approved with monitoring
  ☐ Cpk 1.00–1.32 — Marginal — conditional approval + improvement plan
  ☐ Cpk < 1.00 — Not capable — tooling or process correction required

[Repeat for each critical dimension]

PPAP DOCUMENT PACKAGE (supplier to submit)
PPAP Level selected: [2 / 3]

☐ Design Records — copy of approved drawing (Rev ___)
☐ Engineering Change Documents — if any changes since original drawing
☐ Customer Engineering Approval — G3 sample approval records
☐ Design FMEA — buyer or supplier (depending on who owns design)
☐ Process Flow Diagram
☐ Process FMEA (PFMEA)
☐ Control Plan
☐ Measurement System Analysis (MSA / Gauge R&R) for critical gauges
☐ Dimensional Results — 30-piece layout on all drawing dimensions
☐ Material / Performance Test Results — all test reports from T1 stage
☐ Initial Process Studies (Cp/Cpk) — for critical dimensions
☐ Qualified Laboratory Documentation — accredited lab test reports
☐ Appearance Approval Report — sign-off on colour/texture/surface
☐ Sample Parts — [X] production-run samples submitted to buyer
☐ Master Sample / Golden Sample — confirmation of storage location
☐ Checking Aids — photos/list of gauges used; calibration records
☐ Customer-Specific Requirements — any additional requirements met
☐ Part Submission Warrant (PSW) — supplier's formal submission document
    signed by supplier's authorised quality representative

FIRST ARTICLE INSPECTION (FAI) REPORT
☐ Completed by: [Buyer's QC / Third-party inspector / Supplier with witness]
☐ Date of inspection: [Date]
☐ Inspection location: [Supplier's factory / Buyer's facility]
☐ All critical and major dimensions verified on [X] production parts
☐ FAI report issued: [FAI-XXXXXXXX-[Date]]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
G4 PPAP DECISION

☐ PPAP APPROVED — all documents submitted, Cpk acceptable,
  production trial results satisfactory
  → Trigger: Tooling payment Milestone 3 (final)
  → Action: First production PO may be issued

☐ PPAP CONDITIONALLY APPROVED — minor items outstanding
  Outstanding items: _________________________________
  Resolution by: [Date]
  → Action: First PO may be issued with limited volume;
    full approval required before ramp

☐ PPAP REJECTED — significant gaps in documentation or capability
  Key failures: ______________________________________
  → Action: Re-run trial after corrective action; resubmit PPAP

PPAP Reference: [PPAP-XXXXXX-[Date]]
Signed off by: [Name, Title] Date: __________
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Gate 5: First Production Release and Ramp

**Purpose:** Authorise and execute the first commercial production run. Monitor closely. Ramp volume in controlled steps.

**Entry criteria:** G4 PPAP approved. First production PO issued. Buffer stock plan confirmed.

```
GATE 5 — FIRST PRODUCTION RELEASE AND RAMP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FIRST PRODUCTION PO
☐ First production PO issued (use `purchase-order-generator` skill)
☐ PO references approved Golden Sample: [GS-XXXXXX]
☐ PO references PPAP reference: [PPAP-XXXXXX]
☐ PO specifies: AQL [2.5 major / 4.0 minor] per ISO 2859-1
☐ PO specifies: pre-shipment inspection required [Y/N]
☐ First shipment quantity: [X units — ramp step 1]

PRODUCTION MONITORING — FIRST SHIPMENT
☐ Buyer or third-party inspector present for first production day
☐ Daily production yield reports during first run: [% first-pass yield]
☐ Any new defect types found — report to buyer immediately
☐ Production parameters monitored and confirmed stable
☐ In-process inspection checksheet completed each shift

PRE-SHIPMENT INSPECTION (first shipment — mandatory)
☐ Inspection company: [SGS / Intertek / Bureau Veritas / QIMA / other]
☐ Inspection date: [Date — must be before cargo loads]
☐ AQL level: [2.5 major / 4.0 minor]
☐ Inspection scope:
  ☐ Random visual inspection per AQL
  ☐ Dimensional spot check (5–10 pcs) against Golden Sample
  ☐ Functional test spot check
  ☐ Carton markings and labelling check
  ☐ Packing and carton quality check
☐ Inspection result: [Pass / Fail / Pending]
☐ If fail: hold cargo, issue CAPA, re-inspect after correction

RAMP PLAN
────────────────────────────────────────────────────────────
Shipment   Quantity    Inspection   Decision gate       Status
─────────────────────────────────────────────────────────────
1 (First)  [X units]  100% PSI     Buyer approval      Pending
2          [X units]  PSI — AQL    PSI pass required
3          [X units]  PSI — AQL    PSI pass required
4+         [X units]  Risk-based   Scorecard-driven
Full ramp  [X units]  Standard     Per supplier tier
─────────────────────────────────────────────────────────────
Full ramp: when supplier has achieved [3] consecutive PSI passes
and first-pass yield ≥ [95]% for [2] production runs.

SUPPLIER SCORECARD ACTIVATION
☐ Supplier added to `supplier-performance-scorecard` system
☐ Baseline KPIs set:
  OTIF target: ≥97%
  First-pass quality yield: ≥[95]%
  Defect rate target: ≤[500] PPM
  First shipment review date: [30 days after first delivery]

NPI CLOSE-OUT
☐ NPI lessons learned document completed
☐ All NPI costs captured for future reference
☐ Supplier scorecard initiated
☐ All tooling documented: tool number, location, buyer ownership
☐ PPAP package filed and accessible
☐ Golden Sample stored with clear traceability
☐ NPI project formally closed: [Date]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
G5 — PRODUCTION RELEASE AUTHORISED
First commercial shipment approved by: _______________
Date: ______________
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 3: NPI Risk Assessment

Before starting any NPI, score the overall risk level to calibrate how strictly to apply each gate.

```
NPI RISK SCORING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Rate each factor 1–5 (1 = low risk, 5 = high risk):

PRODUCT COMPLEXITY
☐ Simple (few parts, wide tolerances, standard material)      1–2
☐ Medium (assembly, moderate tolerances, specified material)  3
☐ Complex (tight tolerances, multi-component, critical fit)   4–5
Score: ___

SUPPLIER FAMILIARITY
☐ Long-standing supplier, proven on similar products          1
☐ Known supplier, new product category                        2–3
☐ New supplier, proven category                               3–4
☐ New supplier, new product type                              5
Score: ___

REGULATORY / COMPLIANCE BURDEN
☐ No regulatory requirements beyond general trade             1–2
☐ Standard certifications (ISO, CE, RoHS)                     3
☐ Food / pharma / medical / safety-critical requirements      4–5
Score: ___

BUSINESS IMPACT OF FAILURE
☐ Low volume, alternative suppliers exist                     1–2
☐ Medium volume, one alternative                              3
☐ High volume, long lead time, sole source                    4–5
Score: ___

SCHEDULE PRESSURE
☐ Ample time; no hard deadline                                1–2
☐ Moderate; some buffer in schedule                           3
☐ Hard deadline; no buffer; launch-critical                   4–5
Score: ___

MANUFACTURING PROCESS NOVELTY
☐ Standard, well-understood process                           1–2
☐ Process used but at new location or with new material       3
☐ New process or new material combination                     4–5
Score: ___

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOTAL RISK SCORE: ___ / 30

6–12:  LOW RISK — standard NPI gates with light documentation
13–20: MEDIUM RISK — full gates; PPAP Level 2 minimum
21–26: HIGH RISK — strict gates; PPAP Level 3; FAI; increased sampling
27–30: CRITICAL RISK — consider phased launch; executive oversight;
       dual-source development in parallel
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 4: NPI Timeline Templates

### Fast-Track NPI (simple product, known supplier, low risk)

```
Week 1–2:   G0 Design freeze + DFM review
Week 2–3:   G1 Supplier award + tooling PO
Week 4–8:   Tooling build
Week 9:     G2/G3 T1 samples received and reviewed
Week 10:    T1 approval (or correction if needed)
Week 11–12: G4 Pre-production trial + PPAP
Week 13:    G5 First production PO
Week 16–18: First commercial shipment

Total: ~16–18 weeks from design freeze to first shipment
```

### Standard NPI (new supplier or medium complexity)

```
Week 1–2:   G0 Design freeze + DFM review
Week 3:     G1 Supplier award + tooling PO + kick-off
Week 4–10:  Tooling build
Week 10:    G2 T0 samples (if applicable)
Week 11:    T0 corrections
Week 12–13: G3 T1 samples received
Week 13–14: T1 review; testing to external lab
Week 15:    T1 approval
Week 15:    T2 if corrections required (add 3–4 weeks)
Week 16–17: G4 Pre-production trial + PPAP
Week 18:    PPAP approval
Week 18:    G5 First production PO
Week 22–24: First commercial shipment

Total: ~22–24 weeks (28 with T2 round)
```

### Complex NPI (regulated product, new supplier, tight tolerance)

```
Week 1–3:   G0 Design freeze + regulatory mapping + DFM
Week 4–5:   G1 Supplier award + PPAP planning + tooling PO
Week 6–14:  Tooling build (complex tooling; multiple cavities)
Week 14:    G2 T0 samples
Week 15:    T0 corrections
Week 16–18: G3 T1 samples + lab testing (allow 3–4 weeks for lab)
Week 20:    T1 approval / T2 if required (add 4 weeks)
Week 21–22: G4 Pre-production trial + PPAP
Week 23–25: PPAP review + approval
Week 25:    G5 First production PO
Week 30–32: First commercial shipment

Total: ~30–32 weeks minimum
Note: Regulatory certification (CE, BIS, FDA) may add 8–26 weeks
and should run in parallel, not sequentially
```

---

## Step 5: Common NPI Failure Modes and How to Prevent Them

| Failure | Root cause | Prevention |
|---------|-----------|------------|
| T1 dimensions out of tolerance on critical features | DFM not done; tolerances tighter than process can achieve | Run `dfm-bridge` skill at G0; confirm tolerances achievable |
| Colour mismatch at production vs. sample | Colour only checked visually; no spectrophotometer measurement | Set L*a*b* tolerance in spec; measure every batch with spectrophotometer |
| Production parts worse than T1 | T1 produced under special conditions, not production conditions | Require process parameter lock before T1; trial conditions = production conditions |
| PPAP submitted with missing documents | PPAP treated as a box-ticking exercise | Use this skill's PPAP checklist; gate payment on PPAP approval, not just samples |
| First production quality worse than pre-production | Turnover of skilled staff; different shift; pressure to hit output targets | Require buyer/inspector on first production day; yield monitoring every shift |
| Launch delayed by regulatory certification | Certification started after sample approval | Start regulatory certification process at G0 in parallel with NPI |
| Tooling held hostage by supplier | No tooling ownership clause in PO | Use `purchase-order-generator` skill with tooling PO — ownership clause is mandatory |
| Supplier runs NPI for multiple customers simultaneously | No NPI capacity agreed upfront | Confirm NPI capacity and dedicated resource at G1 kick-off |
| Golden Sample lost or replaced without notice | No formal golden sample control | Serial number the golden sample; dual storage (buyer + supplier); reference in every PO |
| Cost creep after tooling approval | Supplier claims changes required after tool is cut | Design freeze at G0; change control in place; all changes require written approval + cost impact |

---

## Step 6: NPI Status Report Template

For communicating NPI progress to internal stakeholders weekly:

```
NPI WEEKLY STATUS REPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Product:      [Name]       Supplier: [Name]
NPI Lead:     [Name]       Week ending: [Date]
Current gate: [G0/G1/G2/G3/G4/G5]
Overall RAG:  [🟢 GREEN / 🟡 AMBER / 🔴 RED]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MILESTONE TRACKER
─────────────────────────────────────────────────
Milestone             Plan Date   Forecast   Status
───────────────────── ─────────── ─────────  ──────
G1 Supplier award     [Date]      [Date]     ✓ Done
Tooling PO issued     [Date]      [Date]     ✓ Done
T1 samples            [Date]      [Date]     On track
T1 approval           [Date]      [Date]     At risk +2wk
Pre-production trial  [Date]      [Date]     TBD
First shipment        [Date]      [Date]     At risk +2wk
─────────────────────────────────────────────────
Schedule slippage:  [+X weeks vs. plan]
Impact on launch:   [Launch date moves from X to Y / On track]

THIS WEEK'S ACTIVITIES
☐ [Activity completed]
☐ [Activity completed]
○ [Activity in progress]

NEXT WEEK'S PRIORITIES
1. [Action — owner — due date]
2. [Action — owner — due date]
3. [Action — owner — due date]

KEY RISKS AND ISSUES
🔴 [Critical issue — impact — mitigation]
🟡 [Risk — probability — mitigation]

DECISIONS NEEDED
1. [Decision required from whom — by when]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 7: NPI for Specific Product Categories

### Injection Moulded Plastics
- T0 essential for complex tools; skip only for simple single-cavity tools
- Cavity-by-cavity dimensional tracking is mandatory
- Process parameter lock (injection speed, pressure, temperature, cooling time) must be documented before T1 approval
- Warpage and shrinkage — measure 24–72 hours after moulding (not immediately — parts change dimension as they cool and stress-relax)
- Key risk: optimised sample conditions vs. production conditions (longer cycle, faster output, hotter tool from continuous running)

### Die Casting (Aluminium, Zinc)
- Porosity is the hidden enemy — X-ray inspection of T1 samples recommended for pressure-critical applications
- Die release agent application — inconsistent application affects surface finish and dimensional repeatability
- Gate and runner system — affects fill, porosity, and parting line flash; review at T0
- Secondary operations (machining, surface treatment) — must be qualified separately

### Textiles and Apparel
- Fabric testing before cut: colourfastness, shrinkage, tensile strength, pilling — all before production fabric committed
- Seam strength testing on T1 garments
- Size set grading — all sizes must be sampled (or statistically sampled for large ranges)
- Wash test on T1: dimensional change after [3] wash cycles vs. spec
- Trim and accessories (zips, buttons, labels) — sourced and approved separately; do not assume

### Electronics / PCBAs
- IPC-A-610 workmanship standard — specify class (Class 2 for consumer; Class 3 for industrial/medical)
- First article inspection must include X-ray of solder joints for BGA and QFN packages
- Functional test — 100% functional test on production line is standard; confirm test coverage
- EMC pre-compliance scan before investing in full CE/FCC certification
- Component sourcing — confirm no counterfeit/grey market risk for critical ICs (especially in China)

### Food Products (coffee ground straws, rice husk tableware)
- Packaging material migration testing (EN 1186 for plastics; EFSA guidelines for bio-based)
- Shelf life study — real-time preferred; accelerated acceptable for first submission
- Organoleptic testing (taste/odour impact from packaging)
- Compostability certification testing (EN 13432 / ASTM D6400) — allow 3–6 months for testing
- FSSAI labelling compliance before first India market shipment
- BPI or DIN CERTCO certification for US/EU compostability claims
- Humidity and temperature cycling test for structural integrity

---

## Related Skills
- `dfm-bridge` — run at G0 before design freeze; prevents the most expensive NPI mistakes
- `should-cost-modelling` — set unit cost target at G0; challenge supplier quote against it at G1
- `vendor-qualification` — supplier selection before NPI award at G1
- `rfq-drafting` — formal RFQ for NPI tooling and production pricing
- `purchase-order-generator` — tooling PO at G1; first production PO at G5
- `supplier-performance-scorecard` — activate at G5; NPI data becomes baseline KPIs
- `esg-compliance-audit` — run ESG assessment in parallel with NPI, not after it
- `customs-documentation-checklist` — determine export/import documentation requirements at G0
- `tariff-hs-lookup` — confirm HS code and duty rates at G0 (affects landed cost model)
- `resilience-geopolitical-radar` — check supply chain risk for new supplier country at G1
