---
name: negotiation-playbook
description: Use this skill when the user wants to negotiate with a supplier, prepare for a price negotiation, push back on a quote, plan a negotiation strategy, handle supplier objections, or close a commercial deal. Also trigger when the user says "negotiate this price", "supplier won't budge", "how do I push back", "prepare me for a negotiation", "they came back too high", "I need to get a better price", "what's my BATNA", "supplier is asking for better payment terms", "I need a negotiation script", "how do I handle this counter-offer", "supplier said no", "counter this offer", or describes any commercial standoff with a supplier. Covers price negotiation, payment terms, MOQ, lead time, tooling cost, warranty, and multi-issue integrative negotiation. Works for any product, any country, any supplier relationship stage (first order to long-term partner). Produces negotiation strategy documents, BATNA analysis, opening positions, concession plans, and ready-to-send negotiation emails.
---

# Negotiation Playbook

The most important skill in procurement. Every dollar saved in negotiation goes straight to margin. This skill encodes practitioner-grade negotiation strategy — not theory, but what actually works in supplier conversations across every major sourcing and trading nation: Asia-Pacific, Middle East, all of Europe, Latin America, Africa, and beyond. 40+ country playbooks. No country is off-limits.

**Core philosophy:** Negotiation is not confrontation. It is joint problem-solving with a commercial outcome. The best negotiations leave both sides feeling they won something. The worst destroy relationships that took years to build.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Extract: supplier name and country, product, target price, payment terms, volume, relationship history, approved supplier alternatives.

---

## Step 1: Situation Assessment

Before any negotiation, classify the situation across four dimensions:

### 1A. Power Balance

Who needs this deal more?

| Factor | Buyer Power ↑ | Supplier Power ↑ |
|--------|--------------|-----------------|
| Alternatives | Multiple qualified alternatives exist | You are sole-sourced |
| Volume | You are a significant customer for them | Your volume is trivial to them |
| Switching cost | Low — easy to move | High — significant re-qualification cost |
| Urgency | You have time | You have a hard deadline |
| Market | Buyer's market (many suppliers) | Seller's market (few suppliers, high demand) |
| Relationship | New supplier (no lock-in) | Long-term partner (switching = risk) |

**Score your position:** Count buyer vs. supplier factors. If buyer power ≥ 4: negotiate hard. If balanced: collaborative approach. If supplier power ≥ 4: negotiate carefully — relationship preservation matters more than squeezing.

### 1B. Negotiation Type

| Type | Description | Strategy |
|------|-------------|----------|
| **Distributive** | Fixed pie — one side's gain is the other's loss. Typically pure price. | Anchor high/low, use competitive tension, be willing to walk |
| **Integrative** | Expandable pie — find trades where both sides gain. Multiple issues. | Reveal priorities, make package deals, look for asymmetric value |
| **Relationship** | Long-term partner where short-term price matters less than trust | Make concessions visibly, signal commitment, protect their dignity |
| **Crisis** | Urgent, emotion elevated, relationship at risk | Slow down, acknowledge, solve the problem before the price |

Most real supplier negotiations are **integrative with distributive elements** — there is a price component AND multiple other terms to trade.

### 1C. BATNA Analysis

BATNA = Best Alternative To Negotiated Agreement. The single most powerful concept in negotiation.

**Your BATNA (buyer):**
- What will you do if this negotiation fails entirely?
- Do you have a qualified second supplier?
- Can you source from a different country?
- Can you change the specification to use a different material/process?
- Can you delay the requirement?

**Rate your BATNA:** Strong (clear alternative, similar cost) / Moderate (alternative exists but at cost/risk) / Weak (no real alternative, must close this deal)

**Supplier's BATNA (estimate):**
- What happens to them if they lose this order?
- What is their current utilisation?
- Are you a top-10 customer for them?
- Do they have competing orders for the same capacity?

**The BATNA Rule:** Your negotiating power = the strength of your BATNA relative to theirs. Never negotiate without knowing both.

**If your BATNA is weak:** Strengthen it before negotiating. Issue RFQ to alternatives, qualify a second supplier, or adjust timeline to give yourself options.

### 1D. Issue Map

List every negotiable issue, not just price. Most negotiations fail because both sides only argue about price when there are 8 other things to trade.

| Issue | Your ideal | Your walk-away | Their likely position | Trade value |
|-------|-----------|----------------|----------------------|-------------|
| Unit price | $X.XX | $X.XX max | $X.XX quoted | High |
| Payment terms | Net 60 | Net 30 min | 30% advance + 70% BL | High |
| MOQ | 500 units | 1,000 max | 2,000 | Medium |
| Lead time | 30 days | 45 days max | 60 days | Medium |
| Tooling cost | $0 (amortise) | $5,000 max | $8,000 upfront | Medium |
| Sample cost | Free | $200 max | $500 | Low |
| Warranty | 24 months | 12 months min | 12 months | Low |
| Exclusivity | None | None | None | Varies |
| Annual volume commitment | Flexible | None | 10,000/year | High |

**Key insight:** Issues have asymmetric value. Something that costs you little may be worth a lot to the supplier — and vice versa. Payment terms are cheap for a cash-rich buyer but critical for a cash-strapped factory. Volume commitment costs you flexibility but gives them planning certainty. Find these asymmetries and trade on them.

---

## Step 2: Pre-Negotiation Preparation

### 2A. Should-Cost Anchor

Run `should-cost-modelling` skill before any price negotiation. Know what the product *should* cost before the supplier tells you what they want to charge.

Having a credible cost model:
- Removes anchor bias (supplier's first number doesn't dominate your thinking)
- Gives you a rational basis for your counter-offer
- Signals sophistication — suppliers respect buyers who understand their costs
- Helps you identify which cost component to challenge

### 2B. Set Your Three Numbers

For each issue, define:

1. **Opening position** — where you start. Should be ambitious but not absurd. Rule of thumb: 15–25% below your target for price; 2× your ideal for MOQ reduction.
2. **Target** — what you actually want to achieve.
3. **Walk-away** — your BATNA threshold. Below this, you walk.

Never reveal your target or walk-away. Only your opening position is disclosed — and even that is negotiated.

### 2C. Prepare the Competitive Tension Signal

If you have multiple suppliers quoting, this is your most powerful tool. You don't need to reveal specifics — just signal competition exists:

- "We are evaluating several suppliers for this category"
- "We received a competitive quote at a lower price point"
- "We need your best price — we are making a final decision this week"

**Never bluff about a competitor quote you don't have.** Skilled suppliers will call it. But you can always be vague: "We have an alternative at a competitive price" — this is true as long as you have *any* alternative, even a rough one.

### 2D. Cultural Preparation

Load the relevant section from the country guide below before negotiating with a supplier from that country. Negotiation styles vary enormously. What works in Germany will fail in China. What works in India will alienate a Turkish supplier.

---

## Step 3: Global Country Negotiation Playbooks

No country is off-limits. This section covers every major sourcing and trading nation. Load the relevant country profile before any negotiation.

**How to use:** Find the supplier's country. Read the full profile. Apply the style guidance and tactics before your first communication.

**Quick style index by region:**
- Asia-Pacific: China, India, Vietnam, Bangladesh, Indonesia, Malaysia, Thailand, Philippines, Pakistan, Sri Lanka, Taiwan, South Korea, Japan, Singapore, Australia, New Zealand
- Middle East & North Africa: Turkey, UAE, Saudi Arabia, Egypt, Morocco, Israel
- Europe (Western): Germany, France, Italy, Spain, Netherlands, Belgium, Sweden, Denmark, Finland, Norway, Switzerland, Austria, Portugal, UK, Ireland
- Europe (Central & Eastern): Poland, Romania, Czech Republic, Hungary, Slovakia, Serbia, Ukraine
- Latin America: Mexico, Brazil, Colombia, Argentina, Chile, Peru, Costa Rica
- Sub-Saharan Africa: South Africa, Kenya, Ethiopia, Ghana, Nigeria
- North America (as supplier): USA, Canada

---

## ASIA-PACIFIC

---

### China 🇨🇳

**Style:** Relationship-first, indirect, long-term oriented, deeply face-conscious.

**Key principles:**
- Guanxi (关系) — relationship — matters more than the contract. Invest time in it before negotiating price.
- Never cause loss of face (面子 — mianzi) publicly. Any criticism of price, quality, or capability must be private and framed indirectly.
- First offers are always anchored high. 30–50% above final settlement is common, especially on first interaction.
- "No" is rarely said directly. "That's a bit difficult" (这有点难), "I'll need to check with my manager", or extended silence typically signals no.
- Patience is deployed as a deliberate tactic. Don't rush. Don't fill silence.
- Decision-making is hierarchical. Your contact often cannot say yes — only no. To move, you may need to access the factory owner (老板 — lǎobǎn) or director.
- Price is not the only lever. Payment terms, exclusivity, long-term volume commitment, and annual order guarantees are highly valued and tradeable.

**Tactics that work:**
- Build rapport before commercial discussion. Ask about city, factory history, products they're proud of.
- Open with volume potential: "We are growing fast and this could be a very significant long-term relationship."
- Use the "I'd love to work with you, but..." framing — signals desire while stating the constraint, preserves face.
- Token gifts at first meeting (never cash — branded item, quality sweets) signal respect.
- Ask for "best price for a long-term partner" rather than bluntly demanding lower price.
- Let silence sit after a counter. Many Chinese negotiators will fill it themselves with a concession.
- Reference category competition indirectly: "Other factories we visited in Ningbo offer X" — never name the competitor.
- WeChat is often more effective than email for real commercial discussion. Use it.

**Tactics that backfire:**
- Ultimatums — causes loss of face; often ends the relationship permanently
- Public confrontation or frustration
- Revealing your delivery deadline (they will use it against you in the final round)
- Demanding an immediate decision
- Assuming the first "yes" is final — in China a yes often means "I hear you", not "I agree"

**Email tone:** Warm, indirect, relationship-focused.
> "We really value our partnership with your team and believe we can build something significant together long-term. Could you kindly review the pricing once more? We are confident there is room for both sides to benefit."

**Language note:** Sending key points in simplified Chinese alongside English demonstrates respect and dramatically improves response rates with non-English-dominant factory staff.

---

### India 🇮🇳

**Style:** Relationship and hierarchy-aware, entrepreneurial, expressive, comfortable with ambiguity.

**Key principles:**
- Negotiation is expected, enjoyed, and respected. A price accepted immediately signals you left money on the table.
- Personal rapport with the decision-maker is everything. Deals happen because people like each other.
- Hierarchy matters: always identify who the final decision-maker is (usually the MD, promoter, or owner) and access them directly.
- Flexibility is extraordinarily high. Nearly everything is negotiable — items you didn't even know to ask for.
- Time is elastic: "I'll send by EOD" often means 2–4 days. Plan accordingly.
- Indian SMEs are frequently cash-constrained. Payment terms are the most sensitive lever of all.
- Emotional appeals work: "I've chosen you as my partner" carries real weight.

**Tactics that work:**
- State your long-term volume potential early and return to it often.
- Be direct about your target price — Indian suppliers appreciate directness more than Chinese counterparts.
- Competitive tension is highly effective: "We have a quote at a lower price and are trying to consolidate with you."
- Ask for extras bundled into the deal: free samples, free courier on first shipment, extended warranty, priority production slot.
- A WhatsApp voice note or video call dramatically increases credibility vs. email alone.
- Appeal to entrepreneurial pride: "You're clearly building something exceptional — let's grow this together."
- Follow up persistently. Silence is often a test of seriousness, not a no.

**Tactics that backfire:**
- Overly formal transactional tone (reads as cold or disrespectful)
- Hard ultimatum deadlines (often ignored or create resentment)
- Skipping the personal relationship layer entirely

---

### Vietnam 🇻🇳

**Style:** Formal, hierarchical, polite, indirect, relationship-oriented, long-term thinking.

**Key principles:**
- More formally structured than China or India — use titles (Mr./Ms. + surname) in all written comms.
- Relationship matters but negotiation moves faster than China once rapport is established.
- Decision-making is hierarchical — your factory contact may need approval from above for any price change.
- Price sensitivity is high; Vietnamese exporters often operate on thin margins, especially in garments and furniture.
- Factory owners are frequently hands-on and accessible — try to negotiate with the principal directly.
- Vietnamese suppliers value long-term stability and predictability over short-term maximum price.

**Tactics that work:**
- Establish credibility first: your brand, your market, your volume potential.
- Be specific about quantities and timelines — Vietnamese factories want certainty before dropping price.
- Offer payment terms improvement in exchange for price reduction (faster TT or reduced advance %).
- "We have visited several factories this week and are making our final decision" — competitive tension is effective.
- Express appreciation for their compliance investments (SMETA, ISO, OEKO-TEX) — it is a genuine differentiator they're proud of.

**Backfires:** Rushing decisions, ignoring hierarchy, treating the relationship as purely transactional.

---

### Bangladesh 🇧🇩

**Style:** Formal, community-oriented, price-sensitive, deeply relationship-driven in the RMG sector.

**Key principles:**
- Buyer power is structurally high in Bangladesh's RMG sector — use it responsibly or burn relationships.
- BGMEA/BKMEA membership and compliance certifications (ACCORD, Alliance, LEED-certified factory) are genuine sources of pride — always acknowledge them.
- CM (cut and make) is the primary lever in garments. Fabric is often buyer-supplied, so price negotiation is on CM rate.
- Lead time pressure is a fact of life in the industry — don't weaponise it unless you genuinely have flexibility to offer.
- Labour compliance and worker welfare are increasingly non-negotiable for Western buyers — use them as qualification gates, not negotiation chips.

**Tactics that work:**
- Acknowledge their compliance investment sincerely before commercial discussion.
- Use volume commitment as the primary lever — annual program commitment unlocks better CM rates.
- Payment terms improvement (reducing L/C to TT, or shortening settlement) is highly valued.
- Audit support (helping them achieve certifications) builds loyalty that price cannot buy.

---

### Indonesia 🇮🇩

**Style:** Relationship-first, indirectly communicative, hierarchical, respectful of seniority, Pancasila-influenced harmony ethos.

**Key principles:**
- Harmony (rukun) is a deep cultural value — confrontational negotiation styles are jarring and counterproductive.
- Bapak/Ibu (Mr./Mrs.) titles are important — use them consistently.
- Decision-making is consensus-oriented and can be slow. Decisions rarely happen in the room; they happen after the meeting.
- "Yes" frequently means "I am listening" or "I understand", not "I agree". Confirm explicitly.
- Face (muka) is as important as in China — never challenge or embarrass a contact publicly.
- Business entertaining and relationship time before commercial discussion is expected and valued.

**Tactics that work:**
- Build the relationship over multiple contacts before pushing on price.
- Use intermediaries or agents when possible — Indonesians prefer to negotiate through trusted go-betweens for sensitive issues.
- Frame price reduction as "helping us grow together" rather than challenging their margin.
- Offer stability: regular orders and long-term predictability matter more than spot price.

**Language note:** Bahasa Indonesia correspondence (alongside English) significantly improves response rates with non-Jakarta based suppliers.

---

### Malaysia 🇲🇾

**Style:** Multi-cultural (Malay, Chinese, Indian communities), professionally Westernised, direct by Asian standards.

**Key principles:**
- Malaysian business culture is a blend — Chinese-Malaysian businesses often operate closer to mainland Chinese norms; Malay-owned businesses are more formal and relationship-first.
- English proficiency is high — Malaysia is an easy market to communicate with.
- Bumiputera (Malay indigenous) preference policies affect certain government-linked contracts.
- Halal certification is important for food, pharma, cosmetics, and certain manufacturing suppliers.
- Malaysian manufacturers are strong in electronics, rubber, palm oil, medical devices, and furniture.

**Tactics that work:**
- Refer to Malaysia's trade advantages: CPTPP and RCEP member, duty-free access to many markets.
- Price negotiation is direct and acceptable — Malaysians are comfortable with frank commercial discussion.
- Payment terms and repeat order commitment are the most effective levers.

---

### Thailand 🇹🇭

**Style:** Relationship-oriented, kreng jai (consideration for others), indirect refusal, respectful of seniority.

**Key principles:**
- Kreng jai means Thai counterparts will often avoid saying "no" to avoid causing discomfort. Watch for indirect signals: silence, changing subject, vague commitments.
- Greng jai also means they may agree to terms they cannot meet to avoid confrontation — always build in verification steps.
- Respect for seniority and hierarchy is significant. Senior buyer representatives get better response.
- "Sanuk" (fun, enjoyment) matters — Thai business relationships involve social time.
- Strong in automotive parts, electronics, food products, rubber, and packaging.

**Tactics that work:**
- Build personal rapport; ask about family and their business journey.
- Frame requests as joint problem-solving: "How can we make this work together?"
- Face-to-face or video calls are far more effective than email for sensitive commercial topics.
- Volume commitment and payment reliability are highly valued levers.

---

### Philippines 🇵🇭

**Style:** Warm, relationship-driven, English-fluent, values personal connection, pakikisama (group harmony) oriented.

**Key principles:**
- English is a first language for business — no communication barrier.
- Filipinos are among the most personable and expressive business cultures in Asia.
- Hiya (shame) means direct criticism must be delivered carefully and privately.
- Utang na loob (debt of gratitude) — if you help someone, they will feel a genuine obligation to reciprocate.
- Strong sectors: electronics/PCB assembly, business process outsourcing, furniture, fashion accessories, food processing.

**Tactics that work:**
- Be personal and warm. Ask about their business, their family, their city.
- Express genuine appreciation for their work — Filipinos respond powerfully to sincere recognition.
- Use the relationship to unlock flexibility — "As your partner, I need your help on this price."
- Be clear and specific about what you need; vagueness causes confusion.

---

### Pakistan 🇵🇰

**Style:** Relationship-driven, hierarchical, bargaining expected, hospitality-first.

**Key principles:**
- Extended bargaining is culturally normal and expected — first price is never final.
- Hospitality (chai, food) before business is a cultural ritual. Accepting it is important.
- Religious calendar matters: Ramadan significantly slows business; Eid al-Fitr and Eid al-Adha cause factory shutdowns of 1–2 weeks. Plan shipments accordingly.
- Pakistani textile sector (cotton yarn, fabric, knitwear, denim) is among the world's largest and most competitive.
- Strong sports goods sector (Sialkot: soccer balls, surgical instruments, boxing equipment).
- Trust is paramount — once established, Pakistani suppliers are loyal and flexible.

**Tactics that work:**
- Personal introduction through a mutual contact dramatically accelerates trust.
- Volume commitment is the primary lever — commit to annual volumes for meaningful price movement.
- Be patient — decisions often happen after consultation with family members who are also involved in the business.
- Reference export experience to US/EU markets as credibility signal.

**Note:** Cross-border logistics complexity (limited direct air links from some origins) adds to lead time — factor into planning.

---

### Sri Lanka 🇱🇰

**Style:** Formal, relationship-oriented, English-proficient, strong ethics emphasis, compliance-forward.

**Key principles:**
- English proficiency is high — excellent communication.
- Sri Lankan manufacturers (apparel, rubber, gems, spices) are known for quality and compliance.
- Business culture is polite and non-confrontational.
- The garment sector is highly compliance-certified (WRAP, OEKO-TEX, Better Work) — acknowledge and value this.

**Tactics that work:**
- Acknowledge compliance as a genuine differentiator.
- Long-term relationship signals and volume commitment are more effective than aggressive price pressure.
- Payment reliability (no delays, no deductions) is highly valued and builds goodwill.

---

### Taiwan 🇹🇼

**Style:** Technically sophisticated, quality-focused, pragmatic, relationship-aware but more direct than mainland China.

**Key principles:**
- Taiwanese suppliers are often OEM/ODM specialists — they bring design capability, not just manufacturing.
- Face matters but less acutely than mainland China — more direct communication is acceptable.
- Quality and technical specification are their primary source of pride. Challenge them on price; never on capability.
- Taiwanese companies often have operations in China, Vietnam, or other countries — verify actual country of manufacture.
- Strong in electronics, semiconductors, precision machinery, plastics, and specialty chemicals.

**Tactics that work:**
- Come prepared with technical knowledge — they respect buyers who understand what they're making.
- Discuss roadmap and product development together — ODM engagement builds stickier relationships than pure OEM price squeezing.
- Payment terms (T/T 30 days) are standard and fairly inflexible — focus negotiation on price and MOQ.

---

### South Korea 🇰🇷

**Style:** Hierarchical, punctual, hardworking, proud, quality-obsessed, respectful of seniority.

**Key principles:**
- Confucian hierarchy is deeply embedded — always address senior contacts with appropriate titles (부장님, 사장님).
- Decision-making is top-down; the CEO or director is often the effective decision-maker.
- Bballi bballi (빨리 빨리 — hurry hurry) culture: Koreans work fast and expect responsive counterparts.
- Koreans are intensely proud of their brands and technology — respect this. Never diminish their products.
- Strong in electronics, steel, automotive parts, cosmetics, and specialty chemicals.

**Tactics that work:**
- Move quickly — slow responses are read as lack of seriousness.
- Senior-to-senior contact unlocks deals that stall at operational level.
- Demonstrate technical sophistication — Korean suppliers respond to buyers who know their specs deeply.
- Korean suppliers are sophisticated negotiators — do your homework on should-cost before the call.

---

### Japan 🇯🇵

**Style:** Consensus-driven (nemawashi / ringi process), indirect, relationship long-term, quality supreme, punctuality absolute.

**Key principles:**
- Japanese suppliers are among the most quality-obsessed in the world. Kaizen, zero-defect, poka-yoke are lived values.
- Decision-making involves extensive internal consensus (nemawashi/ringi) — decisions are slow but once made, rarely reversed.
- Indirect communication is the norm: "That would be difficult" means "no". Silence after a proposal often means discomfort.
- Relationship (ningensei — human connection) must be established before business accelerates.
- Japanese suppliers rarely engage in aggressive price negotiation. They prefer long-term price stability.
- Punctuality is absolute — late to a meeting is a serious cultural offence.

**Tactics that work:**
- Invest in relationship time heavily upfront. Business cards (meishi) must be accepted and handled with both hands and reverence.
- Frame price discussion as long-term total cost optimization, not price squeezing.
- Ask for Kaizen support and cost reduction through process improvement rather than demanding a lower price.
- Volume certainty and schedule stability are more valuable to Japanese suppliers than a higher spot price.

**Tactics that backfire:**
- Impatience or rushing the process
- Aggressive price demands
- Short-term transactional framing

---

### Singapore 🇸🇬

**Style:** Western-aligned, contract-first, multicultural (Chinese/Malay/Indian blend), sophisticated, efficiency-focused.

**Key principles:**
- Singapore operates on Western commercial norms — English, precise contracts, punctuality.
- Singapore companies are often trading companies, regional HQs, or intermediaries rather than direct manufacturers.
- Anti-corruption culture is strong — no facilitation payments or grey-area "gifts".
- Strong hub for regional logistics, chemicals, electronics, and professional services.

**Tactics that work:**
- Direct, data-driven, contract-focused negotiation is perfectly appropriate.
- Leverage Singapore's FTA network (ASEAN, CPTPP, bilateral agreements) as part of the commercial discussion.
- Singapore counterparts are sophisticated — come fully prepared.

---

### Australia 🇦🇺

**Style:** Direct, informal, egalitarian, low context, no-nonsense, anti-pretension.

**Key principles:**
- Australians dislike formality and hierarchy. Use first names immediately. No titles in conversation.
- They value directness and honesty above all — don't waste time with elaborate preamble.
- "Tall poppy syndrome" — excessive self-promotion or formality is viewed negatively.
- Trust is built through reliability and follow-through, not relationship rituals.
- Strong sectors as suppliers: agricultural products (wool, beef, grains, dairy), mining/minerals, wine, seafood, specialty food, high-precision manufacturing.
- Australian suppliers are increasingly competitive on quality and provenance story — buyers pay premiums for this.

**Tactics that work:**
- Get to the point quickly. State your number and your rationale clearly.
- Show you've done your homework — Australians respect preparation.
- Informal communication (WhatsApp, direct chat) works well once initial contact is made.
- Provenance, clean-and-green, and sustainability narrative add genuine value and can be leveraged in pricing.

**Tactics that backfire:**
- Excessive formality or long preamble
- Attempting to "impress" with titles or hierarchy
- Not following through on commitments

---

### New Zealand 🇳🇿

**Style:** Even more informal than Australia, collaborative, trust-based, relationship important but not ritualistic.

**Key principles:**
- New Zealanders are warm, egalitarian, and direct. First-name basis immediately.
- Smaller economy means suppliers tend to be smaller, owner-operated businesses — decision-maker is usually in the room (or on the call).
- Strong on niche quality: dairy (Fonterra products), wool, seafood (King salmon, Greenshell mussels), Manuka honey, horticulture, wine.
- Maori business culture (if relevant): relationships (whanaungatanga) and collective benefit (manaakitanga) are deeply valued.
- NZ suppliers are not aggressive negotiators by default — they prefer to work collaboratively.

**Tactics that work:**
- Treat them as equals and partners. They respond very poorly to buyer arrogance.
- Be transparent about your constraints — NZ suppliers will often work creatively to solve your problem.
- Volume commitment and supply certainty (not demanding flexibility) are the strongest levers.

---

## MIDDLE EAST & NORTH AFRICA

---

### Turkey 🇹🇷

**Style:** Relationship-driven, warm, hospitable, proud of craftsmanship, direct once trust is established.

**Key principles:**
- Çay (tea) and hospitality before business is a cultural expectation — accept it graciously.
- Turks take immense pride in their manufacturing quality and craftsmanship. Acknowledge this explicitly before discussing price — it opens doors.
- Price and quality are bundled in their identity. Never imply "cheapest is best" — frame as "best value".
- Turkish exporters are globally sophisticated, particularly in textiles, furniture, automotive parts, ceramics, and chemicals.
- Personal relationship between principals (owner to buyer) unlocks the best deals.

**Tactics that work:**
- Open with genuine quality acknowledgement: "Your quality is clearly excellent — that's exactly why we want to work with you."
- Direct framing once rapport is built: "Our budget is X. Can you help us make this work?"
- EU and US market references carry significant weight — Turkish factories prize and protect these relationships.
- Offer testimonials or references in exchange for pricing improvement.
- Long-term commitment signals are powerful — mention multi-year partnership intent.

**Tactics that backfire:**
- Being transactional without relationship investment
- Implying Turkish quality is not premium
- Rushing — Turkish business culture values considered, relationship-grounded decisions

---

### UAE 🇦🇪

**Style:** Hierarchical, relationship-critical, patient, sophisticated, multicultural business environment.

**Key principles:**
- UAE is primarily a trading hub, not a manufacturing nation — suppliers here are often regional distributors or re-exporters.
- Relationship with the right person (Wasta — connections and influence) is everything. A cold approach with no introduction is rarely effective.
- Emirati businesspeople are senior and relationship-focused. Most operational interaction is with expatriate staff (South Asian, Levantine).
- Ramadan significantly slows business — working hours shorten, decisions are deferred. Plan around it.
- Dress conservatively, especially for first meetings. Formality signals respect.
- Free zone companies (Jebel Ali, RAKEZ, DMCC) operate under different regulations than mainland.

**Tactics that work:**
- Warm introduction through a mutual contact is worth more than any cold email.
- Express long-term regional commitment — "We see the UAE as our regional hub" is music to Emirati ears.
- Decision-making often involves the owner or family patriarch — get to this level if the deal is significant.
- Payment reliability and no surprises (quality, delivery) build the loyalty that unlocks better terms.

---

### Saudi Arabia 🇸🇦

**Style:** Relationship-critical, hierarchical, formal, patience expected, religious calendar paramount.

**Key principles:**
- Saudi business is built on Wasta (connections) and personal introductions — a cold approach without a reference is extremely challenging.
- Meetings start late and run long by Western standards. Patience is non-negotiable.
- Religious calendar dominates: Ramadan (no decisions, short hours), Hajj season (senior management absent), and Friday/Saturday weekend.
- Saudi Vision 2030 is driving localisation (Saudisation) — local content requirements are increasing across sectors.
- SABER and IECEE certification are mandatory for regulated products entering the Saudi market.
- Decision-makers are senior and may be absent from meetings — a "yes" from an operational contact often means nothing.

**Tactics that work:**
- Invest in in-person visits. A face-to-face meeting in Riyadh or Jeddah is often the only way to close.
- Reference Saudi Vision 2030 alignment — show how your partnership supports local development goals.
- Patience and persistence. Deals take longer than anywhere else, but are sticky once made.

---

### Egypt 🇪🇬

**Style:** Relationship-driven, hierarchical, expressive, hospitable, flexible on time.

**Key principles:**
- Relationship (علاقة — alaqah) is the foundation of business. Cold commercial approaches rarely work.
- Egyptian business is expressive and warm — personal connection matters as much as price.
- Haggling is a cultural institution — first price is always too high and both sides know it.
- Time flexibility is significant. Meetings start late; deadlines are approximate.
- Strong in textiles/apparel (Egyptian cotton is world-renowned), chemicals, food, and glass.
- Payment and delivery reliability are genuine concerns for Egyptian exporters — reassurance helps.

**Tactics that work:**
- Invest in personal relationship and hospitality time before commercial discussion.
- Be an enthusiastic negotiator — Egyptians enjoy the process and view a buyer who doesn't negotiate as suspicious.
- Cash flow support (better payment terms, faster settlement) is a very powerful lever.
- Reference Egyptian cotton quality and heritage as genuine differentiators.

---

### Morocco 🇲🇦

**Style:** French-influenced, relationship-oriented, hospitable, proud of heritage, quality-conscious.

**Key principles:**
- French is the primary business language alongside Arabic — English proficiency varies; French documents and correspondence are appreciated.
- Business culture blends French formality with Moroccan hospitality. Mint tea is ceremonial.
- Strong in textiles/apparel, automotive parts, phosphates, leather, and food (olives, citrus, argan).
- Morocco's proximity to Europe (2 hours from Madrid) makes it an increasingly important nearshoring destination.
- Seniority and age carry significant weight — showing respect to senior contacts is essential.

**Tactics that work:**
- Send correspondence in French alongside English.
- Reference EU market access (Morocco has association agreement with EU) as a shared commercial advantage.
- Price negotiation is direct and accepted — Moroccan suppliers are commercially sophisticated, especially in textiles.
- Acknowledge their EU compliance investments (factory certifications, labour standards).

---

### Israel 🇮🇱

**Style:** Direct, informal, technically sophisticated, impatient with protocol, chutzpah-driven.

**Key principles:**
- Israeli business culture is among the most direct in the world — they say exactly what they mean and expect the same.
- Titles and formality are largely discarded. First names immediately.
- Speed is valued — slow responses or deliberate delay is read as disrespect.
- Israelis are innovative and entrepreneurial — they often bring technology or IP value, not commodity pricing.
- Strong in agri-tech, medical devices, security technology, drip irrigation, diamonds, and specialty chemicals.
- Very comfortable with confrontational debate — pushing back hard is not rude, it is the norm.

**Tactics that work:**
- Get to the point immediately. State your number, your reasoning, and your timeline.
- Engage in vigorous debate — it signals you are a serious partner.
- Technical depth and innovation discussion unlock better commercial terms.
- Mutual benefit framing ("here's why this deal is good for both of us") works well.

**Tactics that backfire:**
- Formality and lengthy preamble
- Indirect or vague communication

---

## WESTERN EUROPE

---

### Germany 🇩🇪

**Style:** Analytical, formal, direct, quality-obsessed, contract-first, precision-focused, punctual.

**Key principles:**
- Germans say exactly what they mean. No hidden messages. No need to read between lines.
- Data, specifications, and cost analysis carry total weight — opinion without data is dismissed.
- Thoroughness over speed: German suppliers take time to respond properly and expect the same.
- Quality (Qualität) is a deep cultural value — price-only arguments without quality context are poorly received.
- Contracts are binding and taken extremely seriously — every term must be precisely specified.
- Punctuality is non-negotiable. Late to a meeting = professional disrespect.
- Hierarchy exists but is less rigid than Asian cultures — expertise commands more respect than title.

**Tactics that work:**
- Lead with a structured cost analysis (should-cost model) — they respect buyers who understand production economics.
- Be precise: "We require a unit price of €X.XX DDP [destination], confirmed by [date]."
- Volume commitment with clear schedules and forecasts is the primary lever.
- Technical engagement — understanding their process and capability — builds more trust than relationship small talk.

**Tactics that backfire:**
- Vagueness or ambiguity in specifications or requirements
- Emotional appeals or friendship framing
- Casual attitudes to contract terms

---

### France 🇫🇷

**Style:** Formal, intellectual, proud, indirect but with nuance, relationship-valued, food and quality culture.

**Key principles:**
- Formal address (Monsieur/Madame + surname) is expected in initial correspondence.
- Intellectual engagement is valued — French counterparts enjoy substantive discussion, debate, and rationale.
- La grande école and credentials culture: who you are matters as much as what you're buying.
- Lunch meetings are a legitimate and important part of business development.
- French suppliers in luxury, food, wine, cosmetics, and fashion carry significant brand power — their price is their brand.
- Language: French correspondence, even imperfect, signals effort and generates goodwill.

**Tactics that work:**
- Open with substantive qualifications of their product ("We admire the craftsmanship...").
- Engage intellectually — explain your reasoning for the price position, don't just state it.
- Total cost of ownership arguments (lower quality = more rework, customer returns) resonate.
- Volume commitment over multi-year horizon is the primary commercial lever.

---

### Italy 🇮🇹

**Style:** Relationship-driven, quality-proud, expressive, flexible on timing, design and aesthetics paramount.

**Key principles:**
- Fare bella figura (making a good impression) is important — presentation, style, and professionalism signal seriousness.
- Italian manufacturing is concentrated in clusters (fashion in Milan, ceramics in Modena, leather in Florence, machinery in Emilia-Romagna) — these clusters have strong identities.
- Relationship between the titolare (owner) and buyer is what moves the deal. Getting to the owner is the mission.
- Italians are flexible on terms but not on quality — compromise on spec is deeply uncomfortable.
- Small and medium family businesses dominate Italian manufacturing — decisions are personal and human.

**Tactics that work:**
- In-person visits to the factory/showroom are highly valued and often unlock real flexibility.
- Acknowledge design and aesthetic heritage sincerely.
- Long-term commitment to the relationship ("we want to build this with you for years") unlocks the owner's best price.
- Package deals that include design collaboration, co-development, or exclusivity trade well against price.

---

### Spain 🇪🇸

**Style:** Relationship and social context important, expressive, direct when trust is established, flexible on timing.

**Key principles:**
- Personalismo — relationships between individuals (not companies) drive business.
- Mañana culture is real: don't expect immediate responses or rigid adherence to deadlines.
- Decision-making can be slow; hierarchy is important in larger companies.
- Strong sectors: food and wine, ceramics/tiles, footwear, automotive parts, olive oil, machinery.
- Spanish suppliers to Latin America often have regional networks — valuable for buyers entering LATAM markets.

**Tactics that work:**
- Build the personal relationship before pressing on commercial terms.
- Business lunches/dinners are a genuine part of the relationship process — accept invitations.
- Direct price discussion is acceptable once rapport is established.
- References to their export experience and EU quality standards build mutual credibility.

---

### Netherlands 🇳🇱

**Style:** Direct, pragmatic, internationally oriented, anti-hierarchy, egalitarian, tulip no-nonsense.

**Key principles:**
- Dutch directness is legendary — they will tell you exactly what they think and expect the same.
- Egalitarianism is deep — everyone at the table is equal; seniority does not dominate conversation.
- International trade orientation is strong — the Netherlands is Europe's logistics gateway (Port of Rotterdam).
- Dutch suppliers are often traders and distributors as much as manufacturers.
- Sustainability and ESG credentials are increasingly important selection criteria.

**Tactics that work:**
- State your position clearly and directly from the outset.
- Data-based negotiation (market benchmarks, cost analysis) is highly respected.
- ESG and sustainability arguments genuinely influence commercial discussion.
- Logistics and total supply chain cost are often more negotiable than unit price.

---

### Belgium 🇧🇪

**Style:** Similar to Netherlands but more formal, French/Flemish cultural duality, consensus-driven.

**Key principles:**
- Dual culture (Flemish/Dutch-speaking vs. French/Walloon-speaking) — adapt your tone to the region.
- Consensus and thoroughness are valued. Don't rush decisions.
- Strong in chemicals, pharma, food, and logistics.

---

### Sweden 🇸🇪

**Style:** Egalitarian, consensus-driven (lagom — moderation), long-term focused, sustainability-first, punctual.

**Key principles:**
- Lagom (just the right amount) — moderation and fairness define Swedish business values.
- Consensus-based decisions can be slow but are stable once made.
- Sustainability credentials are not optional — Swedish buyers and sellers both prioritise environmental responsibility.
- Directness is valued but expressed with tact — not blunt like the Dutch, but clear.
- Swedish industrial companies (machinery, automotive, furniture — IKEA supply chain) are globally sophisticated.

**Tactics that work:**
- Lead with sustainability alignment — it is a genuine commercial criterion.
- Long-term partnership framing outperforms transactional price-push.
- Demonstrate that your supply chain meets their ethical sourcing requirements.

---

### Denmark 🇩🇰 / Finland 🇫🇮 / Norway 🇳🇴

**Style:** Similar to Sweden — egalitarian, direct, trust-based, sustainability-conscious, high quality standard.

**Key principles (Nordics shared):**
- Honesty and transparency are non-negotiable cultural values.
- Relationship moves faster than in Southern Europe once trust is established.
- Price negotiation is direct but fair — they don't squeeze; they want equitable terms.
- Finland: slightly more formal and introverted than Sweden/Denmark; silence in meetings is comfortable and normal.
- Norway: oil wealth background means price sensitivity is lower; quality and reliability matter most.

---

### Switzerland 🇨🇭

**Style:** Punctual (famously), formal, quality-absolute, risk-averse, multilingual.

**Key principles:**
- Swiss suppliers (watches, instruments, chemicals, pharmaceuticals, machinery) occupy premium market positions. Price compression arguments are rarely effective.
- Reliability and precision are the supreme commercial values.
- Risk aversion is high — they will not commit without due diligence.
- Multi-lingual (German/French/Italian regions) — adapt language accordingly.

**Tactics that work:**
- Total cost of ownership / reliability argumentation over pure price.
- Swiss suppliers respond to long-term security and brand-fit over short-term savings.

---

### United Kingdom 🇬🇧

**Style:** Politely indirect, formal in initial contact, pragmatic, dry humour signals comfort, understated.

**Key principles:**
- British understatement is famous — "That's quite interesting" may mean "I'm not convinced." "Not bad" often means "very good."
- Formality in first contact; informality develops quickly once rapport is established.
- Fairness and reciprocity are core values — a deal perceived as one-sided will not stick.
- Post-Brexit complexity has made UK/EU trade more complicated — tariffs, customs documentation, and rules of origin now apply on UK-EU flows.
- Strong in financial services, pharma, aerospace, whisky, premium food, and creative industries.

**Tactics that work:**
- Understated confidence works better than aggressive positioning.
- Reciprocity and fairness framing: "I want this to be a good deal for both sides."
- Humour — brief, dry, self-deprecating — signals trust and ease when used appropriately.

---

### Ireland 🇮🇪

**Style:** Warm, personable, storytelling-oriented, relationship-important, modestly direct.

**Key principles:**
- Irish business culture is warm and social — personal connection is genuinely valued.
- Relationships are built through conversation, shared context, and informal time.
- Directness is appreciated but delivered with warmth — not German bluntness.
- Strong in dairy/agri, pharma, tech, and financial services.

---

### Portugal 🇵🇹

**Style:** Formal, relationship-important, patient, quality proud, EU-integrated.

**Key principles:**
- Formal address initially; informality develops over time.
- Strong in textiles, footwear, cork, wine, ceramics, and automotive parts.
- Saudade (longing for connection) makes long-term partnerships feel natural and valued.
- Portuguese suppliers are increasingly competitive as a nearshoring option for Western Europe.

---

### Austria 🇦🇹

**Style:** Similar to Germany but slightly warmer and more social. Gemütlichkeit (cosiness and warmth) balances German precision.

**Key principles:**
- Strong in machinery, chemicals, wood products, and packaging.
- Formal but approachable. Decision-making is thorough.
- Environmental and sustainability credentials are highly valued.

---

## CENTRAL & EASTERN EUROPE

---

### Poland 🇵🇱

**Style:** Direct, pragmatic, hardworking, increasingly Western-aligned, proud of capability uplift since EU accession.

**Key principles:**
- Poland is now a significant EU manufacturing hub — automotive, electronics, furniture, food processing.
- Price pressure is accepted and expected — be direct.
- EU supply chain advantages (short lead time to Western Europe, euro pricing, no customs) are genuine and tradeable.
- English proficiency is high, especially among factory management.
- Polish suppliers are not aggressive negotiators but will not accept unreasonable terms.

**Tactics that work:**
- Competitive tension is effective — mention other Eastern European alternatives (Romania, Czech Republic).
- Volume commitment and long-term partnership matter. Polish factories want stable programs.
- Highlight EU regulatory compliance as a shared advantage versus Asian sourcing.

---

### Romania 🇷🇴

**Style:** Pragmatic, warm but formal initially, relationship matters more than in Poland, price-competitive.

**Key principles:**
- Romania's cost advantage in Western EU is significant: labour costs substantially below Germany/France.
- Strong in textiles, footwear, automotive parts, furniture, and IT services.
- Personal relationships are important — Romanian business is more relationship-oriented than Polish.
- Romanians are direct once rapport is established; formal in initial contact.

---

### Czech Republic 🇨🇿

**Style:** Formal, precise, quality-oriented, engineering culture, similar to Germany but less rigid.

**Key principles:**
- Czech manufacturing is strong in machinery, automotive, glass, ceramics, and electronics.
- Germans are major customers — Czech suppliers are accustomed to German quality standards.
- Precision and reliability are points of pride.
- Price negotiation is direct and data-driven — bring your should-cost analysis.

---

### Hungary 🇭🇺

**Style:** Formal, hierarchical by Central European standards, direct, engineering-focused.

**Key principles:**
- Hungary is a major automotive and electronics manufacturing base (Audi, Mercedes, Samsung all produce here).
- English proficiency is variable — German is often preferred.
- Price negotiation is straightforward; German-influenced commercial discipline.

---

### Serbia 🇷🇸

**Style:** Warm, hospitality-first, direct, entrepreneurial, relationship-valued.

**Key principles:**
- Serbia is an EU candidate with growing manufacturing in textiles, automotive, IT services.
- Hospitality is genuine and important — accept it and reciprocate.
- Serbs are direct and will tell you plainly what is and isn't possible.
- Price negotiation is frank and relatively quick.

---

### Ukraine 🇺🇦

**Note (2025 context):** Active war since Feb 2022 has disrupted manufacturing significantly. Western regions (Lviv corridor) continue operating. IT services sector remains active. Any sourcing must include detailed continuity risk assessment. Use `resilience-geopolitical-radar` skill for current status.

---

## LATIN AMERICA

---

### Mexico 🇲🇽

**Style:** Relationship-driven, personalismo, hierarchical in larger companies, warm, flexible on time.

**Key principles:**
- Mexico is a USMCA member — critical for US-bound supply chains. Duty-free access to US is a major commercial lever.
- Nearshoring boom (2023–2026) has made Mexico's manufacturing highly competitive — automotive, electronics, medical devices, textiles, food.
- Personalismo — personal relationships, not institutional ones, drive business. The person matters more than the company.
- Decision-making is hierarchical. Get to the director/owner for any meaningful commercial agreement.
- Mañana culture: time flexibility is real but varies by company size and sector. Large manufacturers (Tier 1 auto suppliers) operate to global standards.
- WhatsApp is the primary business communication channel.

**Tactics that work:**
- Lead with USMCA advantage — "Made in Mexico for the US market" is a powerful story.
- Build the personal relationship before commercial pressure.
- In-person visit (Monterrey, Guadalajara, Mexico City are manufacturing hubs) dramatically accelerates deal-making.
- Volume certainty and schedule consistency are highly valued levers.

---

### Brazil 🇧🇷

**Style:** Warm, expressive, relationship-first, jeitinho brasileiro (creative flexibility), hierarchical.

**Key principles:**
- Jeitinho brasileiro — "the Brazilian way" — means creative problem-solving and flexibility to find a path around obstacles. Embrace this.
- Personal warmth and social connection are prerequisites for business. Cold transactional approaches fail.
- Hierarchy is important — decisions flow from the top.
- Brazilian bureaucracy (tax system, customs, import/export regulations) is among the most complex in the world. Always engage a local agent or customs specialist.
- Strong in agriculture (soybeans, beef, coffee, sugar, orange juice), steel, mining, aircraft (Embraer), and footwear.

**Tactics that work:**
- Invest in relationship warmth — social time before commercial discussion is essential.
- Acknowledge the complexity of doing business in Brazil and your commitment to navigate it together.
- Brazilian suppliers value buyers who understand their market realities (regulatory burden, FX volatility, inflation).
- Long-term commitment language works strongly.

---

### Colombia 🇨🇴

**Style:** Warm, relationship-important, formal initially, expressive, proud of quality improvement story.

**Key principles:**
- Colombia has transformed significantly — business environment, rule of law, and export quality have all improved dramatically in the 2010s–2020s.
- Strong in flowers (world's second largest exporter), coffee, textiles, fruits, emeralds, and increasingly manufacturing.
- Relationship-building before commercial discussion is expected.
- Direct price negotiation is comfortable once rapport is established.

**Tactics that work:**
- Acknowledge Colombia's quality story and trajectory — they are proud of how far the country has come.
- Volume commitment and long-term partnership signals outperform pure price pressure.
- Coffee sector: direct trade premiums and sustainability certifications (Rainforest Alliance, Fair Trade) are significant commercial levers.

---

### Argentina 🇦🇷

**Style:** Expressive, intellectual, proud, relationship-valued, price-flexible but FX-sensitive.

**Key principles:**
- Argentine business culture is sophisticated and intellectual — substantive commercial conversation is enjoyed.
- FX volatility (peso) is a permanent feature. All export contracts should be in USD.
- Argentina has extraordinary agricultural capability (soy, wheat, beef, wine) and some industrial strength (chemicals, pharmaceuticals).
- Bureaucracy and capital controls are significant — work with an experienced customs agent.
- Economic volatility means Argentine suppliers price in risk. A stable buyer with reliable payment history commands significant goodwill.

---

### Chile 🇨🇱

**Style:** Professional, formal, stability-oriented, internationally aligned, direct.

**Key principles:**
- Chile is among Latin America's most stable and internationally oriented economies.
- Business culture is more formal and structured than Brazil or Argentina.
- Strong in copper mining, wine, salmon, lithium, and fresh fruit.
- Chilean suppliers are sophisticated negotiators — come prepared.

---

### Peru 🇵🇪

**Style:** Formal, hierarchical, relationship-valued, warm once established.

**Key principles:**
- Strong in minerals (gold, silver, copper, zinc), asparagus, grapes, avocados, quinoa, and textiles (alpaca, Pima cotton).
- Business culture blends Spanish colonial formality with warm Andean hospitality.
- Peruvian textile sector (alpaca, Pima cotton) produces premium products and commands premium pricing — negotiate on quality value rather than commodity price.

---

### Costa Rica 🇨🇷

**Style:** Professional, environmentally proud, stable, English-proficient in export sectors.

**Key principles:**
- Costa Rica punches above its weight in high-value niches: medical devices (major US multinationals have plants here), pineapple, coffee, and sustainability tourism.
- Environmental brand ("Pura Vida") is genuinely embedded in business culture — ESG and sustainability resonate strongly.
- Stability, rule of law, and reliability are true differentiators vs. other LATAM nations.

---

## SUB-SAHARAN AFRICA

---

### South Africa 🇿🇦

**Style:** Professionally Westernised, relationship-important, multi-cultural (Zulu/Xhosa/Afrikaner/Indian/Coloured communities), Ubuntu philosophy.

**Key principles:**
- Ubuntu — "I am because we are" — community and mutual support underpin South African business relationships.
- Business English is universal in commercial contexts.
- Strong in mining (platinum, diamonds, gold, chrome), wine, citrus, automotive parts (BMW, Toyota assembly), and financial services.
- B-BBEE (Broad-Based Black Economic Empowerment) scoring is a commercial requirement for South African government and corporate procurement — understand it if selling to SA, not just sourcing from it.
- Personal relationship and trust are important; South Africans do business with people they like.

**Tactics that work:**
- Acknowledge South Africa's quality standards and capability — they are justifiably proud.
- Long-term commitment language resonates strongly.
- Ubuntu framing — "we grow together" — is authentic and effective.

---

### Kenya 🇰🇪

**Style:** Entrepreneurial, warm, Nairobi-hub focused, tech-forward (Silicon Savannah), relationship-valued.

**Key principles:**
- Kenya is East Africa's commercial hub — strong in tea, coffee, flowers, fresh produce, and increasingly tech and financial services.
- Business culture is relationship-driven with increasing professionalism in export sectors.
- Mobile money (M-Pesa) and digital infrastructure are sophisticated — Kenya is ahead of many developed markets in fintech.
- Strong in floriculture (world's second-largest cut flower exporter, primarily to EU).
- In-person relationship and referrals through networks (church, university, professional associations) are very important.

---

### Ethiopia 🇪🇹

**Style:** Formal, relationship-driven, hierarchical, patient, proud of ancient culture.

**Key principles:**
- Ethiopia is the second-most populous country in Africa and a significant sourcing nation for coffee (origin of Arabica), sesame, oilseeds, and increasingly apparel (cheap labour, Hawassa Industrial Park).
- Business culture is formal and respect for seniority is paramount.
- Decision-making is slow and hierarchical — patience is essential.
- Coffee sector: Ethiopia's coffee (Yirgacheffe, Sidama, Harrar) commands significant premiums — treat origin story and farmer welfare as commercial assets.

---

### Ghana 🇬🇭

**Style:** Warm, hospitable, English-fluent, entrepreneurial, increasingly commercially sophisticated.

**Key principles:**
- Ghana is West Africa's most stable democracy and commercial environment.
- Business English is universal — communication is easy.
- Strong in cocoa (world's second-largest producer), gold, timber, and increasingly light manufacturing.
- Ghanaian business culture is warm and social — hospitality and personal relationship are important.

---

### Nigeria 🇳🇬

**Style:** Entrepreneurial, expressive, hierarchical, assertive, complex regulatory environment.

**Key principles:**
- Nigeria is Africa's largest economy and most complex commercial environment. Due diligence is critical.
- Business is relationship-driven and referral-based — cold approaches to major Nigerian businesses rarely succeed.
- Decision-making is centralised around the Oga (boss/owner) — get to the right person.
- Payment security is a genuine concern — LC or advance payment is recommended for new relationships.
- Strong in oil/gas, cocoa, sesame, cassava, and increasingly light manufacturing and tech.

---

## UNIVERSAL RULES THAT APPLY EVERYWHERE

Regardless of country, these principles hold globally:

1. **Know your should-cost before you know their price.** Run `should-cost-modelling` first. Always.
2. **Silence is a tactic everywhere.** After stating your position, stop talking.
3. **Reciprocity is universal.** Every concession you make should receive one in return.
4. **Written confirmation within 24 hours.** Verbal agreements drift everywhere in the world.
5. **BATNA is power everywhere.** The side with more alternatives has more leverage — in any culture.
6. **Face and dignity matter in every culture** — just expressed differently. Never humiliate.
7. **Long-term language unlocks short-term flexibility** in almost every culture.
8. **Payment reliability** — simply paying on time, every time — builds more goodwill than any tactic.

---

## Step 4: The Negotiation Playbook — Move by Move

### Opening Move: Setting the Anchor

**Principle:** The first number stated in a negotiation has outsized influence on the final outcome. This is anchoring. Whoever sets the anchor controls the negotiating range.

**As the buyer:** When possible, let the supplier make the first offer (their RFQ response). Then anchor your counter well below your target, not at your target.

**Counter-offer formula:**
```
Their quote:    $5.00
Your should-cost: $3.20
Your target:    $3.80
Your opening counter: $3.20 (your should-cost — justifiable and aggressive)
Expected landing zone: $3.60–3.90
```

**Opening counter framing options:**

Option A — Should-cost approach (analytical):
> "Thank you for your quote. Based on our analysis of material costs for [material] at current market prices, and production labour rates in [country], our cost model puts this product at $X.XX. We'd like to work toward that as our target price."

Option B — Competitive tension (market-based):
> "We appreciate your quote of $5.00. We are currently evaluating three suppliers for this program. We have a competitive quote at a lower price point. To move forward with you as our preferred partner, we need to align at $X.XX."

Option C — Volume commitment trade (integrative):
> "Your price of $5.00 is based on [X] units. We are prepared to commit to [2X] units annually in exchange for a unit price of $X.XX. This gives you the production planning certainty you need."

Option D — Direct and simple (works with many Indian and Turkish suppliers):
> "Your quote is $5.00. Our budget is $3.80. Can you make this work?"

---

### The Middle Game: Concession Strategy

**Concession rules — follow all of them:**

1. **Never make a unilateral concession.** Every concession you give must receive something in return. "If you can move to $3.80, we can increase our order to 2,000 units and commit to Net 30 payment."

2. **Make concessions decreasing in size.** First move: -$0.50. Second: -$0.25. Third: -$0.10. This signals you are approaching your limit. A buyer who makes equal-sized concessions signals they have unlimited room.

3. **Trade price for non-price terms.** Price is the hardest thing for a supplier to move on (it affects all their customers if word gets out). Payment terms, MOQ, lead time, and packaging are easier — move on those in exchange for price.

4. **Attach conditions to every concession.** "If we do X, then we need Y." Never just give — always link.

5. **Make the supplier work for each concession.** Don't give in quickly — even if you planned to concede. A concession given too fast signals you had more room.

6. **Track all concessions on both sides.** Before closing, review: what did you give? What did they give? Is the balance right?

---

### Handling Common Supplier Pushbacks

**"Our costs have increased — we can't go lower."**
- Response A: "I understand costs are rising. Can you share your material cost breakdown? If we can find savings in one area, we can work together on the price."
- Response B: "We've seen the same market data and our model still suggests X is achievable. What specifically has increased?"
- Response C: "We're open to a price review mechanism — let's agree a fixed price for the next 6 months and then review. That gives you stability now and us a fair process for future adjustments."

**"This is our best price — we can't do better."**
- Response A: Silence. Wait 10–15 seconds. Suppliers often fill silence with a better offer.
- Response B: "I appreciate that. Let me be direct — if we can't reach $X.XX, we will need to proceed with another supplier. Is there anything that would make $X.XX work for you?"
- Response C: Change the deal structure: "What if we gave you a 12-month purchase commitment for [volume]? Would that allow you to reconsider?"
- Response D: "Can we look at other terms instead of price? If we changed payment terms to [better terms for them], could you revisit the price?"

**"We need 30% advance payment."**
- Response A: "We typically work on Net 30 after delivery. What would it take to get there? We could offer a Letter of Credit against confirmed orders."
- Response B: "We can offer 10% advance, 90% against bill of lading copy. This is consistent with our standard payment terms across all suppliers."
- Response C (if supplier is new): "We understand you need security on a first order. We propose 20% advance for the first order, then moving to Net 30 after successful completion."

**"We can't meet your lead time."**
- Response A: "What's the bottleneck? Is it raw material sourcing, production capacity, or finishing? Maybe we can help solve part of it."
- Response B: "If we pre-order the material, can you reduce the production lead time? We can provide a purchase commitment to allow you to pre-stock."
- Response C: "Can you do an air shipment for part of the order to meet our launch date, with the balance by sea?"

**"Your volume is too low for our MOQ."**
- Response A: "What's the incremental cost of running a smaller batch? Can we pay a small-batch premium on this first order?"
- Response B: "We're starting small, but our forecast is [X] annually. Can we agree a lower MOQ for the first two orders with a volume ramp commitment?"
- Response C: "Can we consolidate multiple SKUs or colours into one production run to hit your MOQ?"

**"Another customer is offering us better terms."**
- Response A: "We're committed to building a long-term partnership with you. Long-term, we believe we can be a more valuable customer because of [reason]. What would it take to make us your preferred partner?"
- Response B: "We can't match every term, but we offer [specific advantage: faster payment, clear specs, reliable forecasts, growth potential]. Let's find a package that works."

---

### The Close: Locking the Deal

**Signs the supplier is ready to close:**
- They stop countering and ask for your "final number"
- They start asking about logistics, lead time, payment
- Their concessions are getting very small
- They say "let me speak to my manager" (often means "I want to say yes but need approval")

**Closing techniques:**

**The Summary Close:**
> "So to confirm where we've landed: unit price $X.XX FOB Ningbo, MOQ 1,000 units, lead time 45 days, payment 30% TT advance 70% against BL, 12-month warranty. Can we proceed on this basis?"

**The Conditional Close:**
> "If you can confirm $X.XX by end of day, I'm ready to issue the PO today."

**The Or-Else Close (use sparingly):**
> "We need to make a supplier decision by [date]. If we can confirm $X.XX today, we proceed with you. If not, we'll need to move forward with our alternative."

**The Give-to-Get Close:**
> "I can get this approved today if you can move to $X.XX. Can you do that?"

---

### Post-Negotiation Documentation

Always document what was agreed — immediately.

Send a deal confirmation email within 24 hours of any verbal agreement:

```
Subject: Summary of Commercial Agreement — [Product] — [Date]

Dear [Name],

Thank you for our productive discussion today. I'd like to confirm the agreed terms:

Product: [Name]
Quantity: [MOQ / Annual volume]
Unit price: $X.XX [Incoterms + Port]
Tooling: $X,XXX (one-time, buyer-owned)
Lead time: [X] days from PO + advance payment
Payment: [X]% TT advance, balance against BL copy
Quality standard: [Standard]
Warranty: [X] months from delivery
Valid until: [Date]

Please confirm your acceptance of the above by reply email.
We will issue the formal Purchase Order upon confirmation.

Best regards,
[Name]
```

**Why this matters:** Verbal agreements in supplier negotiations frequently "drift" between the call and the PO stage. A written summary sent immediately creates a record and locks the terms. If the supplier doesn't push back on the summary, the terms are confirmed.

---

## Step 5: Multi-Issue Package Negotiation

When negotiating multiple issues simultaneously, use package deal logic:

### Build the Package

List all issues and rate their value to each side:

| Issue | Cost to you if you concede | Value to supplier if they get it | Trade? |
|-------|---------------------------|----------------------------------|--------|
| Price | High | High | Both care → hardest to move |
| Payment terms | Low (cash-rich) | Very high (cash-strapped factory) | ✅ Trade this |
| Volume commitment | Medium (flexibility) | High (production planning) | ✅ Trade this |
| Exclusivity | High (sourcing risk) | Medium | ❌ Protect this |
| Lead time extension | Low | Medium | ✅ Trade this |
| Tooling ownership | Low | Medium | ✅ Trade this |

**Package deal example:**
> "Here's what I'm proposing as a package: We move from Net 30 to Net 15 [value to supplier], we commit to 5,000 units annually [value to supplier], and we extend your lead time from 30 to 40 days [value to supplier]. In return, we need you to move from $5.00 to $3.80. This is a package — we either take all of it or none of it."

**Why packages work:** Individual concessions get evaluated independently. Packages get evaluated as a whole. A supplier who says no to a $0.20 price reduction may say yes to a package that includes things they value more.

---

## Step 6: Negotiation Scripts by Scenario

### Scenario A: First-order price negotiation (new supplier, competitive market)

```
Email subject: Re: Quotation [RFQ-Number] — [Product] — Commercial Discussion

Dear [Name],

Thank you for your detailed quotation of [date]. Your technical capability and certifications are impressive and we are keen to establish a partnership.

To proceed, I need to address pricing. Your quoted price of $X.XX [Incoterms] is above our current budget of $X.XX. This budget reflects our analysis of production costs and current market pricing for comparable products sourced in [country].

We are in active discussions with [number] suppliers and plan to award this business within [timeframe].

I'd like to propose a commercial discussion — either by call or by email — to explore whether we can find a path forward. If you can move toward $X.XX, we are ready to place a first order for [quantity] units.

Please let me know your availability.

Best regards,
[Name]
```

---

### Scenario B: Incumbent supplier price reduction (existing relationship)

```
Email subject: Annual Price Review — [Product/Category] — [Year]

Dear [Name],

I hope you're doing well. As we approach our annual review, I'd like to discuss pricing for [product/category].

You have been a valuable partner and we have every intention of continuing this relationship. However, I need to be transparent: our procurement team has conducted a market review and we have received competitive quotes at prices below our current agreement.

Rather than go to market, I would like to give you the opportunity to review our pricing first. Specifically, we are targeting a [X]% reduction for the coming year, which would bring us to $X.XX [Incoterms].

I believe this is achievable given [reason: commodity price movements / our increased volume / efficiencies you've gained]. Can we schedule a call to discuss?

Best regards,
[Name]
```

---

### Scenario C: Tooling cost negotiation

```
Our position: We believe tooling should be amortised into the unit price over [X] units, rather than charged upfront.

Framing: "We're committing to [X] units over [Y] months. Rather than a $8,000 upfront tooling fee, could we amortise this at $0.80/unit over the first 10,000 units? This means you recover the same amount, but it reduces our upfront cash requirement and lets us place the order today."

Fallback: "If you need the tooling fee upfront, we'd need to reduce the unit price by $0.XX to offset the capital cost. What works better for you — lower unit price or upfront tooling?"
```

---

### Scenario D: Payment terms negotiation (buyer wants better terms)

```
"We'd like to propose moving to Net 45 from your proposed 30% advance + 70% BL. This is consistent with our standard payment terms for established suppliers.

To make this work for you: we can offer a confirmed Letter of Credit, which gives you bank-guaranteed payment and eliminates counterparty risk. Would that address your concern about payment security?"
```

---

## Step 7: Negotiation Red Lines

**Never cross these — they damage the relationship or your legal position:**

- ❌ Never make a false threat (bluffing about a competitor quote you don't have and can't produce if called)
- ❌ Never accept a price so low the supplier can't make money — they will cut corners or exit
- ❌ Never reveal your BATNA weakness ("We have no other option") — this hands all power to the supplier
- ❌ Never negotiate over the head of your contact to their boss without warning — this causes irreparable face loss
- ❌ Never promise volume you can't commit to — false volume forecasts destroy supplier trust permanently
- ❌ Never renegotiate a deal after it's been agreed in writing — except to acknowledge changed circumstances
- ❌ Never close a negotiation without documenting what was agreed

**Walk-away signals — when to stop negotiating:**

- Supplier has met your walk-away price and still can't match it → exit cleanly, leave door open
- Supplier is clearly making no profit — you are now creating a quality or supply risk
- Relationship is becoming adversarial — de-escalate before negotiating further
- Supplier is dishonest (claiming constraints that aren't real) — proceed with caution or exit

**Clean exit script:**
> "Thank you for your time and the effort you've put into this quote. Unfortunately we aren't able to bridge the gap on pricing at this stage. We'll keep you in mind for future opportunities where our budget better aligns with your pricing. I hope we can work together in the future."

---

## Step 8: Output Formats

After running this skill, produce one or more of:

**A. Negotiation Brief (internal — for buyer to use in call/meeting)**
- Situation assessment (power balance, BATNA)
- Issue map with positions
- Opening statement
- Concession plan (3 moves mapped out)
- Walk-away points
- Cultural notes if relevant

**B. Negotiation Email (external — ready to send)**
- Appropriate tone for supplier country
- Clear opening position
- Rationale (should-cost or competitive reference)
- Specific ask and deadline

**C. Deal Summary Email (post-negotiation)**
- All agreed terms listed
- Request for written confirmation

Ask user which output they need. Default: Negotiation Email + internal Brief.

---

## Related Skills
- `should-cost-modelling` — run this before every price negotiation. Know your numbers.
- `sourcing-project-context` — supplier history, relationship status, alternatives
- `rfq-drafting` — negotiation starts before the first quote with a well-structured RFQ
- `vendor-qualification` — knowing a supplier's financial health affects your negotiation stance
- `contract-redlining` — after negotiation closes, lock terms in the contract
- `supplier-outreach` — negotiation emails follow the same cultural framework as outreach
- `resilience-geopolitical-radar` — disruptions shift power balance; a supplier in a disrupted region has less leverage
