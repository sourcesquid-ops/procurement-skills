---
name: vendor-qualification
description: Use this skill when the user wants to qualify, evaluate, audit, or score a supplier or manufacturer. Trigger when the user mentions "vendor qualification", "factory audit", "supplier assessment", "how do I know if this factory is good", "supplier scorecard", "should I work with this supplier", "factory visit checklist", "supplier due diligence", "vetting a manufacturer", "second-source qualification", "supplier onboarding", or shares a factory profile or company name and asks for evaluation. Works for any country and any product category. Produces audit checklists, scoring matrices, red-flag detection, and recommendation reports.
---

# Vendor Qualification

Evaluates suppliers and manufacturers through a structured, multi-dimensional assessment framework. Produces scorecards, audit checklists, red-flag reports, and go/no-go recommendations for any supplier in any country.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Note: required certifications, quality standards, ESG policy, and blacklist items. These become mandatory gates.

## Workflow

### Step 1: Qualification Mode Selection

Ask the user which mode they need:

| Mode | When to use | Output |
|------|-------------|--------|
| **Remote desk review** | Initial screening before factory visit | Shortlist / eliminate |
| **Factory audit checklist** | On-site or virtual factory assessment | Detailed audit report |
| **Document review** | Evaluating certificates and compliance docs | Pass/fail per document |
| **Full scorecard** | Comparing multiple suppliers head-to-head | Ranked supplier matrix |
| **Re-qualification** | Annual review of existing supplier | Updated risk rating |

### Step 2: Remote Desk Review

For initial screening, gather publicly available information and supplier-provided profile:

**Online research checklist:**
- [ ] Alibaba / Global Sources / Made-in-China profile: verified? Gold supplier? Years active?
- [ ] Google the company name + "complaint" / "fraud" / "review"
- [ ] Check Dun & Bradstreet or Kompass for company registration
- [ ] LinkedIn: does the company have employees? Is the contact person verifiable?
- [ ] Check if factory exports to the user's target market (IEC, EXIM data where available)
- [ ] Google Maps / satellite view: does the factory address match a real industrial facility?
- [ ] Check for any litigation or news alerts

**Request from supplier (Desk Review Package):**
- Business registration certificate (with translation if needed)
- ISO/quality certification (with certificate number — verify online)
- Factory profile: capacity, headcount, production lines, year established
- Current customer references (minimum 2–3, with contact details)
- Export records to target market (letter of reference or BL copies)
- Bank reference letter (for financial credibility)
- Photos: factory floor, warehouse, lab/QC area
- List of sub-contractors (if any)

**Automatic disqualifiers (red flags — reject immediately):**
- Cannot provide business registration
- Refuses to share factory address or satellite-verifiable location
- No verifiable export history for product category
- Certificate number invalid when checked on issuing body's website
- Contact person has no LinkedIn / verifiable digital presence
- Price is >30% below market without explanation
- Urgently requests upfront payment before samples
- Uses a personal Gmail or Yahoo address for business comms

### Step 3: Factory Audit Checklist

For on-site or virtual (video call) audits, run through all sections:

**A. GENERAL / MANAGEMENT (20 points)**
- [ ] Legal entity name matches business registration (2)
- [ ] Factory ownership structure clear (2)
- [ ] Management team present and knowledgeable (3)
- [ ] Org chart and headcount verifiable (2)
- [ ] Production planning system in place (ERP / manual) (3)
- [ ] Customer complaint handling process documented (3)
- [ ] Business continuity plan exists (2)
- [ ] No major management turnover in past 12 months (3)

**B. PRODUCTION CAPABILITY (25 points)**
- [ ] Equipment list matches claimed capability (5)
- [ ] Equipment condition: well-maintained, calibrated (5)
- [ ] Capacity matches claimed monthly output (5)
- [ ] Production schedule shows realistic utilisation (3)
- [ ] Prototype / sample-making capability in-house (4)
- [ ] Tooling ownership clear (own, third-party, client-owned) (3)

**C. QUALITY MANAGEMENT (25 points)**
- [ ] ISO 9001 or equivalent — certificate valid, scope matches (5)
- [ ] QC team independent from production (3)
- [ ] Incoming material inspection process (IQC) (3)
- [ ] In-process inspection (IPQC) with records (4)
- [ ] Final inspection (FQC / OQC) with records (4)
- [ ] Calibration records for all measuring instruments (3)
- [ ] Non-conformance / CAPA process documented (3)

**D. COMPLIANCE & CERTIFICATIONS (15 points)**
- [ ] All claimed certifications valid and verifiable (5)
- [ ] Export licence in place for regulated products (3)
- [ ] Chemical / material compliance records (REACH, RoHS, etc.) (3)
- [ ] Country of origin documentation process (2)
- [ ] Conflict minerals / supply chain transparency (2)

**E. SOCIAL & ENVIRONMENTAL (15 points)**
- [ ] Minimum wage compliance verified (3)
- [ ] Working hours within legal limits (3)
- [ ] No child labour / forced labour (mandatory — automatic fail if violated) (5)
- [ ] Environmental permit / waste disposal process (2)
- [ ] Worker safety: PPE, fire exits, first aid (2)

**TOTAL SCORE: __ / 100**

Scoring guide:
- 85–100: Approved supplier — proceed
- 70–84: Conditional approval — corrective actions required within 60 days
- 55–69: Probationary — significant improvement needed; re-audit in 6 months
- <55: Do not approve — fundamental issues; reject or consider re-audit after major changes

### Step 4: Full Supplier Scorecard (Multi-Supplier Comparison)

For comparing 3–6 suppliers against each other:

| Criteria | Weight | Supplier A | Supplier B | Supplier C |
|----------|--------|------------|------------|------------|
| Price competitiveness | 20% | /10 | /10 | /10 |
| Quality system | 20% | /10 | /10 | /10 |
| Production capacity | 15% | /10 | /10 | /10 |
| Lead time | 10% | /10 | /10 | /10 |
| Communication responsiveness | 10% | /10 | /10 | /10 |
| Financial stability | 10% | /10 | /10 | /10 |
| Compliance / certifications | 10% | /10 | /10 | /10 |
| ESG / social compliance | 5% | /10 | /10 | /10 |
| References / track record | 5% | /10 | /10 | /10 |
| **WEIGHTED TOTAL** | 100% | **/100** | **/100** | **/100** |

Adjust weights based on user's priority (price-driven vs. quality-driven vs. compliance-driven).

### Step 5: Country-Specific Notes

Load from `references/country-risk-profiles.md` the relevant notes for:

**China:** Watch for trade companies masquerading as factories; verify via SAMR (company registry); check for affiliated entity / dual-entity setups where trading company owns the factory.

**India:** Company registration via MCA portal; GST verification via GST portal; MSME classification affects pricing; check for BIS licences if product is mandatory certification category.

**Vietnam:** Business registration via National Enterprise Registration (NER); check for Chinese-owned factories circumventing US tariffs via Vietnam origin claims (supply chain washing risk); verify local content for origin rules.

**Bangladesh:** For RMG (ready-made garments): BGMEA/BKMEA membership; ACCORD/Alliance building assessment status; OEKO-TEX for textiles.

**Turkey:** Turkish Chamber of Commerce registration; ISO certificate issuing body verifiable; CE conformity for EU market.

**Mexico:** SAT (tax authority) registration; IMMEX programme membership if maquiladora; USMCA rules of origin for US market.

**Eastern Europe (Poland, Romania, Czech, etc.):** EU company registration; CE/EN standards; GDPR compliance for data-handling suppliers.

**Middle East (UAE, Saudi):** Chamber of Commerce certificate; Saber certification for KSA; ESMA for UAE if product regulated.

### Step 6: Recommendation Output

```
VENDOR QUALIFICATION REPORT
Supplier: [Name]
Country: [Country]
Product category: [Category]
Assessment type: [Desk review / Audit / Scorecard]
Date: [Date]
Assessor: [User or team]

RECOMMENDATION: ✅ APPROVE / ⚠️ CONDITIONAL / ❌ REJECT

SCORE: [X/100] (if audited)

KEY STRENGTHS
1. [Strength]
2. [Strength]

KEY CONCERNS
1. [Concern] — Required action: [Action] — Deadline: [Date]
2. [Concern]

RED FLAGS DETECTED
[None / List if any]

MANDATORY CONDITIONS (must be met before first PO)
1. [Condition]

NEXT STEPS
1. [Action]
2. [Action]
```

## Related Skills
- `sourcing-project-context` — for approved supplier list and compliance requirements
- `rfq-drafting` — send RFQ to qualified suppliers
- `should-cost-modelling` — assess supplier's quoted price against should-cost
- `contract-redlining` — review and negotiate PO terms with new supplier
- `resilience-geopolitical-radar` — assess country-level risk for new supplier location
