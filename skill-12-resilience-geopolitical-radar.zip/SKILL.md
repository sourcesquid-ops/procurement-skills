---
name: resilience-geopolitical-radar
description: Use this skill when the user wants to monitor supply chain disruptions, geopolitical risks, port strikes, weather events, or tariff changes that could affect their active purchase orders or shipping routes. Also trigger when the user asks about "supply chain risk", "disruption monitoring", "port delays", "geopolitical impact on sourcing", "tariff risk", "will my shipment be affected", "check my supply chain for risk", "update on shipping disruptions", "force majeure risk", "Red Sea / Suez / Panama Canal situation", or asks about any current event in the context of procurement or logistics. Cross-references active POs and shipping routes from the user's context file against real-time global events to flag, quantify, and recommend mitigations for disruptions before they happen.
---

# Resilience & Geopolitical Radar

Monitors global disruption signals — port strikes, weather events, geopolitical tensions, trade policy changes, factory shutdowns, carrier failures — and cross-references them against the user's active POs, shipping routes, and supplier locations. Flags risks before they materialise. Recommends mitigation playbooks.

**Core philosophy:** Disruption only surprises you if you're not watching. This skill watches for you.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Extract:
- Active PO list and shipping routes
- Supplier countries and cities
- Origin and destination ports
- Freight mode and carrier (if known)
- Critical delivery dates and buffer stock levels
- Any existing contingency suppliers

## Workflow

### Step 1: Build the Risk Map

From the context file, construct the user's exposure map:

| Route | Supplier | Origin Port | Vessel/Mode | Destination | ETA | PO Value | Buffer Stock |
|-------|----------|-------------|-------------|-------------|-----|----------|--------------|
| [Route ID] | [Supplier] | [Port] | [FCL/LCL/Air] | [Port] | [Date] | [USD] | [Days] |

If context doesn't have active PO detail, ask the user to provide:
- Which suppliers/countries goods are currently in transit from
- Expected shipment dates or ETAs
- Any critical orders (high value, no buffer stock, hard deadline)

### Step 2: Search for Active Disruptions

Use web search to check current status across all risk categories. Search for each relevant geography based on the user's active routes.

**Search queries to run (adapt to user's routes):**

```
[Origin port] port congestion OR strike OR delay [current month year]
[Shipping route] disruption OR closure OR incident [current month year]
[Supplier country] factory shutdown OR labour strike OR protests [current month year]
[Supplier country] export ban OR trade restriction OR tariff [current year]
Red Sea Suez Canal shipping update [current month year]
Panama Canal water level shipping update [current month year]
Asia Europe shipping delays [current month year]
[Destination country] port strike OR congestion [current month year]
[Destination country] customs delays OR clearance backlog [current month year]
[Carrier name] vessel delay OR schedule change [if carrier known]
```

Also search for:
- Typhoon / cyclone / hurricane season impact on relevant routes
- Flood / earthquake / extreme weather in supplier regions
- Political instability or elections in supplier countries
- Currency volatility in supplier currency that affects pricing
- New tariffs, anti-dumping duties, or sanctions relevant to supplier country/product

### Step 3: Score Each Risk

For each disruption identified, score it:

**Impact × Probability Matrix:**

| Risk | Probability | Impact on PO | Financial Exposure | Days Risk |
|------|-------------|--------------|-------------------|-----------|
| [Event] | High/Med/Low | Direct/Adjacent/Low | $X,XXX | +X days |

**Severity levels:**

🔴 **CRITICAL** — Disruption confirmed, direct route affected, delivery at risk within 30 days
- Immediate action required
- Notify stakeholders today

🟠 **HIGH** — High probability disruption, adjacent route, delivery risk 30–60 days
- Activate contingency within 48 hours
- Prepare customer/internal communication

🟡 **MEDIUM** — Emerging risk, could escalate, watch and prepare
- Monitor daily
- Pre-position contingency supplier

🟢 **LOW** — Background risk, unlikely to materialise, noted
- Monthly check sufficient

### Step 4: Activate Mitigation Playbooks

For each Critical or High risk, recommend the appropriate playbook:

---

**PLAYBOOK A: Port Congestion / Strike**
1. Confirm with forwarder: is vessel affected or at risk?
2. Check alternative ports: e.g., if Shanghai congested → Ningbo / Qingdao / Tianjin
3. Request vessel diversion if cargo not yet loaded
4. If cargo loaded: request blank sailing skip or transshipment options
5. Consider air freight for urgent / high-value portion
6. Notify customer of potential delay and revised ETA
7. Check if force majeure clause applies (use `contract-redlining` skill)

**PLAYBOOK B: Factory / Supplier Disruption**
1. Contact supplier immediately for status and recovery timeline
2. Check inventory position: how many days of buffer stock remain?
3. Activate secondary supplier from ASL (see context file)
4. If no secondary supplier: fast-track qualification using `vendor-qualification` skill
5. Assess split sourcing: can primary supplier do partial delivery?
6. Update demand plan with stock-out risk window
7. Trigger emergency RFQ if replacement needed using `rfq-drafting` skill

**PLAYBOOK C: Tariff / Trade Policy Change**
1. Confirm effective date and HS code applicability
2. Calculate duty cost impact using `tariff-hs-lookup` skill
3. Assess options:
   - Accelerate shipments before effective date
   - Shift production to FTA-eligible country
   - Apply for tariff exclusion (if applicable)
   - Renegotiate supplier price to share duty burden
   - Adjust selling price downstream
4. Check FTA eligibility for alternative origin countries
5. Review contracts for duty absorption clauses

**PLAYBOOK D: Weather / Force Majeure**
1. Track storm/weather system trajectory vs. vessel position
2. Contact carrier/forwarder: vessel status, expected deviation
3. Check insurance coverage: cargo insurance for weather damage?
4. If vessel diverted: get revised ETA and port of discharge
5. Pre-notify customs broker at destination of potential delay
6. Assess buffer stock adequacy for delay duration
7. Communicate to internal stakeholders with realistic revised timeline

**PLAYBOOK E: Currency / Payment Risk**
1. If supplier currency has depreciated sharply: expect price renegotiation request from supplier
2. If supplier currency has appreciated: opportunity to renegotiate downward
3. For open LC positions: check if bank confirmation is affected by country risk changes
4. Consider FX hedging for large open positions (>$50,000)
5. Flag any payment instructions that have changed (fraud risk signal)

**PLAYBOOK F: Geopolitical Escalation**
1. Assess: is supplier country subject to new sanctions or export controls?
2. Check if product category is restricted under new rules
3. Review supplier's export compliance (EAR, OFAC, ITAR if US-adjacent)
4. Identify alternative sourcing countries (use `rfq-drafting` to fast-track)
5. Engage legal/trade compliance counsel for sanction screening
6. Increase safety stock if supply window is narrowing

---

### Step 5: Deliver the Radar Report

Output format:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SUPPLY CHAIN RESILIENCE RADAR
[Company] | Generated: [Date & Time]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ACTIVE POs MONITORED: [n] orders | $[X]K total exposure
ROUTES MONITORED: [Origin countries] → [Destination]

━━━ 🔴 CRITICAL ALERTS ━━━
[Alert 1]: [Description]
  Affected PO: [PO number / Supplier]
  Risk: [X] day delay | $[X]K exposure
  Action required: [Playbook X — specific steps]

━━━ 🟠 HIGH WATCH ━━━
[Alert]: [Description]
  Monitoring: [What to watch and when]
  Pre-position: [Action]

━━━ 🟡 EMERGING RISKS ━━━
[Risk]: [Description and why it matters]

━━━ 🟢 BACKGROUND CONTEXT ━━━
[Item]: [Context update — no action required]

━━━ ROUTE HEALTH SUMMARY ━━━
[Origin country] → [Destination]: [Status] | [Notes]
[Origin country] → [Destination]: [Status] | [Notes]

━━━ RECOMMENDED ACTIONS THIS WEEK ━━━
1. [Action] — Owner: [Sourcing/Logistics/Finance] — By: [Date]
2. [Action] — Owner: [Role] — By: [Date]

Next radar check: [Recommended frequency based on risk level]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Step 6: Set Monitoring Cadence

Based on current risk level, recommend:

| Overall risk level | Recommended check frequency |
|-------------------|----------------------------|
| Critical active alerts | Daily |
| High watch items | Every 2–3 days |
| Medium risks only | Weekly |
| Low / clear | Bi-weekly |

Offer to: "Run this radar again? Just say 'run radar' or 'supply chain update' and I'll check all current disruptions against your routes."

## Persistent Risk Categories to Always Monitor

**Chokepoints** (always relevant if shipping internationally):
- Suez Canal / Red Sea (Houthi attacks, traffic)
- Panama Canal (water levels, drought)
- Strait of Malacca (piracy, congestion)
- Strait of Hormuz (geopolitical tension)
- Taiwan Strait (political tension)
- Port of Los Angeles / Long Beach (labour, congestion)
- Rotterdam (European gateway congestion)
- Colombo / Singapore (transshipment hub delays)

**Seasonal patterns to pre-load:**
- Typhoon season: June–November (South China Sea, Japan, Philippines, Korea)
- Monsoon season: June–September (South Asia — affects Indian ports and factory access)
- Chinese New Year: Factory shutdowns January–February (always buffer 4–6 weeks)
- Golden Week: China October (1-week slowdown)
- Diwali: India October–November (logistics slowdown)
- Hurricane season: June–November (Gulf of Mexico, Caribbean, US East Coast)
- Winter storms: November–February (Northern Europe, US Midwest, Great Lakes)

**Trade policy watchlist:**
- US-China tariffs and Section 301 exclusion status
- India BIS mandatory certification requirements (expanding categories)
- EU CBAM (Carbon Border Adjustment Mechanism)
- EU Deforestation Regulation (EUDR) — timber, palm oil, soy, cattle, cocoa
- US Uyghur Forced Labour Prevention Act (UFLPA) — Xinjiang-origin goods
- UK CBAM and due diligence regulations
- RCEP implementation progress and rule-of-origin requirements

## Related Skills
- `tariff-hs-lookup` — for trade policy and duty impact analysis
- `incoterms-advisor` — when disruption changes recommended Incoterms
- `rfq-drafting` — for emergency alternative supplier RFQs
- `vendor-qualification` — for fast-tracking alternative suppliers
- `contract-redlining` — to assess force majeure clauses in existing contracts
- `freight-cost-calculator` — to price alternative routing options

## Reference Files
- `references/risk-frameworks.md` — PESTLE, supply chain resilience frameworks, risk scoring matrices
