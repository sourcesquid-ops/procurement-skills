---
name: purchase-order-generator
description: Use this skill when the user wants to create, generate, draft, or issue a purchase order. Also trigger when the user says "create a PO", "generate a purchase order", "issue a PO to my supplier", "write up the order", "convert this quote to a PO", "place an order with this supplier", "I need a PO for", "draft a purchase order", "send an order to the factory", "formalise this deal", "PO for this RFQ response", "blanket PO", "release order", "standing order", "call-off order", or "framework order". Covers standard POs, blanket/framework orders, call-off releases, repeat orders, and amendment POs. Works for any product category, any country pair, any currency, any Incoterms. Produces a complete, legally structured purchase order document ready to send to the supplier, with all standard commercial and quality T&Cs embedded. Can output as Word document, PDF, or plain text.
---

# Purchase Order Generator

Converts an approved supplier quote, negotiated deal, or verbal agreement into a complete, professionally structured purchase order — with all commercial terms, quality clauses, legal protections, and delivery requirements embedded. Closes the loop from RFQ → negotiation → binding order.

**Core philosophy:** A purchase order is a legal contract the moment the supplier acknowledges it. Every word matters. A poorly written PO is an unenforceable PO — and an unenforceable PO is a check written to whoever has the better lawyer.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Extract: company name, address, GST/tax ID, standard payment terms, Incoterms preference, quality standards, and default T&Cs. Pre-fill everything available from context — only ask for what's missing.

---

## Step 1: PO Type Classification

Identify which type of PO is needed:

| PO Type | When to use | Key characteristics |
|---------|-------------|---------------------|
| **Standard PO** | Single, defined order with fixed quantity and delivery date | Most common; one-time transaction |
| **Blanket / Framework PO** | Long-term agreement covering multiple releases over a period | Sets price, T&Cs, and total value ceiling; individual releases called off separately |
| **Call-off / Release Order** | Releasing a specific quantity against an existing blanket PO | References parent blanket PO; specifies quantity and delivery date |
| **Repeat / Standing Order** | Recurring order at fixed intervals (monthly, quarterly) | References prior PO; confirms continuation |
| **Amendment PO** | Changing terms of an already-issued PO | Must reference original PO; clearly states what changes and what remains |
| **Tooling PO** | Paying for moulds, dies, jigs, fixtures | Separate from production PO; ownership clause critical |
| **Sample PO** | Ordering pre-production or prototype samples | Low value; approval conditions attached |
| **Service PO** | Engaging a supplier for services rather than goods | Milestone-based; deliverable-defined |

---

## Step 2: Information Gathering

Collect all required fields. For each, check context file first — ask only for what's genuinely missing.

### Buyer Details (from context or ask once)
- Legal company name
- Registered address
- GST / VAT / Tax ID number
- PO issuer name and title
- Accounts payable contact (for invoice queries)
- Buyer's bank details (if needed for supplier reference)

### Supplier Details
- Legal entity name (must match contract / bank account)
- Factory / shipping address
- Supplier contact name and title
- Supplier GST / VAT / Tax ID (required for many jurisdictions)
- Supplier bank details (if TT payment — verify independently)

### Order Details
- PO number (buyer's sequential numbering system)
- PO date
- Order validity (date by which supplier must acknowledge)

### Line Items
For each line:
- Line number
- Part number / SKU / Item code (buyer's reference)
- Supplier part number / reference (their reference)
- Description (full, precise — never "as per sample" alone)
- Unit of measure (pcs, kg, m, set, box)
- Quantity ordered
- Unit price and currency
- Line total
- Any applicable tooling amortisation per unit

### Delivery Terms
- Incoterms (with named place — e.g., FOB Ningbo, Incoterms® 2020)
- Required delivery date (or delivery window)
- Ship-to address or port of destination
- Partial shipments: allowed or not?
- Ship-to contact name and phone (for logistics)
- Special handling requirements (fragile, hazmat, temperature-controlled)

### Commercial Terms
- Payment terms (e.g., 30% TT advance on PO, 70% TT against BL copy)
- Payment currency
- Invoice instructions (when to invoice, what reference to quote)
- Late delivery penalty (if applicable)
- Warranty period
- Price validity confirmation

### Quality Requirements
- Applicable standard (ISO 9001, CE, FDA, BIS, RoHS, FSC, GOTS, etc.)
- AQL level (e.g., AQL 2.5 Major / 4.0 Minor)
- Inspection type (self-certification, buyer inspection, third-party)
- Required documentation (CoA, test report, MSDS, certificate of origin, packing list)
- Golden sample / approved sample reference (if applicable)
- First article inspection (FAI) required? Y/N

### Packaging and Marking
- Inner pack configuration
- Master carton dimensions and max weight
- Packing list requirements
- Carton marking (PO number, item code, country of origin, quantity, weight, dimensions)
- Barcode / label requirements
- Any special export markings

---

## Step 3: Generate the Purchase Order

Output the complete PO in this format. Every field must be populated — no blanks, no TBDs, no "as discussed."

---

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                        PURCHASE ORDER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

BUYER                                    PURCHASE ORDER DETAILS
──────────────────────────────────────   ────────────────────────────────────────
[Company Legal Name]                     PO Number:    [PO-YYYY-NNNN]
[Registered Address Line 1]              PO Date:      [DD Month YYYY]
[City, State/Province, PIN/ZIP]          Valid until:  [Date — supplier must
[Country]                                              acknowledge by this date]
GST/Tax ID: [Number]                     Revision:     [00 for original]
                                         Currency:     [USD / EUR / INR / GBP]

BILL TO                                  SHIP TO
──────────────────────────────────────   ────────────────────────────────────────
[Legal billing entity if different]      [Delivery address / Port]
[Address]                                [City, Country]
[Contact: Name, Email, Phone]            [Contact: Name, Phone]
                                         [Special handling notes]

SUPPLIER
──────────────────────────────────────
[Supplier Legal Name]
[Factory Address Line 1]
[City, Province, Country, Postal Code]
GST/Tax ID: [Number]
Attn: [Supplier contact name, title]
Email: [Email] | Tel: [Phone]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ORDER LINES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Line  Part No.         Supplier Ref.   Description              UOM   Qty      Unit Price    Line Total
────  ───────────────  ──────────────  ───────────────────────  ────  ───────  ────────────  ──────────
001   [BUYER-SKU-001]  [SUPP-REF-001]  [Full item description   pcs   [X,000]  [USD X.XX]    [USD X,XXX]
                                        including grade,
                                        dimensions, colour]
002   [BUYER-SKU-002]  [SUPP-REF-002]  [Full description]       pcs   [X,000]  [USD X.XX]    [USD X,XXX]
003   TOOLING-001      N/A             [Mould/die description]  set   1        [USD X,XXX]   [USD X,XXX]
                                        (Buyer-owned tooling —
                                        see Clause 8)
────  ───────────────  ──────────────  ───────────────────────  ────  ───────  ────────────  ──────────

                                                       SUBTOTAL:           [USD XX,XXX.XX]
                                                       FREIGHT (if CIF):   [USD X,XXX.XX]
                                                       INSURANCE (if CIF): [USD XXX.XX]
                                                       TOTAL PO VALUE:     [USD XX,XXX.XX]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DELIVERY & SHIPPING TERMS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Incoterms:        [e.g., FOB Ningbo, Incoterms® 2020]
Required by:      [DD Month YYYY] — goods must arrive at destination
                  [OR: goods must be loaded on board vessel by DD Month YYYY]
Partial shipment: [Permitted / Not permitted without prior written consent]
Booking:          Supplier must provide shipping booking confirmation to buyer
                  minimum [X] business days before vessel cut-off.
Bill of Lading:   Consigned to: [Buyer name or To Order]
                  Notify party: [Freight forwarder name and address]
Advance Ship      Supplier must issue ASN to [email] minimum [X] days
Notice (ASN):     before shipment. ASN must include: PO number, line items,
                  quantities, vessel name, ETD, ETA, bill of lading number.
Documents         Supplier to provide within [5] banking days of shipment:
required:         ☐ Commercial Invoice (3 originals)
                  ☐ Packing List (3 originals)
                  ☐ Bill of Lading / Airway Bill (3 original BLs)
                  ☐ Certificate of Origin ([Form XX] for [FTA name] / GSP)
                  ☐ [Certificate of Analysis / Test Report]
                  ☐ [MSDS for hazardous goods]
                  ☐ [Phytosanitary / Health certificate if food/agri]
                  ☐ [Any other required by destination customs]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PAYMENT TERMS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Payment method:   [TT Bank Transfer / LC / DP / DA]
Payment schedule: [Option A — TT example:]
                  [30]% advance: USD [X,XXX] payable within [5] business days
                  of PO acknowledgement by supplier.
                  [70]% balance: USD [X,XXX] payable within [3] business days
                  of buyer receiving copy of clean on-board bill of lading.

                  [Option B — Net terms example:]
                  Net [30/45/60] days from date of delivery and receipt of
                  correct invoice quoting this PO number.

                  [Option C — LC example:]
                  Irrevocable Letter of Credit at sight, issued by [Bank Name]
                  in favour of supplier within [X] business days of PO
                  acknowledgement. LC terms to be agreed separately.

Invoice to:       [Email address for invoices]
Invoice must      This PO number: [PO-YYYY-NNNN]
quote:            Supplier Tax ID, Buyer Tax ID
                  Bank details: [Supplier's bank name, account, SWIFT/IBAN]
Currency:         All invoices must be in [USD / EUR / INR]. Buyer will not
                  accept invoices in any other currency without prior approval.
Late payment:     Buyer commits to payment per above schedule. In the event
                  of late payment, interest shall accrue at [X]% per annum.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
QUALITY REQUIREMENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Quality standard: All goods must comply with [ISO 9001:2015 / CE Directive /
                  BIS IS:[number] / FDA 21 CFR / RoHS 2011/65/EU / FSC /
                  GOTS / REACH / other applicable standard].
AQL:              Acceptance Quality Limit: [2.5] Major / [4.0] Minor defects
                  per MIL-STD-1916 / ISO 2859-1, Level II, unless otherwise
                  stated per line item.
Approved sample:  Production must conform to golden sample reference
                  [SAMPLE-REF-NUMBER] approved on [Date] and held by buyer.
                  Any deviation requires written approval before production.
Inspection:       [Option A:] Buyer or buyer's agent reserves the right to
                  inspect goods at supplier's premises prior to shipment.
                  Supplier must provide [5] business days' notice of
                  production completion.
                  [Option B:] Third-party inspection by [Intertek / SGS /
                  Bureau Veritas / QIMA] required before shipment. Cost borne
                  by [buyer / supplier].
                  [Option C:] Supplier self-certification with CoA required.
First Article:    [If applicable:] First article inspection (FAI) required
                  before production commences. Submit [X] units with full
                  dimensional report and CoA. Production may not proceed
                  without written FAI approval from buyer.
Documentation:    The following must accompany every shipment:
                  ☐ Certificate of Analysis (CoA) referencing this PO
                  ☐ Test report (per [standard, test method])
                  ☐ Declaration of Conformity (for CE / RoHS / REACH)
                  ☐ [MSDS / SDS for chemical/hazmat items]
Warranty:         Supplier warrants all goods for [12] months from date of
                  delivery (or [18] months from date of manufacture, whichever
                  is earlier) against defects in material and workmanship.
                  During warranty period, supplier shall replace or repair
                  defective goods at supplier's cost including freight.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PACKAGING AND MARKING REQUIREMENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Inner pack:       [X] pcs per inner pack / polybag with [specification]
Master carton:    [X] inner packs per master carton
                  Max carton dimensions: [L × W × H cm]
                  Max carton gross weight: [X] kg
Carton marking    Each master carton must be clearly marked with:
(all 4 sides):    ☐ Buyer's PO Number: [PO-YYYY-NNNN]
                  ☐ Item description and Buyer's Part Number
                  ☐ Quantity per carton (pcs)
                  ☐ Carton number / Total cartons (e.g., 1 of 50)
                  ☐ Gross weight (kg) and Net weight (kg)
                  ☐ Dimensions (L × W × H cm)
                  ☐ Country of Origin: Made in [Country]
                  ☐ [Hazmat / fragile / this way up markings if applicable]
Barcodes:         [EAN-13 / UPC-A / QR code specification if required]
Special:          [Temperature range / orientation / stacking limit if applicable]
Packing list:     One packing list per shipment, listing: PO number, line
                  items, carton numbers, quantities, weights, and dimensions.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STANDARD TERMS AND CONDITIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CLAUSE 1 — ACCEPTANCE
This Purchase Order constitutes an offer by Buyer to purchase the goods
described herein on these terms and conditions. This PO is accepted when
Supplier either: (a) sends written acknowledgement to Buyer within [3]
business days; or (b) commences performance. Any terms in Supplier's
acknowledgement that conflict with or add to these terms are expressly
rejected and shall not form part of the contract unless agreed in writing
by Buyer's authorised signatory.

CLAUSE 2 — DELIVERY
Time is of the essence. If Supplier anticipates a delivery delay, Supplier
must notify Buyer in writing as soon as reasonably practicable, stating the
cause, estimated delay, and remediation plan. Such notice does not waive
Buyer's rights under this PO.

Late delivery penalty: Goods delivered more than [3] calendar days after
the required delivery date may be subject to a penalty of [0.5]% of the
affected line value per calendar day of delay, up to a maximum of [5]% of
the total PO value. This is in addition to, not in lieu of, any other
rights Buyer may have.

CLAUSE 3 — PRICE AND CHANGES
Prices stated in this PO are fixed and inclusive of all costs except those
explicitly stated otherwise. Supplier may not make substitutions, changes to
materials, components, or manufacturing location without prior written
approval from Buyer. Unauthorised changes entitle Buyer to reject the goods
at Supplier's cost.

CLAUSE 4 — INVOICING
Supplier shall invoice Buyer only after goods have been shipped and documents
transmitted. Invoices must reference this PO number. Incorrect invoices will
be returned unpaid and the payment clock will restart from receipt of the
corrected invoice.

CLAUSE 5 — INSPECTION AND REJECTION
Buyer's payment does not constitute acceptance of the goods. Buyer reserves
the right to inspect and reject goods within [30] days of delivery. Rejected
goods shall be returned to Supplier at Supplier's cost, or destroyed at
Supplier's cost if return is not practicable. Supplier shall issue credit or
replacement within [15] business days of rejection notice.

CLAUSE 6 — WARRANTIES AND REPRESENTATIONS
Supplier warrants that all goods: (a) conform to the specifications, drawings,
and approved samples referenced in this PO; (b) are free from defects in
design (except buyer-provided design), material, and workmanship; (c) comply
with all applicable laws, regulations, and standards in the country of
manufacture and the destination country stated herein; (d) do not infringe
any third-party intellectual property rights; (e) are produced without the
use of child labour, forced labour, or practices inconsistent with the UN
Guiding Principles on Business and Human Rights.

CLAUSE 7 — LIABILITY AND INDEMNITY
Supplier shall indemnify, defend, and hold harmless Buyer, its affiliates,
officers, and customers from and against any claims, losses, costs, and
expenses (including legal fees) arising from: (a) Supplier's breach of this
PO; (b) any defect in the goods; (c) any infringement of third-party rights;
(d) Supplier's negligence or wilful misconduct. Supplier's total liability
shall not be limited to less than the total value of this PO.

Supplier shall maintain product liability insurance of not less than
[USD 1,000,000 / INR 7,500,000 / EUR 900,000] per occurrence and shall
provide Buyer with a certificate of insurance upon request.

CLAUSE 8 — TOOLING AND INTELLECTUAL PROPERTY
All tooling, moulds, dies, jigs, fixtures, and equipment funded wholly or
partly by Buyer remain the exclusive property of Buyer, regardless of
physical location. Supplier shall: (a) clearly mark all Buyer-owned tooling
as such; (b) maintain it in good condition at Supplier's cost; (c) use it
exclusively for Buyer's orders unless Buyer provides written consent
otherwise; (d) return it to Buyer within [30] days of written demand.

All intellectual property in the goods and their design, including any
improvements developed during this engagement, that relates to Buyer's
products or specifications remains exclusively owned by Buyer. Supplier is
granted a limited, non-exclusive licence to use such IP solely to fulfil
this PO.

CLAUSE 9 — CONFIDENTIALITY
Supplier shall keep all technical data, commercial terms, pricing, and
business information of Buyer strictly confidential. Supplier shall not
disclose Buyer's identity as a customer without prior written consent.
This obligation survives termination of the contract for [5] years.

CLAUSE 10 — SUBCONTRACTING
Supplier shall not subcontract any part of this order without Buyer's prior
written consent. Approved subcontractors are subject to the same obligations
as Supplier under this PO. Supplier remains fully responsible for the acts
and omissions of any approved subcontractor.

CLAUSE 11 — COMPLIANCE WITH LAWS
Supplier shall comply with all applicable laws and regulations, including
but not limited to: export control laws; anti-corruption and anti-bribery
laws (including the UK Bribery Act 2010 and US Foreign Corrupt Practices
Act); environmental regulations; employment and labour laws; and product
safety regulations in the country of manufacture and destination.

Supplier shall not offer, pay, or receive any bribe, kickback, or improper
payment in connection with this PO. Any violation entitles Buyer to
immediately terminate this and all other orders with Supplier.

CLAUSE 12 — AUDIT RIGHTS
Buyer reserves the right to audit Supplier's facility, records, and supply
chain relevant to this PO upon [5] business days' written notice. Supplier
shall cooperate fully and provide access to all relevant information.

CLAUSE 13 — FORCE MAJEURE
Neither party shall be liable for delay or failure caused by events beyond
its reasonable control (including acts of God, war, government action,
pandemic, natural disaster), provided: (a) the affected party gives written
notice within [5] business days of the event; (b) uses commercially
reasonable efforts to mitigate. If force majeure continues for more than
[60] days, the non-affected party may terminate this PO without penalty
by giving [30] days' written notice.

Force majeure does NOT excuse: Supplier's financial inability to perform;
foreseeable shortages of materials; or any event that Supplier assumed the
risk of in its quote.

CLAUSE 14 — TERMINATION FOR CONVENIENCE
Buyer may cancel this PO in whole or part by written notice to Supplier.
In such event, Buyer's liability is limited to: (a) the price of goods
already shipped and conforming to this PO; (b) reasonable documented costs
of work-in-progress at the time of cancellation, not to exceed [X]% of the
cancelled value; (c) the cost of raw materials specifically purchased for
this order and not usable for other purposes. Buyer shall not be liable for
lost profits or indirect costs.

CLAUSE 15 — GOVERNING LAW AND DISPUTES
This PO shall be governed by the laws of [India / Singapore / England &
Wales / State of [X], USA — select as appropriate].

Any dispute shall first be referred to senior management of both parties for
resolution within [30] days. If unresolved, the dispute shall be finally
determined by:
[Option A — Arbitration:] Arbitration under the rules of [ICC / SIAC /
LCIA / Indian Arbitration and Conciliation Act 1996], with the seat at
[Singapore / London / Mumbai / New Delhi], conducted in English before
[1/3] arbitrator(s). The award shall be final and binding.
[Option B — Courts:] The exclusive jurisdiction of the courts of
[Mumbai / Delhi / Singapore / London].

CLAUSE 16 — ENTIRE AGREEMENT AND PRECEDENCE
These terms and conditions, together with the face of this PO, constitute
the entire agreement for the goods described herein and supersede all prior
discussions, representations, and agreements. In the event of conflict
between documents, precedence is:
  1. PO face (quantities, prices, delivery dates)
  2. These Terms and Conditions
  3. Any Quality Agreement or Technical Specification signed by both parties
  4. Buyer's RFQ / specification documents
  5. Supplier's quotation (only to the extent not inconsistent with the above)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AUTHORISATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Issued by:          ________________________    Date: ____________
                    [Name], [Title]
                    [Company Name]
                    [Email] | [Phone]

Purchase Order      ________________________    Date: ____________
approved by:        [Approving authority — if different from issuer]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SUPPLIER ACKNOWLEDGEMENT (please sign and return)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

We, [Supplier Legal Name], hereby acknowledge and accept PO Number
[PO-YYYY-NNNN] dated [Date] on the terms and conditions stated herein.

Confirmed delivery date:  ________________________________
Any exceptions or notes:  ________________________________
                          (If no exceptions noted, all terms accepted)

Signed:             ________________________    Date: ____________
Name:               ________________________
Title:              ________________________
Company stamp:

Please return signed copy to: [Email] within [3] business days.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 4: Specialised PO Variants

### Blanket / Framework Purchase Order

A Blanket PO sets the commercial framework for a period (typically 12 months). Individual deliveries are called off against it.

**Additional fields for Blanket PO header:**
```
BLANKET PURCHASE ORDER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Blanket PO Number:    [BPO-YYYY-NNNN]
Effective date:       [Date]
Expiry date:          [Date — typically 12 months]
Maximum total value:  [USD XX,XXX] (indicative — actual releases may vary)
Estimated releases:   [X] releases over contract period
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PRICING SCHEDULE (fixed for contract period unless stated otherwise)
──────────────────────────────────────────────────────────────────
Item          Description              Price (per UOM)   Price break
────────────  ───────────────────────  ────────────────  ──────────────────
[ITEM-001]    [Description]            [USD X.XX / pcs]  1,000–4,999 units
                                       [USD X.XX / pcs]  5,000–9,999 units
                                       [USD X.XX / pcs]  10,000+ units

CALL-OFF PROCESS
────────────────────────────────────────────────────────
Individual releases shall be placed via Call-off Order referencing this
Blanket PO number. Each call-off must specify:
  - Blanket PO reference number
  - Call-off sequence number
  - Line items, quantities, and delivery date
  - Cumulative quantity to-date vs. blanket total

Minimum call-off quantity:  [X] units per release
Maximum call-off frequency: [X] per month
Forecast commitment:        Buyer will provide [4]-week rolling forecast
                            updated [weekly / fortnightly].
Lead time per release:      [X] calendar days from call-off to shipment.
```

---

### Call-off / Release Order

References the Blanket PO; adds only release-specific detail.

```
CALL-OFF ORDER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Call-off Number:       [CO-YYYY-NNNN-001]
Against Blanket PO:    [BPO-YYYY-NNNN] dated [Date]
Call-off Date:         [Date]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RELEASE DETAILS
──────────────────────────────────────────────────
Item          Description    Qty this release   Cumulative to-date
────────────  ─────────────  ─────────────────  ──────────────────
[ITEM-001]    [Description]  [X,000] pcs        [XX,000] / [blanket total]

Required ship date:    [Date]
Required arrival date: [Date]
All other terms:       As per Blanket PO [BPO-YYYY-NNNN]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

### Tooling Purchase Order

Tooling POs require extra precision on ownership, maintenance, and return.

**Additional tooling-specific clauses:**
```
TOOLING PURCHASE ORDER — ADDITIONAL TERMS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Tooling description:   [Injection mould / Die / Jig / Fixture — description]
Tooling specification: [Drawing number / specification reference]
Design approver:       Buyer (drawings reference [DWG-XXX])
Expected tool life:    [X00,000] shots / cycles
Cavity count:          [X] cavities

MILESTONE PAYMENT SCHEDULE
────────────────────────────────────────────────────
Payment 1: [50]% = [USD X,XXX] — on PO acknowledgement
Payment 2: [30]% = [USD X,XXX] — on approval of T1 samples
Payment 3: [20]% = [USD X,XXX] — on first production approval

T1 SAMPLE REQUIREMENTS
────────────────────────────────────────────────────
Supplier must produce T1 samples within [X] weeks of PO.
T1 submission must include:
  ☐ [X] samples from each cavity
  ☐ Full dimensional report (all critical dimensions on drawing)
  ☐ Material certificate (confirming specified grade)
  ☐ Gate and ejector mark locations confirmed acceptable
  ☐ Surface finish check vs. approved reference

TOOLING OWNERSHIP — ABSOLUTE TERMS
────────────────────────────────────────────────────
This tooling is the exclusive property of Buyer from the moment
of first payment. Supplier holds the tooling as bailee only.
Supplier may not:
  × Use this tooling for any customer other than Buyer
  × Sell, pledge, or encumber this tooling
  × Move this tooling without Buyer's written consent
  × Withhold this tooling for any reason, including payment disputes

Upon Buyer's written demand, Supplier shall release the tooling within
[5] business days, freight cost to be agreed case by case.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

### Amendment / Change Order

When modifying an existing PO after supplier acknowledgement.

```
PURCHASE ORDER AMENDMENT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Amendment Number:   [PO-YYYY-NNNN]-AMD-[01]
Original PO:        [PO-YYYY-NNNN] dated [Date]
Amendment Date:     [Date]
Reason for change:  [Brief reason — e.g., revised quantity per updated forecast]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CHANGES
────────────────────────────────────────────────────
The following supersedes the corresponding terms in the original PO:

Item          Field               Was                     Now
────────────  ──────────────────  ──────────────────────  ─────────────────────
[Line 001]    Quantity            [X,000] pcs             [X,500] pcs
[Line 001]    Required by date    [Original date]         [New date]
[Header]      Payment terms       [Original terms]        [New terms]

All other terms and conditions of PO [PO-YYYY-NNNN] remain unchanged.

New PO Total Value:    [USD XX,XXX.XX] (previously [USD XX,XXX.XX])

SUPPLIER ACKNOWLEDGEMENT OF AMENDMENT
────────────────────────────────────────────────────
Please acknowledge acceptance of this amendment by [Date].
Failure to respond is deemed acceptance.

Signed: _________________________ Date: _____________
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 5: India-Specific PO Requirements

When buyer or supplier is in India, add the following mandatory elements:

```
INDIA-SPECIFIC FIELDS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Buyer GSTIN:          [29ABCDE1234F1Z5]
Supplier GSTIN:       [XX-GSTIN of supplier]
Place of supply:      [State where goods are delivered]
HSN Code per line:    [8-digit HSN for each line item]
GST applicable:       [IGST XX% / CGST X% + SGST X%]
                      [Exempt / Zero-rated if export]
E-way Bill:           Supplier responsible for generating E-way Bill
                      for shipments >INR 50,000. E-way Bill number
                      must be communicated to buyer's transporter.
TDS (if applicable):  Buyer will deduct TDS at [1]% u/s 194Q if
                      annual purchases from this supplier exceed
                      INR 50 lakhs in this FY.
Reverse charge:       [Applicable / Not applicable — state reason]
Invoice format:       Tax invoice must comply with GST Rules 2017.
                      Must include: GSTIN of both parties, HSN codes,
                      GST rate and amount per line, place of supply.
MSME declaration:     Supplier to confirm MSME registration status.
                      If MSME, buyer commits to payment within 45 days
                      as per MSMED Act 2006.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 6: Country-Specific Tax and Compliance Fields

Automatically include the relevant fields based on supplier and buyer country:

| Country pair | Key additions |
|-------------|---------------|
| **India → India** | GSTIN both parties, HSN codes, E-way Bill, TDS u/s 194Q, MSME declaration |
| **India → Export** | GST zero-rated / LUT, ARE-1 form reference, FIRC from bank, RoDTEP/EPCG if applicable |
| **China → Any** | CCC certification if applicable, HS code, VAT rebate applicability, GACC registration for food |
| **EU → EU** | VAT numbers both parties, Intrastat declaration obligation, CE marking confirmation |
| **EU → Non-EU** | EUR.1 movement certificate for GSP preference, EORI numbers, customs declaration |
| **USA import** | HTS code, ISF filing 24h before loading, FDA prior notice if food/pharma |
| **UK import** | EORI numbers, commodity codes, Rules of Origin for UK trade deals |
| **GCC import** | Certificate of origin (Arab-specific form), SABER/IECEE if KSA, Halal cert if food |
| **Australia import** | AQIS/DAFF biosecurity declaration for agri/food, ACN/ABN numbers |

---

## Step 7: Pre-Issuance Quality Gates

Before finalising the PO, run through this checklist:

**Commercial completeness:**
- [ ] PO number assigned (sequential, traceable)
- [ ] All line items have full description — no "misc" or "as discussed"
- [ ] Prices match the confirmed supplier quote — no rounding errors
- [ ] Incoterms stated with named place and "Incoterms® 2020"
- [ ] Currency explicitly stated on every monetary figure
- [ ] Payment schedule adds up to 100% of PO value
- [ ] Delivery date is a specific date, not "ASAP" or "as agreed"
- [ ] Supplier acknowledgement deadline specified

**Legal completeness:**
- [ ] All 16 standard clauses present (or adapted for local law)
- [ ] Governing law and dispute resolution specified
- [ ] Tooling ownership clause present if tooling on this PO
- [ ] IP ownership clause present
- [ ] Liability cap set at minimum PO value
- [ ] Force majeure clause present
- [ ] Warranty period specified with start trigger

**Quality completeness:**
- [ ] Quality standard explicitly named (no "standard quality")
- [ ] AQL level specified
- [ ] Approved sample reference number included
- [ ] Required documents listed (CoA, test report, etc.)
- [ ] Inspection rights reserved

**Tax / Compliance:**
- [ ] Buyer and supplier tax IDs on the PO face
- [ ] HSN/HS codes on each line (if required by jurisdiction)
- [ ] Country of origin marked as required
- [ ] Certificate of origin type specified if FTA being used

**Common mistakes to catch:**
- ❌ "Price as per quote" without stating the actual price — if the quote changes, PO value is ambiguous
- ❌ Delivery date as "within 45 days" — always use a calendar date
- ❌ Missing GST/VAT information for domestic India orders
- ❌ "Standard T&Cs apply" with no T&Cs attached — unenforceable
- ❌ Tooling on the same PO as production without separate ownership clause
- ❌ Payment "upon delivery" without defining what triggers the delivery clock
- ❌ "Quality as per sample" without a sample reference number — which sample?

---

## Step 8: Delivery Format

After generating, ask the user which format:

- **Word document (.docx):** Use the `docx` skill — full formatting, company letterhead, signature blocks. Recommended for formal sending.
- **PDF:** Use the `pdf` skill — locked format, professional. Recommended for archive and supplier copy.
- **Excel line-item sheet:** Use the `xlsx` skill — if buyer needs a machine-readable PO for ERP upload.
- **Plain text / email body:** For fast, informal orders where a formatted doc is not required.

Default recommendation: Word document for formal supplier issuance, with PDF generated simultaneously for buyer records.

---

## Step 9: PO Transmittal Email

After generating the PO, produce a brief transmittal email:

```
Subject: Purchase Order [PO-YYYY-NNNN] — [Product Description] — [Company Name]

Dear [Supplier Contact Name],

Please find attached our Purchase Order [PO-YYYY-NNNN] dated [Date] for
[brief product description].

Key details:
• PO Value: [USD XX,XXX]
• Delivery required by: [Date]
• Delivery terms: [FOB/CIF/DAP + named place]
• Payment: [Brief payment term summary]

Please acknowledge acceptance of this order — including confirmation of the
delivery date — by [Acknowledgement deadline date].

If you have any questions about the specifications or terms, please contact
[Name] at [Email / WhatsApp] before commencing production.

We look forward to a smooth execution.

Best regards,
[Name]
[Title] | [Company]
[Email] | [Phone / WhatsApp]
```

---

## Related Skills
- `rfq-drafting` — the RFQ that precedes this PO
- `negotiation-playbook` — the negotiation that determined these terms
- `incoterms-advisor` — if Incoterms selection needs review before PO is issued
- `contract-redlining` — for reviewing supplier's counter-T&Cs if they push back
- `supplier-performance-scorecard` — track performance against this PO after issuance
- `supplier-outreach` — for the transmittal email and follow-up communications
- `tariff-hs-lookup` — for HSN/HS codes and duty rates to include on the PO
- `sourcing-project-context` — for company details, standard T&Cs, and approval thresholds
