---
name: freight-cost-calculator
description: Use this skill when the user wants to calculate freight costs, choose between sea and air freight, understand CBM calculation, estimate shipping costs, compare logistics options, or decide between FCL and LCL. Also trigger when the user says "how much will shipping cost", "should I ship by sea or air", "calculate CBM", "FCL vs LCL", "chargeable weight", "freight rate estimate", "how many cartons fit in a container", "what's cheaper — sea or air", "courier vs air freight", "cost per kg for sea", or provides carton dimensions and asks about shipping. Works for any trade lane, any freight mode, any cargo type.
---

# Freight Cost Calculator

Calculates freight costs, makes mode recommendations, computes CBM and chargeable weight, and benchmarks against current market rates for any trade lane.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Note preferred ports, freight mode, and forwarder from context.

## Workflow

### Step 1: Gather Cargo Details

Ask for (or extract from context/previous conversation):

- Origin city / country and port
- Destination city / country and port
- Cargo: number of cartons, dimensions (L × W × H in cm), weight per carton (kg)
- Total gross weight (if known)
- Any special cargo type: hazmat, refrigerated, oversized, high-value, fragile
- Urgency / required delivery date
- Incoterms (to determine what buyer is actually paying for)

### Step 2: Calculate Cargo Metrics

**CBM (Cubic Metre) Calculation:**

```
Carton CBM = (Length cm × Width cm × Height cm) / 1,000,000
Total CBM = Carton CBM × Number of cartons
```

**Chargeable Weight for Air Freight:**

```
Volumetric weight = Total CBM × 167 (kg)
Actual weight = Total gross weight (kg)
Chargeable weight = MAX(Volumetric weight, Actual weight)
```

**Chargeable Weight for Courier (DHL/FedEx/UPS):**

```
Volumetric weight = Total CBM × 200 (kg)  [courier divisor is 5000 cm³/kg]
Chargeable weight = MAX(Volumetric weight, Actual weight)
```

**Container Capacity (20' GP as baseline):**

| Container | Internal CBM | Max Payload (kg) | Typical carton count (std 60×40×40cm) |
|-----------|-------------|------------------|--------------------------------------|
| 20' GP | 25–26 CBM | 21,700 kg | ~900–1,000 cartons |
| 40' GP | 55–58 CBM | 26,500 kg | ~2,000–2,200 cartons |
| 40' HC | 67–70 CBM | 26,500 kg | ~2,400–2,600 cartons |
| 45' HC | 78–80 CBM | 27,000 kg | ~2,800–3,000 cartons |
| 20' Reefer | 22–25 CBM | 21,000 kg | (temp controlled) |

### Step 3: Mode Selection Decision Tree

**Rule of thumb:** Sea freight is 6–15× cheaper per kg than air. Air is 3–10× faster.

Ask:
1. What is the total CBM of the shipment?
2. What is the time sensitivity?
3. What is the value of the goods (USD)?

**Decision logic:**

```
If CBM ≥ 15: → FCL sea strongly preferred (own container)
If CBM 3–15: → LCL sea or FCL sea (share container)
If CBM < 1: → Courier or LCL depending on urgency
If transit time critical (< 7 days): → Air freight or express courier
If goods value > $50,000 AND CBM < 5: → Air freight (insurance cost justifies it)
If goods are perishable/temp-sensitive: → Air freight or reefer container
If goods are hazmat Class 1 (explosives): → Sea only (air restricted)
```

**FCL vs LCL decision:**

| Factor | FCL | LCL |
|--------|-----|-----|
| CBM threshold | >15 CBM → FCL is cheaper | <15 CBM → LCL more flexible |
| Transit time | Faster (direct) | Slower (+3–10 days for consolidation) |
| Damage risk | Lower (own container) | Higher (handling during deconsolidation) |
| Port flexibility | Less flexible | CFS to CFS (more inland points) |
| Lead time for booking | 3–7 days | 1–3 days |

### Step 4: Rate Benchmarks by Trade Lane

**Current benchmark ranges (2025 — update with web search for live rates):**

**Sea Freight — FCL rates (USD per container):**

| Trade Lane | 20' GP | 40' GP | 40' HC |
|------------|--------|--------|--------|
| China → India (JNPT/Mundra) | $600–1,200 | $900–1,800 | $1,000–2,000 |
| China → Europe (Hamburg/Rotterdam) | $800–2,500 | $1,200–3,500 | $1,300–3,800 |
| China → USA West Coast | $1,000–3,000 | $1,500–4,500 | $1,600–4,800 |
| China → USA East Coast | $2,000–5,000 | $3,000–7,000 | $3,200–7,500 |
| India → USA | $1,500–3,500 | $2,000–5,000 | $2,200–5,500 |
| India → Europe | $700–1,800 | $1,000–2,500 | $1,100–2,700 |
| Vietnam → USA | $1,200–3,000 | $1,800–4,500 | $2,000–5,000 |
| Vietnam → Europe | $900–2,200 | $1,300–3,200 | $1,400–3,500 |

Note: Add origin charges (origin THC, documentation, seaway bill) typically $150–400 per container. Add destination charges (destination THC, customs, delivery) typically $300–700.

**Sea Freight — LCL rates (per CBM, approx):**

| Trade Lane | USD/CBM |
|------------|---------|
| China → India | $25–55 |
| China → Europe | $30–70 |
| China → USA | $50–120 |
| India → Europe | $35–75 |
| India → USA | $55–130 |

Minimum charge: typically 1 CBM or 1,000 kg, whichever is higher.

**Air Freight rates (USD per chargeable kg):**

| Trade Lane | Economy | Express |
|------------|---------|---------|
| China → India | $2.50–5.00 | $5.00–9.00 |
| China → Europe | $3.00–6.00 | $6.00–12.00 |
| China → USA | $3.50–7.00 | $7.00–14.00 |
| India → USA | $3.50–7.00 | $7.00–14.00 |
| India → Europe | $3.00–6.00 | $6.00–12.00 |

**Express Courier rates (approx, under 30kg):**

| Trade Lane | DHL/FedEx/UPS approx |
|------------|---------------------|
| China → India | $4–8/kg |
| China → Europe | $6–12/kg |
| China → USA | $7–14/kg |
| India → Europe | $6–12/kg |
| India → USA | $7–14/kg |

*Always get live quotes from freight forwarders. These are planning benchmarks only.*

### Step 5: Produce Cost Summary

Output format:

```
FREIGHT COST ESTIMATE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Cargo: [N] cartons | [X] CBM | [X] kg gross
Origin: [City, Port]
Destination: [City, Port]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

OPTION 1: [FCL/LCL] SEA FREIGHT
Container: [20'/40' GP/HC] or [X CBM LCL]
Estimated freight: $[X,XXX] – $[X,XXX]
Origin charges (THC + docs): ~$[XXX]
Destination charges (THC + delivery): ~$[XXX]
Insurance (0.5% CIF value): ~$[XXX]
─────────────────────────────────────
TOTAL SEA ESTIMATE: $[X,XXX] – $[X,XXX]
Cost per unit: $[X.XX]
Transit time: [X–X days]

OPTION 2: AIR FREIGHT
Chargeable weight: [X] kg
Rate: $[X.XX]/kg
Estimated freight: $[X,XXX] – $[X,XXX]
Destination charges: ~$[XXX]
Insurance: ~$[XXX]
─────────────────────────────────────
TOTAL AIR ESTIMATE: $[X,XXX] – $[X,XXX]
Cost per unit: $[X.XX]
Transit time: [3–7 days]

PREMIUM FOR AIR vs. SEA: $[X,XXX] (+[X]%)

RECOMMENDATION: [Sea/Air] — [1-line rationale]

Next step: Get live quotes from 2–3 freight forwarders
using these specifications.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Step 6: Pro Tips to Surface

- **Container load check:** Flag if CBM calculated suggests the shipment will leave significant unused container space — buyer may be over-specified on container size.
- **Weight check:** Flag if cargo density is very high (e.g., metal parts) and weight will hit container payload limit before CBM fills — switch to 20' if approaching 40' payload limit.
- **Season note:** Rates spike pre-Chinese New Year (Jan), Golden Week (Oct), and pre-Christmas peak (Aug–Oct for USA/Europe). If booking near these windows, advise booking 4–6 weeks early.
- **Forwarder tip:** For LCL, always get 3 quotes. LCL pricing varies significantly by consolidator.
- **Duty-inclusive check:** Remind user that freight cost is only part of landed cost — add import duty from `tariff-hs-lookup` for total picture.

## Related Skills
- `incoterms-advisor` — determines who pays which freight component
- `tariff-hs-lookup` — import duty to complete landed cost
- `should-cost-modelling` — incorporate freight into landed cost model
- `resilience-geopolitical-radar` — for route risk affecting freight options
