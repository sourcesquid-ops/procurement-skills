---
name: incoterms-advisor
description: Use this skill when the user asks about Incoterms, delivery terms, shipping terms, or who is responsible for freight, insurance, customs, or risk in a trade transaction. Also trigger when the user says "what Incoterms should I use", "should I buy FOB or CIF", "who pays for freight", "when does risk transfer", "EXW vs DDP", "what does DAP mean", "what are the best terms for importing from China", or is negotiating delivery terms with a supplier. Covers all 11 Incoterms 2020 rules, with selection logic based on freight mode, country pair, buyer/seller risk preference, supply chain maturity, and commercial context. Works for any country pair, any product, any transport mode.
---

# Incoterms Advisor

Selects, explains, and negotiates Incoterms 2020 rules for any trade transaction. Recommends the optimal term based on freight mode, country pair, buyer experience, and commercial context. Explains implications for cost, risk, insurance, and customs.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Note preferred Incoterms, logistics setup, and freight mode from context.

## Quick Reference — All 11 Incoterms 2020

### Group 1: Any Transport Mode (multimodal, air, courier, road, rail)

| Term | Full Name | Risk Transfers | Buyer Pays From | Use When |
|------|-----------|---------------|-----------------|----------|
| **EXW** | Ex Works | At seller's factory gate | Everything | Buyer has local pickup capability; seller has minimal obligation |
| **FCA** | Free Carrier | Named place (often seller's factory) | From named place | Air freight / container; replaces EXW in most cases; allows on-board BL |
| **CPT** | Carriage Paid To | Named destination | From destination | Seller books freight; buyer takes risk at origin carrier handover |
| **CIP** | Carriage & Insurance Paid To | Named destination | From destination | Like CPT but seller provides insurance (Institute Cargo A — broadest) |
| **DAP** | Delivered at Place | Named destination | Unloading + import duty | Seller manages everything except import duty; buyer handles customs |
| **DPU** | Delivered at Place Unloaded | Named destination (unloaded) | Import duty only | Seller unloads at destination; buyer handles import |
| **DDP** | Delivered Duty Paid | Named destination (duty paid) | Nothing | Seller controls everything; highest obligation for seller |

### Group 2: Sea and Inland Waterway ONLY

| Term | Full Name | Risk Transfers | Use When |
|------|-----------|---------------|----------|
| **FAS** | Free Alongside Ship | Alongside vessel at origin port | Bulk/breakbulk cargo |
| **FOB** | Free On Board | On board vessel at origin port | Most common for containerised sea freight |
| **CFR** | Cost and Freight | On board at origin (risk) | Seller books freight; buyer arranges insurance |
| **CIF** | Cost, Insurance and Freight | On board at origin (risk) | Seller books freight and provides minimum insurance |

**Important:** FOB, CFR, CIF, FAS are for sea/inland waterway ONLY. Using FOB for air freight is technically incorrect (should be FCA). However, FOB is widely used colloquially for air — acknowledge this in output while recommending FCA for precision.

## Selection Decision Tree

### Step 1: What transport mode?

**Air or courier** → Use FCA, CPT, CIP, DAP, DDP, EXW
**Sea freight (FCL/LCL)** → All terms available; FOB most common
**Road/rail** → FCA, CPT, CIP, DAP, DDP, EXW
**Multimodal** → FCA, CPT, CIP, DAP, DDP, EXW

### Step 2: Who manages freight best?

**Buyer has strong freight forwarding capability** → EXW or FCA or FOB
- Buyer controls freight cost and carrier selection
- Buyer can consolidate with other shipments
- Recommended for experienced importers with volume

**Seller has better freight rates or local logistics knowledge** → CIF, CFR, CPT, DAP
- Useful when buyer is new to origin country logistics
- Seller may have preferential rates from origin
- Risk: seller may inflate freight; buyer loses visibility

**Buyer wants full control over everything** → EXW (maximum buyer responsibility)

**Buyer wants to do nothing** → DDP (maximum seller responsibility)

### Step 3: Who handles import customs?

**Buyer handles their own import** → Any term except DDP
- Buyer's customs broker knows their commodity and classification
- Buyer can use FTA preference (need to control import process)
- Buyer can reclaim import VAT directly

**Seller handles import** → DDP only
- Avoid DDP unless seller has proven customs capability in destination country
- Risk: seller may use incorrect HS code or undervalue
- Seller may not pass duty savings from FTA to buyer

### Step 4: Insurance

- **CIP**: Seller must provide Institute Cargo Clause A (broadest — all risks)
- **CIF**: Seller provides Institute Cargo Clause C (minimum — named perils only)
- **All other terms**: Buyer arranges own cargo insurance (recommended regardless)
- Recommendation: Always insure, regardless of Incoterm. Incoterms define risk transfer but don't guarantee recovery.

### Step 5: Letter of Credit (LC) Compatibility

- **FOB and CIF**: Most LC-friendly; banks understand these terms universally
- **FCA**: Increasingly accepted; specify "FCA [address], with on-board BL notation" in LC
- **EXW**: Problematic for LC — buyer must control export clearance
- **DAP/DDP**: Less common in LC transactions; possible but requires LC text precision

## Country-Pair Recommendations

**Buying from China:**
- Containerised sea: **FOB [Port]** — standard, well understood by Chinese factories
- Air freight: **FCA [City]** technically correct; **FOB** widely used and accepted
- If new buyer / first shipment: **CIF** to reduce logistics burden on buyer
- Advanced/large volume: **EXW** for maximum cost transparency

**Buying from India:**
- Sea: **FOB** (Mumbai/Nhava Sheva, Chennai, Mundra)
- Note: Indian exporters sometimes quote EXW — push for FOB to control export clearance
- Avoid DDP from India unless exporter has proven destination country experience

**Buying from Vietnam:**
- Sea: **FOB** (Ho Chi Minh City / Cai Mep, Haiphong)
- Air: **FCA Hanoi / FCA Ho Chi Minh City**

**Buying from Bangladesh:**
- RMG (garments): **FOB Chittagong** — standard for the industry
- Note: Chittagong port can have congestion; allow extra lead time

**Buying from Turkey:**
- Sea to Europe: **DAP** common for intra-Europe; **FOB** for intercontinental
- Road to Europe: **DAP [city]** — seller delivers by road

**Buying from Eastern Europe (to Western Europe):**
- Road freight: **DAP** or **DDP** — seller delivers by truck; DDP very common

**Selling to the USA:**
- Typically: **CIF US port** or **DAP US customer address**
- US buyers often want **FOB** for familiarity but accept DAP
- DDP to USA: requires seller to have US customs broker and EIN

**Selling to EU:**
- **DAP** is most common for small-medium shipments
- DDP requires IOSS registration for B2C under €150

## Negotiating Incoterms with Suppliers

**If supplier insists on EXW:**
- Counter: "We prefer FCA [your factory address]. This is similar to EXW but allows our freight forwarder to issue an on-board bill of lading, which is required for our LC."
- EXW creates an export clearance problem — buyer is responsible for export customs in seller's country.

**If supplier insists on CIF or CFR:**
- Counter: "We prefer FOB. We have our own freight agreement and prefer to manage our own freight and insurance."
- CIF gives seller control over freight booking — may inflate; buyer loses track.

**If buyer insists on DDP:**
- Seller should understand: DDP means seller pays import duty, handles customs, and delivers to buyer's door. This requires seller to have a customs presence or broker in destination country.
- Counter: "We can do DAP [your address], which delivers to your door. You'll need to handle import clearance — we can provide all necessary documents."

## Common Mistakes and How to Fix Them

| Mistake | Risk | Fix |
|---------|------|-----|
| FOB used for air freight | Technical incorrectness; possible LC issues | Use FCA for precision |
| EXW from China without export agent | Buyer has no right to export goods in China | Switch to FCA |
| CIF used because seller insisted | Buyer loses freight visibility and possibly pays inflated rates | Negotiate to FOB |
| DDP to USA without US broker | Customs failure, detention, fines | Seller needs US customs broker before agreeing to DDP |
| No Incoterm specified in contract | Disputes over who pays what, and when risk transfers | Always specify: Incoterm + Named Place + "Incoterms® 2020" |
| Named place too vague | "FOB China" is not valid — must be specific port | Use "FOB Ningbo, Incoterms® 2020" |

## Output Format

For each recommendation, explain:

1. **Recommended Incoterm**: [Term + Named place]
2. **Why**: [2–3 sentence rationale]
3. **Buyer responsibilities**: [Bulleted list]
4. **Seller responsibilities**: [Bulleted list]
5. **Risk transfers at**: [Exact point]
6. **Insurance**: [Who arranges, minimum recommended]
7. **Alternative**: [Second-best option and why]

## Related Skills
- `freight-cost-calculator` — once Incoterms selected, calculate freight cost
- `tariff-hs-lookup` — for DAP/DDP: buyer or seller needs to know duty rates
- `rfq-drafting` — embed correct Incoterms into RFQ document
- `contract-redlining` — ensure Incoterms are correctly stated in PO/contract
