---
name: should-cost-modelling
description: Use this skill when the user wants to calculate what a product should cost to manufacture, estimate a fair price before negotiating, tear down a supplier's quote, identify cost drivers, or build a should-cost model. Also trigger when the user says "is this price fair", "what should this cost", "cost breakdown", "cost teardown", "BOM costing", "total cost of ownership", "why is the supplier charging this much", "I need a target price", "analyse this quote", or "am I getting ripped off". Works for any product category and any manufacturing country. Produces a structured cost model with material, labour, overhead, tooling amortisation, and margin estimates.
---

# Should-Cost Modelling

Builds a bottom-up cost model for any product to establish a fair target price before negotiation — or to challenge a supplier quote. Uses industry benchmarks for material prices, labour rates, overhead structures, and margin expectations across different manufacturing countries.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Note target country of manufacture, product category, and volume. These determine the labour rates and overhead multipliers to apply.

## Framework

Every product cost = Material + Labour + Overhead + Tooling Amortisation + Profit Margin + Trade/Logistics add-ons

```
TOTAL LANDED COST
├── Ex-Works (EXW) Price
│   ├── Direct Materials (BOM cost)
│   │   ├── Raw materials
│   │   ├── Purchased components
│   │   └── Packaging
│   ├── Direct Labour
│   │   ├── Machine operator time
│   │   ├── Assembly time
│   │   └── QC / inspection time
│   ├── Manufacturing Overhead
│   │   ├── Equipment depreciation
│   │   ├── Energy / utilities
│   │   ├── Factory rent
│   │   └── Indirect labour (supervision, maintenance)
│   ├── G&A (General & Administrative)
│   ├── Tooling amortisation (per unit)
│   └── Profit margin
├── Freight (origin to destination)
├── Insurance
├── Import duty
└── Destination charges (clearance, delivery)
```

## Workflow

### Step 1: Product Profile

Gather:
- Product name and description
- Manufacturing process (injection moulding / die casting / CNC / textile / electronics / etc.)
- Bill of Materials (BOM): list of materials and components with quantities
  - If no BOM, ask the user to describe the product and estimate components from description
- Annual volume and order quantity
- Manufacturing country (or ask user which country to model)
- Target Incoterms (EXW, FOB, CIF, DAP)

### Step 2: Material Cost Estimation

For each BOM item, estimate cost:

**Plastics (per kg benchmarks — adjust for grade and market):**
| Material | $/kg approx (China) | $/kg approx (India) | $/kg approx (Vietnam) |
|----------|--------------------|--------------------|----------------------|
| PP (standard) | $1.20–1.60 | $1.10–1.50 | $1.30–1.70 |
| ABS | $1.80–2.20 | $1.70–2.10 | $1.90–2.30 |
| PC | $3.00–4.00 | $2.80–3.80 | $3.20–4.20 |
| Nylon PA6 | $2.50–3.20 | $2.30–3.00 | $2.60–3.30 |
| HDPE | $1.10–1.40 | $1.00–1.30 | $1.20–1.50 |
| TPU | $2.80–4.00 | $2.60–3.80 | $3.00–4.20 |
| Recycled PP | $0.70–1.00 | $0.65–0.90 | $0.75–1.05 |

**Metals (per kg benchmarks):**
| Material | $/kg approx |
|----------|------------|
| Carbon steel (sheet) | $0.80–1.20 |
| Stainless steel 304 | $2.50–3.50 |
| Aluminium 6061 | $2.80–3.80 |
| Zinc alloy (die cast) | $2.20–3.00 |
| Copper | $8.00–10.00 |

**Textiles (per metre benchmarks):**
| Fabric | $/m approx (China) | $/m approx (Bangladesh) | $/m approx (India) |
|--------|-------------------|------------------------|-------------------|
| Cotton woven (120gsm) | $1.50–2.50 | $1.20–2.00 | $1.30–2.20 |
| Polyester fabric | $0.80–1.50 | $0.70–1.30 | $0.75–1.40 |
| Nylon ripstop | $2.00–3.50 | $1.80–3.00 | $1.90–3.20 |
| Fleece (200gsm) | $1.80–3.00 | $1.60–2.80 | $1.70–2.90 |

**Material waste factor:** Add 5–15% for material waste/scrap (higher for complex geometries, lower for high-efficiency nesting).

### Step 3: Labour Cost Estimation

**Hourly labour rates by country (fully-loaded, incl. benefits, 2025):**

| Country | $/hr (low-skill mfg) | $/hr (semi-skilled) | $/hr (skilled/technical) |
|---------|---------------------|--------------------|-----------------------|
| Bangladesh | $0.40–0.60 | $0.60–1.00 | $1.00–2.00 |
| Vietnam | $0.80–1.20 | $1.20–2.00 | $2.00–4.00 |
| India (Tier 2 city) | $0.80–1.50 | $1.50–3.00 | $3.00–6.00 |
| India (Metro) | $1.20–2.00 | $2.00–4.00 | $4.00–8.00 |
| China (interior) | $2.00–3.00 | $3.00–5.00 | $5.00–8.00 |
| China (coastal) | $3.00–5.00 | $5.00–7.00 | $7.00–12.00 |
| Turkey | $3.50–6.00 | $6.00–10.00 | $10.00–16.00 |
| Mexico | $2.50–4.50 | $4.50–8.00 | $8.00–14.00 |
| Poland / Romania | $6.00–10.00 | $10.00–15.00 | $15.00–25.00 |
| Western Europe | $20.00–35.00 | $30.00–50.00 | $45.00–80.00 |

**Cycle time estimation:**
- Simple injection moulded part: 20–120 seconds machine cycle; 5–30 seconds labour handling
- Simple metal stamping: 5–30 seconds
- PCB SMT assembly (per board): depends on component count; estimate 30–120 min for medium complexity
- Garment assembly: 10–45 minutes depending on complexity (SAMs)
- Manual assembly of consumer goods: estimate from process steps × time per step

Labour cost per unit = (Cycle time in hours) × (Hourly rate) × (Number of operators)

### Step 4: Overhead and Margin

**Overhead as % of direct costs (typical ranges by region):**

| Region | Manufacturing overhead | G&A | Typical profit margin |
|--------|----------------------|-----|----------------------|
| China (factory) | 30–60% | 8–15% | 8–20% |
| India | 25–50% | 8–12% | 10–20% |
| Vietnam | 25–50% | 8–12% | 8–18% |
| Bangladesh | 20–40% | 6–10% | 10–18% |
| Turkey | 40–70% | 10–15% | 15–25% |
| Mexico | 35–60% | 10–15% | 15–25% |

Trading company / agent margin: Add 5–15% if buying through an intermediary (not direct from factory).

### Step 5: Tooling Amortisation

If new tooling is required:
- Get tooling cost from supplier (or estimate from `dfm-bridge` critique)
- Divide by volume over tooling life to get per-unit amortisation

```
Tooling cost: $10,000
Tooling life: 500,000 shots
Annual volume: 50,000 units
Per-unit tooling cost: $10,000 / 500,000 = $0.02/unit
```

Negotiate: tooling cost is a one-time investment. If the buyer funds tooling, they should own it.

### Step 6: Build the Model

Output the should-cost model in this format:

```
SHOULD-COST MODEL
Product: [Name]
Manufacturing country: [Country]
Annual volume: [Units]
Model date: [Date]

COST BREAKDOWN (per unit, EXW factory)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DIRECT MATERIALS
  [Material 1]    [Qty] × $[Unit cost]     = $[Total]
  [Material 2]    [Qty] × $[Unit cost]     = $[Total]
  [Component 1]   [Qty] × $[Unit cost]     = $[Total]
  [Packaging]                               = $[Total]
  Waste factor (+[X]%)                      = $[Total]
  ─────────────────────────────────────────
  MATERIAL TOTAL                            = $[X.XX]

DIRECT LABOUR
  [Process 1]     [X min] @ $[Rate]/hr     = $[Total]
  [Process 2]     [X min] @ $[Rate]/hr     = $[Total]
  ─────────────────────────────────────────
  LABOUR TOTAL                              = $[X.XX]

MANUFACTURING OVERHEAD ([X]% of direct)    = $[X.XX]
G&A ([X]%)                                 = $[X.XX]
TOOLING AMORTISATION                        = $[X.XX]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FACTORY COST                                = $[X.XX]

PROFIT MARGIN ([X]%)                        = $[X.XX]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SHOULD-COST (EXW)                           = $[X.XX]
SHOULD-COST RANGE: $[X.XX] – $[X.XX]

LANDED COST (add freight, duty, insurance)
  Ocean freight (FCL/LCL estimate)          = $[X.XX]/unit
  Import duty ([X]% × CIF value)            = $[X.XX]
  ─────────────────────────────────────────
  ESTIMATED LANDED COST                     = $[X.XX]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SUPPLIER QUOTED PRICE: $[X.XX] (if known)
VARIANCE: [X]% above/below should-cost
```

### Step 7: Negotiation Guidance

Based on the variance between should-cost and supplier quote:

**Quote within 10% of should-cost:** Competitive. Focus on terms, payment, lead time. Don't over-negotiate on price.

**Quote 10–25% above should-cost:** Room to negotiate. Present your should-cost model (or a subset of it). Ask for a line-item quote breakdown. Target the gap on the highest-cost component.

**Quote 25–50% above should-cost:** Either the supplier has significantly higher overhead (are they a factory or trader?), or material/labour assumptions need revisiting. Challenge with data.

**Quote >50% above should-cost:** Reject or re-RFQ. Either the supplier is not suited for the volume/category, or has misunderstood the spec.

**Quote below should-cost by >15%:** Caution. Either the supplier is buying the business (unsustainable) or is cutting corners. Ask for a factory visit before committing.

## Related Skills
- `dfm-bridge` — design improvements will shift the should-cost model
- `rfq-drafting` — use should-cost to set target price in RFQ
- `incoterms-advisor` — to build the landed cost from EXW price
- `freight-cost-calculator` — for the freight component of landed cost
- `tariff-hs-lookup` — for the import duty component
