---
name: spend-analysis
description: Use this skill when the user wants to analyse procurement spend, identify savings opportunities, find maverick spending, consolidate suppliers, understand their spend by category or supplier, or build a spend cube. Also trigger when the user says "analyse my spend", "where am I spending money", "which suppliers can I consolidate", "spend visibility", "procurement savings", "category analysis", "spend under management", "tail spend", "preferred supplier compliance", or uploads a PO report, ERP extract, or invoice dataset for analysis. Works with Excel uploads, CSV files, or manually provided spend data.
---

# Spend Analysis

Analyses procurement spend data to surface savings opportunities, supplier consolidation targets, maverick spend, and category insights. Works with any spend dataset — ERP extract, PO register, invoice data, or manually provided figures.

## Read Context First

```bash
cat .sourcesquid/context.md 2>/dev/null
```

Note company profile, annual spend estimate, and any known spend categories.

## Workflow

### Step 1: Data Intake

Ask the user to provide spend data in any format:
- Excel / CSV export from ERP (SAP, Oracle, Tally, QuickBooks, etc.)
- PO register with columns: Date, PO#, Supplier, Category, Amount, Currency
- Invoice listing
- Manual estimate by category

If data is uploaded, use the `xlsx` or `file-reading` skill to read it.

Minimum required fields:
- Supplier name
- Amount (spend value)
- Category or description (if available)
- Period (month/year)

Nice-to-have:
- PO number
- Business unit / cost centre
- Buyer name
- Payment terms
- Country of supply

### Step 2: Data Cleaning and Normalisation

Before analysis:
- Standardise supplier names (e.g., "Alibaba", "Alibaba.com", "Alibaba Group" → "Alibaba")
- Convert all amounts to a single currency (use approximate FX rates)
- Assign or verify categories (see Step 3)
- Remove internal transfers, taxes, and employee expense reimbursements
- Flag duplicates

### Step 3: Category Classification

If categories are missing or inconsistent, classify spend using the UNSPSC or custom taxonomy:

**Standard procurement categories:**

| Category | Sub-categories |
|----------|---------------|
| Direct materials | Raw materials, Components, Packaging, Sub-assemblies |
| Indirect — MRO | Maintenance, Repair, Operations supplies |
| Indirect — IT | Software, Hardware, Cloud services, IT services |
| Indirect — Professional services | Consulting, Legal, Accounting, HR services |
| Indirect — Facilities | Rent, Utilities, Cleaning, Security, Catering |
| Indirect — Marketing | Advertising, Events, Design, Print |
| Logistics | Freight (sea/air/road), Warehousing, 3PL |
| Capex | Equipment, Tooling, Leasehold improvements |
| Travel | Flights, Hotels, Ground transport |
| Utilities | Electricity, Water, Gas |

### Step 4: Build the Spend Cube

Analyse spend across three dimensions:
1. **By Category** — what is being bought
2. **By Supplier** — who is being bought from
3. **By Period** — when spend occurs (monthly, quarterly, annually)

**Category Analysis:**
```
SPEND BY CATEGORY — [Company] | [Period]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Category              Spend      % of Total   Suppliers
─────────────────────────────────────────────────────
Direct Materials      $X,XXX     XX%          XX
Logistics             $X,XXX     XX%          X
[Category]            $X,XXX     XX%          X
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOTAL                 $XX,XXX    100%         XX

Top 3 categories by spend: [Category 1], [Category 2], [Category 3]
```

**Supplier Concentration (Pareto):**
```
SUPPLIER PARETO — [Period]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Supplier          Spend      % of Total   Cumulative %
────────────────────────────────────────────────────
[Supplier 1]      $X,XXX     XX%          XX%
[Supplier 2]      $X,XXX     XX%          XX%
...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Check: Do top 20% of suppliers = ~80% of spend? (Pareto principle)]
Tail suppliers (spending < $X,XXX/year): [N] suppliers = $X,XXX ([X]% of total)
```

### Step 5: Opportunity Identification

**A. Supplier Consolidation**
Find categories where spend is fragmented across many suppliers:
- Same category, multiple suppliers → consolidate to 1–2 preferred, negotiate volume discount
- Target: Categories with >3 suppliers and no apparent reason for fragmentation
- Estimated saving: 5–15% from volume leverage

**B. Maverick Spend**
Identify spend outside preferred supplier list:
- Same category, different supplier from preferred → compliance failure
- No PO (invoice-only purchases) → off-contract spend
- Estimated saving: 5–20% by bringing maverick spend back under contract

**C. Tail Spend Management**
Suppliers with <$5,000/year spend:
- High transaction cost relative to value
- Consider: purchasing card programme, online marketplaces, or consolidating to fewer suppliers
- Typical tail spend = 20% of suppliers but only 5% of value — but high admin cost

**D. Price Benchmarking**
For same item purchased from multiple suppliers at different prices:
- Identify the lowest price paid — target to standardise
- Flag: same item, >15% price variance across suppliers or periods

**E. Payment Terms Optimisation**
- Map current payment terms by supplier
- Identify suppliers on Net 15 or Net 30 where Net 45/60 is achievable
- Estimate working capital benefit of extending terms

**F. Category Savings Opportunities**
For each top-5 category, flag standard savings levers:
- Specification rationalisation (fewer SKUs / variants)
- Demand management (do we really need this much?)
- Should-cost challenge (use `should-cost-modelling` skill)
- Alternative sourcing geography
- Negotiation / re-tendering

### Step 6: Savings Pipeline Output

```
PROCUREMENT SPEND ANALYSIS
[Company] | Period: [Date range]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOTAL SPEND ANALYSED: $[X,XXX,XXX]
SPEND UNDER MANAGEMENT: [X]%
NUMBER OF ACTIVE SUPPLIERS: [N]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TOP FINDINGS:
1. [Finding 1] — estimated saving: $[X,XXX]
2. [Finding 2] — estimated saving: $[X,XXX]
3. [Finding 3] — estimated saving: $[X,XXX]

SAVINGS PIPELINE SUMMARY:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Opportunity           Est. Saving    Effort    Timeline
──────────────────────────────────────────────────────
Supplier consolidation $[X,XXX]      Low       1–3 months
Maverick spend control $[X,XXX]      Medium    2–4 months
Tail spend programme   $[X,XXX]      Medium    3–6 months
Category renegotiation $[X,XXX]      High      3–6 months
Should-cost challenge  $[X,XXX]      High      4–8 months
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOTAL IDENTIFIED SAVINGS: $[X,XXX] ([X]% of analysed spend)

RECOMMENDED NEXT 3 ACTIONS:
1. [Action] — Owner: [Name] — By: [Date]
2. [Action]
3. [Action]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## Related Skills
- `should-cost-modelling` — for category-level cost challenge
- `rfq-drafting` — re-tender high-spend categories
- `vendor-qualification` — before consolidating to a new preferred supplier
- `supplier-outreach` — for re-negotiation outreach to existing suppliers
